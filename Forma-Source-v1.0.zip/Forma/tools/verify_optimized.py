#!/usr/bin/env python3
"""Destructive black-box verification of the actual optimized APK on one disposable emulator."""
from pathlib import Path
import argparse,os,subprocess,json
p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);p.add_argument('--variant',choices=['localOptimized','release'],default='localOptimized');args=p.parse_args()
project=Path(__file__).resolve().parents[1];out=args.output;out.mkdir(parents=True,exist_ok=True)
adb=str(Path(os.environ['ANDROID_HOME'])/'platform-tools/adb')
devices=[line.split()[0] for line in subprocess.check_output([adb,'devices'],text=True).splitlines() if line.startswith('emulator-') and line.endswith('device')]
if len(devices)!=1:raise SystemExit('Exactly one disposable emulator required; physical devices refused.')
def run(*a,check=True):return subprocess.run([adb,'-s',devices[0],*a],check=check,capture_output=True).stdout
if run('shell','getprop','ro.build.version.sdk').strip()!=b'35':raise SystemExit('Validated on API35 only.')
run('shell','cmd','connectivity','airplane-mode','enable')
for path in [f'app/build/outputs/apk/{args.variant}/app-{args.variant}.apk','verification/build/outputs/apk/debug/verification-debug.apk','verification/build/outputs/apk/androidTest/debug/verification-debug-androidTest.apk']:
 run('install','-r',str(project/path))
run('shell','pm','clear','com.localjournal.fitness');run('shell','pm','grant','com.localjournal.fitness','android.permission.CAMERA')
for method,name in [('seedOptimizedCameraAndComparison','optimized-seed'),('verifyOptimizedFreshProcessExportAndDeletion','optimized-restart')]:
 if name.endswith('restart'):run('shell','am','force-stop','com.localjournal.fitness')
 data=run('shell','am','instrument','-w','-r','-e','class','com.localjournal.fitness.verification.OptimizedWorkflowTest#'+method,'com.localjournal.fitness.verification.test/androidx.test.runner.AndroidJUnitRunner')
 (out/(name+'.txt')).write_bytes(data)
 if b'OK (' not in data:
  (out/(name+'-failure.png')).write_bytes(run('exec-out','screencap','-p'))
  (out/(name+'-logcat.txt')).write_bytes(run('logcat','-d','-s','AndroidRuntime:E','TestRunner:I'));raise SystemExit(name+' FAILED')
 print(name+' passed',flush=True)
shots=out/'screenshots';shots.mkdir(exist_ok=True)
for name in ['side-by-side','slider','viewer-after-restart','empty-after-delete']:
 data=run('exec-out','cat','/data/local/tmp/forma-optimized-'+name+'.png')
 if data.startswith(b'\x89PNG'):(shots/(name+'.png')).write_bytes(data)
print('OPTIMIZED BLACK-BOX WORKFLOW PASSED',flush=True)
