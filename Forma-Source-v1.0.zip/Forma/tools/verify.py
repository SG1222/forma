#!/usr/bin/env python3
"""Staged, destructive tests on one disposable API 35 emulator. See README before running."""
from pathlib import Path
import os,subprocess,time,threading,re,argparse,shutil
parser=argparse.ArgumentParser();parser.add_argument('--stage',choices=['visual','reliability','final','layouts','phase5a','phase5d','phase5f'],required=True);parser.add_argument('--output',type=Path,required=True);parser.add_argument('--only',help='Run one named check from the selected stage');args=parser.parse_args()
project=Path(__file__).resolve().parents[1];out=args.output;out.mkdir(parents=True,exist_ok=True)
adb=str(Path(os.environ['ANDROID_HOME'])/'platform-tools/adb');serials=[l.split()[0] for l in subprocess.check_output([adb,'devices'],text=True).splitlines() if l.startswith('emulator-') and l.endswith('device')]
if len(serials)!=1:raise SystemExit('Exactly one disposable emulator required; physical devices refused.')
def run(*a,check=True):return subprocess.run([adb,'-s',serials[0],*a],capture_output=True,check=check).stdout
if run('shell','getprop','ro.build.version.sdk').strip()!=b'35':raise SystemExit('This runner is validated on API 35 only.')
def clear():run('shell','am','force-stop','com.localjournal.fitness');run('shell','pm','clear','com.localjournal.fitness')
def collect(name):
 for folder in run('exec-out','run-as','com.localjournal.fitness','ls','files',check=False).decode().split():
  if 'screenshots' not in folder:continue
  for f in run('exec-out','run-as','com.localjournal.fitness','ls','files/'+folder,check=False).decode().split():
   if f.endswith('.png'):
    dest=out/'screenshots'/name;dest.mkdir(parents=True,exist_ok=True);(dest/f).write_bytes(run('exec-out','run-as','com.localjournal.fitness','cat','files/'+folder+'/'+f))
 for f in ['phase4-performance.json','phase5-interactions.json']:
  data=run('exec-out','run-as','com.localjournal.fitness','cat','files/'+f,check=False)
  if data.lstrip().startswith(b'{'):(out/f).write_bytes(data)
def test(name,selector,reset=True):
 if args.only and not (args.only==name or name.startswith(args.only+'-')):return
 if reset:clear()
 data=run('shell','am','instrument','-w','-r','-e','class','com.localjournal.fitness.'+selector,'com.localjournal.fitness.test/androidx.test.runner.AndroidJUnitRunner')
 (out/(name+'.txt')).write_bytes(data);collect(name)
 if b'OK (' not in data:
  (out/(name+'-failure.png')).write_bytes(run('exec-out','screencap','-p'));print(data.decode(),flush=True);raise SystemExit(name+' FAILED')
 print(name+' passed',flush=True)
stop=threading.Event()
def fingers():
 last=''
 while not stop.wait(.2):
  try:
   value=run('exec-out','run-as','com.localjournal.fitness','cat','files/auth-command',check=False).decode().strip()
   if value==last or not re.fullmatch('[12]:[0-9a-f-]{36}',value):continue
   run('emu','finger','touch',value[0]);time.sleep(.15);run('emu','finger','remove')
   run('shell','run-as','com.localjournal.fitness','sh','-c',"'printf %s "+value+" > files/auth-ack'");last=value
  except Exception:pass
worker=threading.Thread(target=fingers,daemon=True)
if args.stage in ['reliability','final','phase5f'] and (not args.only or any(name==args.only or name.startswith(args.only+'-') for name in ['security-export-delete','process-seed','process-restart'])):worker.start()
old_timeout=run('shell','settings','get','system','screen_off_timeout').decode().strip()
old_motion={key:run('shell','settings','get','global',key).decode().strip() for key in ['animator_duration_scale','transition_animation_scale','window_animation_scale']}
run('shell','settings','put','system','screen_off_timeout','600000');run('shell','cmd','connectivity','airplane-mode','enable')
run('install','-r',str(project/'app/build/outputs/apk/debug/app-debug.apk'));run('install','-r',str(project/'app/build/outputs/apk/androidTest/debug/app-debug-androidTest.apk'))
try:
 run('shell','wm','size','reset');run('shell','wm','density','reset');run('shell','settings','put','system','font_scale','1.0')
 if args.stage=='phase5d':
  for key in old_motion:run('shell','settings','put','global',key,'1')
  test('motion','Phase5MotionTest');test('ui','Phase4UiTest');test('compare','ComparisonTest');test('state','FoundationNavigationTest');test('interaction','Phase5InteractionTest')
  for key in old_motion:run('shell','settings','put','global',key,'0')
  test('reduced-viewer','Phase4UiTest#viewerControlsKeepImagePlaneFixedAndZoomBounded');test('reduced-dock','FoundationNavigationTest')
 if args.stage=='phase5a':
  test('theme-matrix','Phase5ThemeTest');test('compare','ComparisonTest');test('dock','FoundationNavigationTest');test('records-streaks','StreaksTest');test('records-grid','CoreJournalTest#populatedLibraryReviewViewerBothThemesAndScrollRestoration');test('interaction','Phase5InteractionTest')
 if args.stage=='visual':
  for name,selector in [('ui','Phase4UiTest'),('grid-review','CoreJournalTest#populatedLibraryReviewViewerBothThemesAndScrollRestoration'),('camera','CoreJournalTest#cameraMultiPhotoSaveViewEditDeleteAndPrivacy'),('compare','ComparisonTest#comparisonScreensBothThemesAndMixedOrientations'),('streaks','StreaksTest#streaksScreensBothThemes'),('settings-lock','Phase3cTest#settingsAndLockScreensBothThemes'),('states','Phase4StatesTest'),('permission','CameraDeniedTest')]:test(name,selector)
 if args.stage=='phase5f':
  for key in old_motion:run('shell','settings','put','global',key,'1');old_motion[key]='1'
 if args.stage in ['reliability','final','phase5f']:
  for name,selector in [('security-export-delete','Phase3cTest'),('process-seed','AuthProcessTest#seedLockedPreference')]:test(name,selector)
  run('shell','am','force-stop','com.localjournal.fitness');test('process-restart','AuthProcessTest#verifyFreshProcessRequiresRealAuthentication',False)
  if args.stage=='phase5f' and worker.is_alive():stop.set();worker.join(timeout=3)
  for name,selector in [('core','CoreJournalTest'),('compare','ComparisonTest'),('streaks','StreaksTest'),('dock','FoundationNavigationTest'),('storage','DeviceStorageTest'),('recovery-seed','RecoveryScenarioTest#seed')]:test(name,selector)
  run('shell','am','force-stop','com.localjournal.fitness');test('recovery-restart','RecoveryScenarioTest#verifyAfterForceStop',False)
  test('reliability','Phase4ReliabilityTest')
  if args.stage=='reliability':
   test('stress-seed','Phase4PerformanceTest#seedThousandPhotosAndProfileGridViewerComparison')
   run('shell','am','force-stop','com.localjournal.fitness');test('stress-restart','Phase4PerformanceTest#verifyColdLibraryAfterForceStop',False)
  if args.stage in ['final','phase5f']:
   if args.stage=='phase5f':
    test('theme-matrix','Phase5ThemeTest');test('motion','Phase5MotionTest');test('interaction','Phase5InteractionTest')
    test('stress-seed','Phase4PerformanceTest#seedThousandPhotosAndProfileGridViewerComparison')
    run('shell','am','force-stop','com.localjournal.fitness');test('stress-restart','Phase4PerformanceTest#verifyColdLibraryAfterForceStop',False)
   test('ui','Phase4UiTest');test('states','Phase4StatesTest');test('permission','CameraDeniedTest')
   if not args.only or args.only.startswith('reduced-motion'):
    for key in old_motion:run('shell','settings','put','global',key,'0')
    test('reduced-motion','Phase4UiTest#viewerControlsKeepImagePlaneFixedAndZoomBounded');test('reduced-motion-dock','FoundationNavigationTest')
    for key,value in old_motion.items():run('shell','settings','put','global',key,value if value!='null' else '1')
 if args.stage in ['layouts','final','phase5f']:
  for name,size,density,font in [('small','720x1280','320','1.0'),('large-phone','1440x2560','420','1.0'),('tablet','1600x2560','320','1.0'),('large-font','720x1280','320','1.5')]:
   run('shell','wm','size',size);run('shell','wm','density',density);run('shell','settings','put','system','font_scale',font)
   test(name,'Phase4UiTest#allScreensBothThemesAndKeyboardReachability')
   test(name+'-lock','Phase3cTest#settingsAndLockScreensBothThemes')
 if args.stage in ['final','phase5f'] and (not args.only or args.only=='unavailable'):
  run('shell','wm','size','reset');run('shell','wm','density','reset');run('shell','settings','put','system','font_scale','1.0')
  clear();run('shell','locksettings','clear','--old','2468');test('unavailable','AuthUnavailableTest')
finally:
 stop.set()
 if worker.is_alive():worker.join(timeout=3)
 run('shell','wm','size','reset');run('shell','wm','density','reset');run('shell','settings','put','system','font_scale','1.0')
 if old_timeout and old_timeout!='null':run('shell','settings','put','system','screen_off_timeout',old_timeout)
 for key,value in old_motion.items():run('shell','settings','put','global',key,value if value!='null' else '1')
print('STAGE '+args.stage+' PASSED',flush=True)
