pluginManagement { repositories { google(); mavenCentral(); gradlePluginPortal() } }
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories { google(); mavenCentral() }
}
rootProject.name = "FitnessPhotoJournal"
include(":app")

// Separate UID/runtime: black-box checks of the actual R8 APK. Not bundled into Forma.
include(":verification")
