# Forma 1.0

Forma is a native Android photo journal that works completely offline. Log is a private photo library, Compare is a two-image workspace, and Streaks is a Monday-first weekly record. There are no accounts, cloud services, analytics, advertising or Internet permission.

## Features

- CameraX front/rear capture, supported flash controls and multiple photos per session.
- Multiple local-photo imports through Android's system document picker; originals stay unchanged.
- Dated check-ins with optional Front/Side/Back/Other labels and a shared note.
- Three-column month-grouped Log, private thumbnails and preserved scroll position.
- Full-screen swipe, bounded pinch/pan, double-tap zoom, editing and confirmed deletion.
- Side-by-side comparison with independent transforms; real clipped reveal slider with alignment controls; Quick Compare.
- Current/longest weekly streak, total check-ins and calendar history.
- Optional native biometric/device-credential lock; System/Light/Dark themes.
- Explicit individual-photo export and confirmed private-data deletion.

## Technology Stack

| Component | Version |
|---|---|
| Kotlin / Compose compiler plugin | 2.2.20 |
| Compose BOM / Material 3 | 2025.08.01 / BOM-managed |
| Android Gradle Plugin / wrapper | 8.13.2 / 8.13 |
| CameraX | 1.5.1 |
| Room / KSP | 2.8.3 / 2.2.20-2.0.3 |
| DataStore / Coil | 1.1.7 / 3.3.0 |
| Navigation / Lifecycle | 2.9.5 / 2.9.4 |
| Activity / Biometric / ExifInterface | 1.11.0 / 1.1.0 / 1.4.1 |
| JUnit / Robolectric / UiAutomator | 4.13.2 / 4.16.1 / 2.3.0 |

Gradle build scripts are authoritative. Dependencies were retained rather than upgraded during final refinement.

## Development Requirements

Use JDK 17, Android SDK Platform 36, build tools 35.0.0 and platform-tools. Minimum Android is 10/API 29; compile/target API is 36. Use Android Studio compatible with AGP 8.13.2. Command-line builds are verified; no specific IDE installation is certified. The wrapper pins its distribution checksum.

Extract `Forma-Source-v1.0.zip`, open its `Forma/` folder in Android Studio, select the app run configuration, choose JDK 17 and configure the SDK. Set `ANDROID_HOME`, or create a local, uncommitted `local.properties` containing `sdk.dir=/your/sdk/path`. Accept SDK licenses and sync Gradle. Initial dependency resolution needs development-machine Internet access; the installed app does not.

## Building and Installing

From `Forma/` on macOS/Linux (Windows: use `gradlew.bat`):

```sh
chmod +x gradlew
./gradlew :app:assembleDebug
adb install -r app/build/outputs/apk/debug/app-debug.apk
adb shell am start -n com.localjournal.fitness/.MainActivity
```

Run an API 29+ emulator or enable USB debugging on a physical Android device. Confirm the intended device with `adb devices`; use `adb -s SERIAL` when multiple devices are attached. Android Studio Run also builds/installs the app. For normal local testing, the proven optimized variant is:

```sh
./gradlew :app:assembleLocalOptimized
adb install -r app/build/outputs/apk/localOptimized/app-localOptimized.apk
```

It uses R8/resource shrinking, excludes Compose debug tooling and is non-debuggable. It uses the local debug signing configuration and is **not a production-signed release**. The final debug artifact uses the normal debug variant; the final release artifact uses the release variant with the separately authorized release identity. Application ID remains `com.localjournal.fitness`, version name `1.0`, version code `8`. Code 8 permits updating previous code-7 installations even though the public version name changed.

Use `install -r` to preserve data when certificates match. Never uninstall or clear personal journal data to work around a signing error. Future builds require the same signing identity to update the supplied app; a new developer's generated debug key will differ. Private signing keys are intentionally absent from this archive.

The final artifacts are `Forma-v1.0-debug.apk` (debug variant, existing debug certificate, debuggable) and `Forma-v1.0-release.apk` (release variant, new user-authorized RSA release certificate, R8/resource shrinking, non-debuggable). The new release certificate cannot update a debug-signed installation in place. Keep using the matching debug APK to preserve an existing debug installation's private data; do not uninstall a populated journal to resolve certificate mismatch.

To rebuild a signed release, securely supply `FORMA_RELEASE_KEYSTORE`, `FORMA_RELEASE_STORE_PASSWORD`, `FORMA_RELEASE_KEY_ALIAS` and `FORMA_RELEASE_KEY_PASSWORD` in the build process environment, then run `./gradlew :app:assembleRelease`. The keystore must be PKCS12. Output: `app/build/outputs/apk/release/app-release.apk`. Without all four variables, the release output is unsigned and must not be distributed as installable. Private signing materials are stored separately and are deliberately excluded from this archive. Back up the authorized signing identity securely; losing it prevents updates using that certificate. Do not commit credentials or put them in Gradle properties/source archives.

After final verification, project-dedicated SDK/JDK/Gradle/emulator installations were removed from the development Mac as requested. To develop elsewhere, install Android Studio or Google's Android command-line tools, JDK 17, SDK Platform 36, build-tools 35.0.0 and platform-tools; accept SDK licenses, configure the SDK path, and allow the pinned wrapper to download Gradle/dependencies. No removed machine-local directory is required by this archive.

## Project Structure

```text
Forma/
  app/
    src/main/java/com/localjournal/fitness/
      core/          # design, navigation, security, storage, export
      data/          # Room, models, preferences, repositories
      features/      # Log, camera, review, viewer, Compare, Streaks, Settings
    src/main/res/    # themes, adaptive/legacy/monochrome icons, backup rules
    src/test/        # logic, storage, security and contrast tests
    src/androidTest/# device/UI/recovery/large-library tests
    schemas/         # exported Room schema
  verification/      # separate test-only host for the real optimized APK
  tools/             # disposable-emulator verification runners
  design/            # approved icon and technical provenance
  gradle/wrapper/
  LICENSES/
  THIRD_PARTY_NOTICES.md
```

The verification host is a separate application/UID and is not bundled into Forma. Generated outputs, SDK paths, caches, screenshots, logs, keys and APKs are excluded from the source distribution.

## Architecture

Compose screens receive state/actions through `JournalViewModel` and screen state holders. Room flows, lifecycle-aware collection and DataStore supply journal, appearance and authentication preferences. The navigation graph saves tab state; a root lazy-grid state restores exact Log position. The native access gate surrounds private navigation.

Room schema 1 has `check_ins` and related ordered `photos` rows, foreign-key cascade and unique original paths/order constraints. `journal.db`, package, preference identity and private directories are preserved. Dates are recorded when saving; importing an old image does not backdate its check-in. Streaks derive from saved local dates, not a mutable counter or photo count.

Repository mutations serialize private-file/Room work. Staged originals, atomic draft metadata, commit recovery and a durable deletion marker protect unrelated saved entries during failure. CameraX binds/unbinds with lifecycle. Imports copy URI streams into private storage. Thumbnail rendering never falls back to original full-resolution files; viewer/comparison requests decode at display-appropriate sizes. Coil disk caching is disabled. The slider clips real overlapping images in a common viewport; it is not an opacity effect.

Export is an explicit original-byte copy into a pending MediaStore row with recovery bookkeeping before publication. Completed gallery copies remain outside private-data deletion. The existing `Pictures/Photo Journal/` album/file naming remains for compatibility.

## Code Philosophy

Prefer readable, small responsibilities over extra frameworks or abstraction. UI owns presentation, ViewModel actions coordinate work, repositories own data/files, and pure functions implement streak/transform rules. Native Android permissions, document selection and authentication are retained. Shared Compose actions and semantic design tokens keep behavior consistent without forcing every screen into the same layout.

Offline storage, minimal dependencies, explicit failure states and independently testable logic guide maintenance. State is predictable rather than duplicated across screens. Accessibility uses labeled actions, semantic selection/range information, contrast-tested colors and appropriate targets. Existing working code was preserved; no claim of architectural perfection or speculative optimization is made.

## Design Philosophy

Warm cream surfaces, brown ink and dusty teal provide one quiet identity. Apple Photos informs dense square browsing and immersive viewing; Apple Health informs calendar/type hierarchy. The approved launcher artwork is retained. Central light background is F4EDE3; primary teal is 3B7372, slightly deeper than the original proposal for text contrast. Dark mode uses deep neutral surfaces and coordinated light teal. Photographs are never tinted.

The floating capsule dock keeps approximately 20 dp side margins and 14 dp bottom safe-area clearance. Narrow grid gutters and photo-first layouts remain. Corners vary by role; primary actions have 52 dp minimum height. Restrained translucent materials and soft elevation suggest floating controls without expensive blur, refraction, gradients or glow. Typography and action hierarchy carry the interface.

## Performance Philosophy

Stable LazyGrid identities/content types, private thumbnails, display-sized images and existing memory-cache reuse limit unnecessary decoding. Disk work runs on IO dispatchers and Room-result/streak mapping off the UI thread. Comparison transforms read in rendering layers; divider updates draw/place only what changes. No bitmap processing runs on each drag. Lifecycle-aware flows and saved navigation avoid unnecessary reloads. No extra cache, dependency or blanket stability annotations were added.

Measurements are debug/software-emulator diagnostics, not physical touch latency or guaranteed FPS. Phase 6 retained working performance code because no new bottleneck justified a change. The user reports the Phase 5 optimized build works well on their phone; no physical-device testing was performed by the agent.

## Navigation & Animation

The capsule remains stationary while its selected indicator moves. Tab state preserves grid position, comparison selections/mode and calendar navigation. Single-top actions prevent duplicate destinations. Destination-owned insets protect outgoing geometry. Existing 180/120 ms entry/exit fades, 200 ms selection and 100 ms press feedback remain; system animation-duration scaling supplies reduced-motion behavior. Viewer controls overlay a fixed photo plane. Comparison mode changes do not crossfade full-size image planes or disrupt alignment. No new animation was added for novelty.

## Privacy & Security

The APK permits CAMERA, USE_BIOMETRIC, USE_FINGERPRINT and the AndroidX app-signature receiver permission only. It has no INTERNET/broad-storage/media permission or network-fetcher/analytics/cloud SDK. Captures, thumbnails, drafts and temporary originals stay internal. Local-only picker hints cannot control independent external-provider behavior.

App lock defaults off and uses native Android authentication. Fresh processes lock when enabled; authorized background returns have a 30-second monotonic grace period. Authorization is memory-only. Recents suppression is supported on API 33+; ordinary authorized screenshots remain allowed. Below API 33/vendor launchers, recents privacy is best effort.

Backup is disabled, with explicit legacy/cloud/device-transfer exclusions. OEM compliance is not certified. Android sandbox/device protections are used; no app-level or end-to-end photo encryption is claimed. Debug builds permit developer access. Manual exports are public and other applications may back them up. Delete all data confirms removal of private records/photos/previews/drafts, resets appearance/export notices, retains the lock choice and leaves completed public exports alone. Uninstalling/clearing data removes the private journal.

## Testing

```sh
./gradlew :app:assembleDebug :app:assembleDebugAndroidTest :app:testDebugUnitTest :app:lintDebug :app:verifyOfflinePrivacy
python3 tools/verify.py --stage phase5f --output verification-local/final
./gradlew :verification:assembleDebug :verification:assembleDebugAndroidTest :app:assembleLocalOptimized
python3 tools/verify_optimized.py --output verification-local/optimized
```

**Device runners are destructive: use exactly one disposable English API 35 emulator, never personal data.** They refuse physical devices, enable airplane mode and repeatedly clear fixture journal data. Before the full suite, configure test PIN 2468 and enroll virtual fingerprint 1 through Android Settings. The runner supplies matching/nonmatching touches and removes the test PIN/enrollment for its last unavailable-authentication test. Both virtual cameras and gesture navigation are required. Screen/density/font/animation settings restore afterward. Seed/restart tests require their prescribed order; unfiltered instrumentation is not equivalent.

Available tests cover comparison math/gestures, weekly boundaries, atomic storage/failure recovery, process/session rules, contrast, camera/import/multi-photo workflows, editing/deletion/export, six app/system theme combinations, navigation/motion, 1,000-photo browsing and small/large/tablet/large-font layouts. The separate optimized host checks actual UI capture, persistence, comparison, editing, export and deletion from another UID. Private hashes and native authentication are verified by the debug suite, not by that host.

Phase 6 verification: 73 unit tests and 49 staged debug instrumentation executions passed; all six app/system theme combinations were exercised. The actual version-1.0 optimized APK passed both separate-host workflow stages and an in-place update retained original hashes, unfinished draft and preferences. Android lint reported 0 errors / 27 warnings (19 version-update advisories and 8 legacy/base icon/resource advisories). No new application bug, performance change or animation change was required. Extracted-source rebuild verification is reported with final delivery. Do not interpret a compiled test or old report as a fresh test pass.

## Known Limitations

Only API 35 ARM64 software emulation was available. API 29/36 runtime, physical/OEM cameras/biometrics, backup/transfer behavior, formal TalkBack certification, every landscape/foldable configuration, actual power loss/full-device storage exhaustion and HEIF/HEIC remain unverified. Fault tests inject IO/ENOSPC errors. English-only, portrait-first/single-pane layouts remain. Software frame timing is slow/variable and does not certify a production frame rate. No production signing key is included.

## Maintenance Guide

Update dependencies one at a time after a demonstrated need; retain pinned builds and rerun relevant tests. Add destinations in `core/navigation`, keep private routes behind the access gate and provide localized semantics when adding UI. Change shared colors/type/spacing/corners/motion in `core/design`; verify contrast, both themes, keyboard/insets and disabled animations.

Keep the approved icon/provenance under `design/`. Technical adaptive/legacy/monochrome resources must preserve safe-zone proportions and be checked in a real launcher. For schema changes, increment Room version, provide an explicit migration and migration tests; never use destructive migration on journals. Keep stable date/enum/path semantics and existing DataStore keys.

Add targeted pure tests under `app/src/test`, device workflows under `app/src/androidTest`, and public-UI optimized checks under `verification/src/androidTest`. Build debug for diagnosis and localOptimized for normal local trials. Increment version code for updates, retain the authorized signing identity and inspect the actual delivered APK's permissions/signature after changes.

## License and Attribution

No project-wide license has been established; do not assume a license grant. Retain `THIRD_PARTY_NOTICES.md`, `LICENSES/Apache-2.0.txt` and vendored icon copyright headers. Gradle-resolved libraries retain their upstream licenses. The approved Forma artwork is supplied by the project owner; its provenance records technical preparation without inventing a separate artwork license.
