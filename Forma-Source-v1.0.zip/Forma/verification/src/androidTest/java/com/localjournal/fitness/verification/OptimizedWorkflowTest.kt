package com.localjournal.fitness.verification

import android.content.Intent
import androidx.test.platform.app.InstrumentationRegistry
import androidx.test.uiautomator.*
import org.junit.Test
import org.junit.Assert.*

/** Black-box UI/API smoke: no references to R8-renamed application implementation classes. */
class OptimizedWorkflowTest {
    @Test fun seedOptimizedCameraAndComparison() = runWorkflow(false)
    @Test fun verifyOptimizedFreshProcessExportAndDeletion() = runWorkflow(true)

    private fun runWorkflow(afterRestart: Boolean) {
        val instrumentation=InstrumentationRegistry.getInstrumentation();val context=instrumentation.targetContext
        val device=UiDevice.getInstance(instrumentation)
        Configurator.getInstance().waitForIdleTimeout = 500
        fun find(selector:BySelector, timeout:Long):UiObject2? {
            val until=android.os.SystemClock.uptimeMillis()+timeout
            do {
                // Camera reuses the count node. Refresh the cross-process accessibility
                // cache rather than waiting for a new window/content event.
                instrumentation.uiAutomation.clearCache()
                device.findObject(selector)?.let { return it }
                android.os.SystemClock.sleep(100)
            } while(android.os.SystemClock.uptimeMillis()<until)
            return null
        }
        fun text(value:String, timeout:Long = 20_000)=find(By.text(value),timeout) ?: error("Missing visible control: $value")
        fun desc(value:String)=find(By.desc(value).enabled(true),20_000) ?: error("Missing action: $value")
        fun expectPhotoCount(expected: Int) {
            val until=android.os.SystemClock.uptimeMillis()+20_000
            do {
                instrumentation.uiAutomation.clearCache()
                if(device.findObjects(By.descStartsWith("Photo ")).size==expected)return
                android.os.SystemClock.sleep(100)
            } while(android.os.SystemClock.uptimeMillis()<until)
            error("Expected $expected visible library photographs")
        }
        fun shot(name:String) {
            // Shell-owned test evidence avoids opening app-private storage on a non-debuggable build.
            instrumentation.uiAutomation.executeShellCommand("screencap -p /data/local/tmp/forma-optimized-$name.png").use {
                android.os.ParcelFileDescriptor.AutoCloseInputStream(it).use { stream -> stream.readBytes() }
            }
        }
        fun launch(){context.startActivity(Intent().setClassName("com.localjournal.fitness","com.localjournal.fitness.MainActivity").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));text("Log")}
        fun capture(count:Int,note:Boolean) {
            desc("Add photographs").click();text("Take Photo").click()
            repeat(count){i->desc("Take photograph").click();text(if(i==0) "1 photo" else "${i+1} photos", 30_000)}
            text("Continue").click()
            if(note){val field=device.wait(Until.findObject(By.clazz("android.widget.EditText")),10_000)!!;field.click();field.text="OPTIMIZED TEST: private check-in";device.pressBack();text("Label: None").click();text("Front").click()}
            text("Save Check-in").click();text("Log")
        }
        fun publicCount(): Int = Regex("(?m)^Row:").findAll(device.executeShellCommand(
            "content query --uri content://media/external/images/media --projection _id")).count()
        launch();val before=publicCount()
        if (!afterRestart) {
        capture(2,true);capture(1,false);assertEquals(before,publicCount())
        text("Compare").click();desc("Change photo A").click()
        (device.wait(Until.findObject(By.descContains(" photo 1,")),10_000) ?: error("Private picker empty")).click()
        desc("Change photo B").click();device.wait(Until.findObject(By.descContains(" photo 1,")),10_000)!!.click()
        text("Side by Side");shot("side-by-side");text("Slider").click()
        val handle=desc("Comparison divider").visibleCenter;device.swipe(handle.x,handle.y,handle.x-140,handle.y,20);shot("slider")
        text("Streaks").click();text("Total check-ins");text("Log").click();desc("Settings").click();text("Settings");android.os.SystemClock.sleep(250);text("Dark theme").click();desc("Back to Log").click()
        return
        }
        expectPhotoCount(3)
        val photo=device.wait(Until.findObject(By.descStartsWith("Photo 1,")),10_000) ?: error("Saved photos missing after restart");photo.click()
        text("Export");shot("viewer-after-restart")
        // This host has a different UID and cannot read Forma's private files.
        // Original-byte/file-removal assertions belong to the full debug suite.
        text("Export").click();text("Save to Gallery").click();text("Saved to Gallery")
        assertEquals(before+1,publicCount())
        desc("More").click();text("Edit").click();device.wait(Until.findObject(By.clazz("android.widget.EditText")),10_000)!!.text="OPTIMIZED TEST: edited";text("Save changes").click()
        desc("More").click();text("Delete").click();text("Delete permanently").click()
        // Deleting the newest single-photo entry may return directly to Log.
        if(device.wait(Until.hasObject(By.desc("Back to Log")),1500)) desc("Back to Log").click()
        desc("Settings").click();text("Settings");android.os.SystemClock.sleep(250)
        repeat(5){if(device.hasObject(By.text("Delete all data")))return@repeat;device.swipe(device.displayWidth/2,device.displayHeight*4/5,device.displayWidth/2,device.displayHeight/3,20)}
        text("Delete all data").click();text("Delete all data?");text("Cancel").click();desc("Back to Log").click()
        expectPhotoCount(2);desc("Settings").click();text("Settings");android.os.SystemClock.sleep(250)
        repeat(5){if(!device.hasObject(By.text("Delete all data")))device.swipe(device.displayWidth/2,device.displayHeight*4/5,device.displayWidth/2,device.displayHeight/3,20)}
        text("Delete all data").click();text("Delete all data?");text("Delete all data").click();text("Your photo journal is empty.")
        assertEquals(before+1,publicCount());expectPhotoCount(0)
        shot("empty-after-delete")
    }
}
