# Third-party notices

Three vector definitions under `core/design/icons` come from AndroidX Compose Material Icons Extended 1.7.8, Copyright 2025 The Android Open Source Project, Apache License 2.0. Their package was relocated; vector geometry is unchanged. Only these three vectors are vendored to avoid including the full extended icon catalog. Settings and Back use the matching AndroidX Material Icons Core family.

Source archive: https://dl.google.com/dl/android/maven2/androidx/compose/material/material-icons-extended/1.7.8/material-icons-extended-1.7.8-sources.jar

License text: LICENSES/Apache-2.0.txt

All other AndroidX, Coil, Kotlin and test libraries are resolved through Gradle and retain their upstream licenses and notices.
