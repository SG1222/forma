plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("com.google.devtools.ksp")
}
android {
    namespace = "com.localjournal.fitness"
    compileSdk = 36
    defaultConfig {
        applicationId = "com.localjournal.fitness"
        minSdk = 29
        targetSdk = 36
        versionCode = 8
        versionName = "1.0"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }
    val releaseEnvironment = listOf("FORMA_RELEASE_KEYSTORE", "FORMA_RELEASE_STORE_PASSWORD", "FORMA_RELEASE_KEY_ALIAS", "FORMA_RELEASE_KEY_PASSWORD")
        .map { providers.environmentVariable(it).orNull }
    val releaseIdentity = if (releaseEnvironment.all { !it.isNullOrBlank() }) signingConfigs.create("authorizedRelease") {
        storeFile = file(releaseEnvironment[0]!!)
        storePassword = releaseEnvironment[1]
        keyAlias = releaseEnvironment[2]
        keyPassword = releaseEnvironment[3]
        storeType = "PKCS12"
    } else null
    buildTypes {
        getByName("release") {
            signingConfig = releaseIdentity
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
        create("localOptimized") {
            initWith(getByName("release"))
            signingConfig = signingConfigs.getByName("debug") // Local testing only, not a production signing identity.
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            matchingFallbacks += listOf("release")
        }
    }
    buildFeatures { compose = true }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    testOptions { unitTests.isIncludeAndroidResources = true }
}
kotlin { compilerOptions { jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17) } }
ksp { arg("room.schemaLocation", "$projectDir/schemas") }
dependencies {
    implementation("androidx.biometric:biometric:1.1.0")
    val cameraVersion = "1.5.1"
    implementation("androidx.camera:camera-camera2:$cameraVersion")
    implementation("androidx.camera:camera-lifecycle:$cameraVersion")
    implementation("androidx.camera:camera-view:$cameraVersion")
    implementation("io.coil-kt.coil3:coil-compose:3.3.0")
    implementation(platform("androidx.compose:compose-bom:2025.08.01"))
    implementation("androidx.activity:activity-compose:1.11.0")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-core")
    implementation("androidx.compose.ui:ui-tooling-preview")
    debugImplementation("androidx.compose.ui:ui-tooling")
    implementation("androidx.navigation:navigation-compose:2.9.5")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.9.4")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.9.4")
    implementation("androidx.room:room-runtime:2.8.3")
    implementation("androidx.room:room-ktx:2.8.3")
    ksp("androidx.room:room-compiler:2.8.3")
    implementation("androidx.datastore:datastore-preferences:1.1.7")
    implementation("androidx.exifinterface:exifinterface:1.4.1")
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.jetbrains.kotlinx:kotlinx-coroutines-test:1.10.2")
    testImplementation("org.robolectric:robolectric:4.16.1")
    testImplementation("androidx.test:core:1.7.0")
    androidTestImplementation(platform("androidx.compose:compose-bom:2025.08.01"))
    androidTestImplementation("androidx.compose.ui:ui-test-junit4")
    androidTestImplementation("androidx.test.ext:junit:1.3.0")
    androidTestImplementation("androidx.test:runner:1.7.0")
    androidTestImplementation("androidx.test.uiautomator:uiautomator:2.3.0")
    androidTestImplementation("androidx.test:rules:1.7.0")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.7.0")
    debugImplementation("androidx.compose.ui:ui-test-manifest")
}

// Guard the final merged manifest, including anything contributed by dependencies.
tasks.register("verifyOfflinePrivacy") {
    dependsOn("processDebugManifest")
    val manifest = layout.buildDirectory.file("intermediates/merged_manifests/debug/processDebugManifest/AndroidManifest.xml")
    inputs.file(manifest)
    inputs.files("src/main/res/xml/backup_rules.xml", "src/main/res/xml/data_extraction_rules.xml")
    doLast {
        val factory = javax.xml.parsers.DocumentBuilderFactory.newInstance().apply { isNamespaceAware = true }
        val document = factory.newDocumentBuilder().parse(manifest.get().asFile)
        val android = "http://schemas.android.com/apk/res/android"
        val permissions = document.getElementsByTagName("uses-permission")
        for (index in 0 until permissions.length) {
            val element = permissions.item(index) as org.w3c.dom.Element
            val permission = element.getAttributeNS(android, "name")
            check(permission in setOf("android.permission.CAMERA", "android.permission.USE_BIOMETRIC",
                "android.permission.USE_FINGERPRINT", "com.localjournal.fitness.DYNAMIC_RECEIVER_NOT_EXPORTED_PERMISSION")) {
                "Unexpected permission in merged manifest: $permission"
            }
        }
        val application = document.getElementsByTagName("application").item(0) as org.w3c.dom.Element
        check(application.getAttributeNS(android, "allowBackup") == "false")
        check(application.getAttributeNS(android, "fullBackupContent") == "@xml/backup_rules")
        check(application.getAttributeNS(android, "dataExtractionRules") == "@xml/data_extraction_rules")
        val domains = setOf("root", "file", "database", "sharedpref", "external", "device_root", "device_file", "device_database", "device_sharedpref")
        fun verifyExclusions(element: org.w3c.dom.Element) {
            val excludes = element.getElementsByTagName("exclude")
            val excludedDomains = (0 until excludes.length).map { excludes.item(it) as org.w3c.dom.Element }
                .filter { it.getAttribute("path") == "." }.map { it.getAttribute("domain") }.toSet()
            check(excludedDomains.containsAll(domains)) { "Incomplete backup/transfer exclusions" }
        }
        verifyExclusions(factory.newDocumentBuilder().parse(file("src/main/res/xml/backup_rules.xml")).documentElement)
        val extraction = factory.newDocumentBuilder().parse(file("src/main/res/xml/data_extraction_rules.xml"))
        listOf("cloud-backup", "device-transfer").forEach { tag ->
            verifyExclusions(extraction.getElementsByTagName(tag).item(0) as org.w3c.dom.Element)
        }
        println("PASS: merged manifest contains only approved camera/authentication/internal receiver permissions; backup and both transfer policies exclude all app domains.")
    }
}
