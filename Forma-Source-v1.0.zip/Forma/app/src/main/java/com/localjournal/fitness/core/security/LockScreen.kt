package com.localjournal.fitness.core.security

import androidx.compose.material.icons.Icons
import com.localjournal.fitness.core.design.icons.PhotoLibrary
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.Modifier
import com.localjournal.fitness.core.design.*

@Composable fun LockScreen(state: AccessState, available: Boolean, opening: Boolean,
    onUnlock: () -> Unit, onSecuritySettings: () -> Unit) {
    Box(Modifier.fillMaxSize().safeDrawingPadding().padding(JournalSpacing.section), contentAlignment = Alignment.Center) {
        Column(Modifier.verticalScroll(rememberScrollState()), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Outlined.PhotoLibrary, null, Modifier.size(JournalSpacing.large), tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(JournalSpacing.standard))
            Text(androidx.compose.ui.res.stringResource(com.localjournal.fitness.R.string.app_name), style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(JournalSpacing.small))
            Text(if (opening || !state.ready) "Opening private journal…" else if (state.purpose != null || state.busy)
                "Complete device authentication to continue." else "Unlock to open your private journal.",
                style = MaterialTheme.typography.bodyLarge, textAlign = TextAlign.Center)
            state.message?.let { Spacer(Modifier.height(JournalSpacing.standard)); Text(it, style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Center) }
            if (state.ready && !opening && state.purpose == null && !state.busy) {
                Spacer(Modifier.height(JournalSpacing.section))
                JournalPrimaryButton(onClick = onUnlock, enabled = available) { Text("Unlock") }
                if (!available) Text("Device authentication is not configured or is currently unavailable.", style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Center)
                JournalTertiaryButton(onClick = onSecuritySettings) { Text("Android security settings") }
            }
        }
    }
}
