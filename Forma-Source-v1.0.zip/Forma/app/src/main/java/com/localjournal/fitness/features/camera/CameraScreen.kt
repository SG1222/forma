package com.localjournal.fitness.features.camera

import android.Manifest
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.ui.graphics.graphicsLayer
import android.content.pm.PackageManager
import android.content.Intent
import androidx.core.net.toUri
import android.provider.Settings
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import android.view.Surface
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.*
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.localjournal.fitness.DraftState
import com.localjournal.fitness.core.design.*

@Composable fun CameraScreen(state: DraftState, onCapture: (ImageCapture) -> Unit,
    onClose: () -> Unit, onContinue: () -> Unit, onImport: () -> Unit) {
    val shutterScale by animateFloatAsState(if (state.busy) .94f else 1f, tween(JournalMotion.pressMillis), label = "Shutter feedback")
    val context = LocalContext.current
    val lifecycle = LocalLifecycleOwner.current
    var granted by remember { mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) }
    var requested by rememberSaveable { mutableStateOf(false) }
    var denied by rememberSaveable { mutableStateOf(false) }
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it; denied = !it }
    DisposableEffect(lifecycle) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) granted = ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        }
        lifecycle.lifecycle.addObserver(observer)
        onDispose { lifecycle.lifecycle.removeObserver(observer) }
    }
    LaunchedEffect(Unit) { if (!granted && !requested) { requested = true; permission.launch(Manifest.permission.CAMERA) } }
    BackHandler { if (!state.busy) onClose() }
    if (!granted) {
        Column(Modifier.fillMaxSize().safeDrawingPadding().verticalScroll(rememberScrollState()).padding(JournalSpacing.standard)) {
            Text("Camera access", style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(JournalSpacing.standard))
            Text("Allow camera access to take photographs inside your private journal. You can also import local photographs.")
            TextButton(onClick = { permission.launch(Manifest.permission.CAMERA) }) { Text("Allow camera") }
            if (denied) TextButton(onClick = {
                context.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, "package:${context.packageName}".toUri()))
            }) { Text("Open Android settings") }
            TextButton(onClick = onImport) { Text("Import Photos") }
            TextButton(onClick = onClose) { Text("Back to Log") }
        }
        return
    }
    var lens by rememberSaveable { mutableIntStateOf(CameraSelector.LENS_FACING_BACK) }
    var flash by rememberSaveable { mutableIntStateOf(ImageCapture.FLASH_MODE_OFF) }
    var ready by remember { mutableStateOf(false) }
    var hasFlash by remember { mutableStateOf(false) }
    var canSwitch by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var reload by remember { mutableIntStateOf(0) }
    val previewView = remember(context) { PreviewView(context).apply {
        implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        scaleType = PreviewView.ScaleType.FIT_CENTER
    } }
    val capture = remember(context) {
        ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
            .setResolutionSelector(ResolutionSelector.Builder()
                .setResolutionStrategy(ResolutionStrategy.HIGHEST_AVAILABLE_STRATEGY).build()).build()
    }
    DisposableEffect(lifecycle, lens, granted, reload) {
        ready = false; error = null
        val preview = Preview.Builder().build().also { it.surfaceProvider = previewView.surfaceProvider }
        var disposed = false
        var provider: ProcessCameraProvider? = null
        val future = ProcessCameraProvider.getInstance(context)
        future.addListener({
            if (!disposed) {
                try {
                    val service = future.get(); provider = service
                    val selector = CameraSelector.Builder().requireLensFacing(lens).build()
                    if (!service.hasCamera(selector)) throw IllegalStateException("Camera unavailable")
                    capture.targetRotation = previewView.display?.rotation ?: Surface.ROTATION_0
                    val camera = service.bindToLifecycle(lifecycle, selector, preview, capture)
                    hasFlash = camera.cameraInfo.hasFlashUnit()
                    canSwitch = service.hasCamera(CameraSelector.DEFAULT_FRONT_CAMERA) && service.hasCamera(CameraSelector.DEFAULT_BACK_CAMERA)
                    ready = true
                } catch (_: Exception) { error = "The camera could not be opened. Try again or import photographs instead." }
            }
        }, ContextCompat.getMainExecutor(context))
        onDispose { disposed = true; ready = false; provider?.unbind(preview, capture) }
    }
    SideEffect { capture.flashMode = if (hasFlash) flash else ImageCapture.FLASH_MODE_OFF }
    Box(Modifier.fillMaxSize().background(JournalColors.comparisonCanvas)) {
        AndroidView(factory = { previewView }, modifier = Modifier.fillMaxSize(),
            update = { capture.targetRotation = it.display?.rotation ?: Surface.ROTATION_0 })
        Column(Modifier.fillMaxSize().safeDrawingPadding()) {
            Row(Modifier.fillMaxWidth().background(JournalColors.comparisonCanvas), verticalAlignment = Alignment.CenterVertically) {
                JournalFloatingIconButton(onClose, Icons.Outlined.Close, "Close camera", Modifier.padding(JournalSpacing.tiny), enabled = !state.busy)
                Spacer(Modifier.weight(1f))
                TextButton(onClick = { flash = when (flash) {
                    ImageCapture.FLASH_MODE_OFF -> ImageCapture.FLASH_MODE_AUTO
                    ImageCapture.FLASH_MODE_AUTO -> ImageCapture.FLASH_MODE_ON
                    else -> ImageCapture.FLASH_MODE_OFF
                } }, enabled = ready && hasFlash && !state.busy) {
                    Text(if (!hasFlash) "Flash unavailable" else "Flash: ${when(flash) {
                        ImageCapture.FLASH_MODE_ON -> "On"; ImageCapture.FLASH_MODE_AUTO -> "Auto"; else -> "Off"
                    }}", color = if (hasFlash) Color.White else Color.LightGray)
                }
            }
            Spacer(Modifier.weight(1f))
            if (!ready && error == null) Text("Opening camera…", color = Color.White, modifier = Modifier.padding(JournalSpacing.standard))
            (error ?: state.error)?.let { message ->
                Column(Modifier.fillMaxWidth().background(JournalColors.comparisonCanvas).padding(JournalSpacing.standard)) {
                    Text(message, color = Color.White)
                    Row {
                        if (error != null) TextButton(onClick = { reload++ }) { Text("Try again") }
                        TextButton(onClick = onImport, enabled = !state.busy) { Text("Import Photos") }
                    }
                }
            }
            Row(Modifier.fillMaxWidth().background(JournalColors.comparisonCanvas)
                .padding(JournalSpacing.standard), verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween) {
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    val last = state.session?.photos?.lastOrNull()
                    if (last != null) PrivateImage(state.session?.previewFiles?.get(last.id), "Last captured photograph", Modifier.size(48.dp))
                    val count = state.session?.photos?.size ?: 0
                    Text(if (state.busy) "Saving…" else "$count ${if (count == 1) "photo" else "photos"}", color = Color.White, style = MaterialTheme.typography.bodyMedium)
                }
                Button(onClick = {
                    capture.targetRotation = previewView.display?.rotation ?: Surface.ROTATION_0
                    onCapture(capture)
                }, enabled = ready && !state.busy && state.session != null,
                    modifier = Modifier.size(76.dp).graphicsLayer { scaleX = shutterScale; scaleY = shutterScale }.border(2.dp, Color.White, CircleShape).testTag("shutter").semantics { contentDescription = "Take photograph" },
                    shape = CircleShape, contentPadding = PaddingValues(6.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent, disabledContainerColor = Color.Transparent)) {
                    androidx.compose.foundation.Canvas(Modifier.fillMaxSize().testTag("shutter-face")) {
                        drawCircle(if (state.busy) Color.Gray else Color.White)
                    }
                    // An explicit accessible name is set on the button below through semantics.
                }
                TextButton(onClick = onContinue, enabled = !state.busy && !state.session?.photos.isNullOrEmpty(), modifier = Modifier.weight(1f)) {
                    Text("Continue", color = if (!state.session?.photos.isNullOrEmpty()) Color.White else Color.Gray)
                }
            }
            JournalSecondaryButton(onClick = { lens = if (lens == CameraSelector.LENS_FACING_BACK) CameraSelector.LENS_FACING_FRONT else CameraSelector.LENS_FACING_BACK },
                enabled = canSwitch && ready && !state.busy, modifier = Modifier.align(Alignment.CenterHorizontally)) {
                Text("Switch camera", color = if (canSwitch) Color.White else Color.Gray)
            }
        }
    }
}
