package com.localjournal.fitness.data.database

import androidx.room.*
import com.localjournal.fitness.data.models.*
import kotlinx.coroutines.flow.Flow
import java.time.Instant
import java.time.LocalDate

@Entity(tableName = "check_ins", indices = [Index("checkInDate"), Index("createdAt")])
data class CheckInEntity(@PrimaryKey val id: String, val createdAt: Instant,
                         val checkInDate: LocalDate, val note: String?)

@Entity(tableName = "photos", foreignKeys = [ForeignKey(entity = CheckInEntity::class,
    parentColumns = ["id"], childColumns = ["checkInId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("checkInId"), Index(value = ["checkInId", "sortOrder"], unique = true),
               Index(value = ["originalFilePath"], unique = true)])
data class PhotoEntity(@PrimaryKey val id: String, val checkInId: String,
    val originalFilePath: String, val thumbnailFilePath: String?, val label: PhotoLabel?,
    val source: PhotoSource, val originalCaptureDate: Instant?, val sortOrder: Int)

data class CheckInWithPhotos(@Embedded val checkIn: CheckInEntity,
    @Relation(parentColumn = "id", entityColumn = "checkInId") val photos: List<PhotoEntity>) {
    fun toModel() = CheckIn(checkIn.id, checkIn.createdAt, checkIn.checkInDate, checkIn.note,
        photos.sortedBy { it.sortOrder }.map { Photo(it.id, it.checkInId, it.originalFilePath,
            it.thumbnailFilePath, it.label, it.source, it.originalCaptureDate, it.sortOrder) })
}

class JournalConverters {
    @TypeConverter fun instant(value: Long?): Instant? = value?.let(Instant::ofEpochMilli)
    @TypeConverter fun epoch(value: Instant?): Long? = value?.toEpochMilli()
    @TypeConverter fun date(value: String?): LocalDate? = value?.let(LocalDate::parse)
    @TypeConverter fun iso(value: LocalDate?): String? = value?.toString()
    @TypeConverter fun label(value: String?): PhotoLabel? = value?.let(PhotoLabel::valueOf)
    @TypeConverter fun labelName(value: PhotoLabel?): String? = value?.name
    @TypeConverter fun source(value: String): PhotoSource = PhotoSource.valueOf(value)
    @TypeConverter fun sourceName(value: PhotoSource): String = value.name
}

@Dao
interface JournalDao {
    @Query("SELECT COUNT(*) FROM photos") suspend fun totalPhotoCount(): Int
    @Query("SELECT checkInDate, COUNT(*) AS count FROM check_ins GROUP BY checkInDate ORDER BY checkInDate")
    fun observeCheckInDays(): Flow<List<CheckInDay>>
    @Transaction @Query("SELECT * FROM check_ins ORDER BY createdAt DESC, id DESC")
    fun observeCheckIns(): Flow<List<CheckInWithPhotos>>
    @Transaction @Query("SELECT * FROM check_ins WHERE id = :id")
    suspend fun checkIn(id: String): CheckInWithPhotos?
    @Query("SELECT * FROM photos WHERE id = :id") suspend fun photo(id: String): PhotoEntity?
    @Query("UPDATE check_ins SET note = :note WHERE id = :id") suspend fun updateNote(id: String, note: String?)
    @Query("UPDATE photos SET label = :label WHERE id = :id") suspend fun updateLabel(id: String, label: PhotoLabel?)
    @Query("DELETE FROM photos WHERE id = :id") suspend fun deletePhoto(id: String)
    @Query("SELECT COUNT(*) FROM photos WHERE checkInId = :id") suspend fun photoCount(id: String): Int
    @Query("SELECT * FROM photos") suspend fun allPhotos(): List<PhotoEntity>
    @Query("UPDATE photos SET thumbnailFilePath = :path WHERE id = :id")
    suspend fun updateThumbnailPath(id: String, path: String)
    @Insert suspend fun insertCheckIn(checkIn: CheckInEntity)
    @Insert suspend fun insertPhotos(photos: List<PhotoEntity>)
    @Query("DELETE FROM check_ins WHERE id = :id") suspend fun deleteCheckIn(id: String)
}

@Database(entities = [CheckInEntity::class, PhotoEntity::class], version = 1, exportSchema = true)
@TypeConverters(JournalConverters::class)
abstract class JournalDatabase : RoomDatabase() { abstract fun journalDao(): JournalDao }
