package com.localjournal.fitness

import android.content.ContentResolver
import android.net.Uri
import androidx.camera.core.ImageCapture
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.localjournal.fitness.core.storage.*
import com.localjournal.fitness.data.models.*
import com.localjournal.fitness.data.preferences.*
import com.localjournal.fitness.data.repositories.JournalRepository
import com.localjournal.fitness.features.camera.CameraCaptureController
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.*
import java.io.IOException

sealed interface FoundationState {
    data object Loading : FoundationState
    data object Ready : FoundationState
    data class Error(val message: String) : FoundationState
}
data class LibraryState(val entries: List<CheckIn> = emptyList(),
    val assets: Map<String, PhotoAssets> = emptyMap(), val loaded: Boolean = false)
data class DraftState(val session: DraftSession? = null, val busy: Boolean = false,
    val error: String? = null, val completed: Boolean = false, val id: String? = session?.id,
    val importProgress: Int = 0, val importTotal: Int = 0)

class JournalViewModel(private val repository: JournalRepository,
    private val preferences: JournalPreferences,
    private val resolver: ContentResolver,
    private val camera: CameraCaptureController,
    localDates: Flow<java.time.LocalDate>,
    private val exporter: com.localjournal.fitness.core.export.PhotoExporter,
    private val maintenance: JournalMaintenance, private val application: android.app.Application) : ViewModel() {
    val exportDisclosureSeen = preferences.exportDisclosureSeen.catch { emit(false) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)
    private val mutableStorage = MutableStateFlow<com.localjournal.fitness.data.repositories.JournalStorageInfo?>(null)
    val storage = mutableStorage.asStateFlow()
    private val mutableStorageError = MutableStateFlow<String?>(null)
    val storageError = mutableStorageError.asStateFlow()
    private val mutableGeneration = MutableStateFlow(0)
    val generation = mutableGeneration.asStateFlow()
    private var storageJob: Job? = null
    fun refreshStorage() {
        storageJob?.cancel()
        mutableStorageError.value = null
        storageJob = viewModelScope.launch {
            try { mutableStorage.value = repository.storageInfo() }
            catch (error: Exception) { if (error is CancellationException) throw error; mutableStorage.value = null; mutableStorageError.value = "Journal storage could not be read. Try again." }
        }
    }
    fun exportPhoto(id: String) {
        if (mutableWorking.value) return
        mutableWorking.value = true
        enqueue("The photograph could not be exported. The private original is kept. Free up storage and try again.", busy = false,
            storageMessage = "Not enough storage to export. The private original is kept; free up space and try again.") {
            try {
                exporter.export(repository.originalForExport(id))
                runCatching { preferences.acknowledgeExportDisclosure() }
                mutableError.value = "Saved to Gallery"
            } finally { mutableWorking.value = false; refreshStorage() }
        }
    }
    fun deleteAllData() {
        if (mutableWorking.value) return
        mutableWorking.value = true
        enqueue("Deletion did not finish. Some private files may remain. Retry Delete all data to complete cleanup.", busy = false,
            storageMessage = "Deletion cleanup did not finish. Free up storage and retry Delete all data.") {
            try {
                libraryJob?.cancelAndJoin()
                maintenance.deleteAll()
                mutableLibrary.value = LibraryState(emptyList(), emptyMap(), true)
                coil3.SingletonImageLoader.get(application).memoryCache?.clear()
                mutableDraft.value = DraftState()
                mutableRecoverable.value = emptyMap()
                mutableGeneration.update { it + 1 }
                mutableState.value = FoundationState.Ready
            } finally { startLibrary(); mutableWorking.value = false; refreshStorage() }
        }
    }
    private val streakRetry = MutableStateFlow(0)
    @OptIn(ExperimentalCoroutinesApi::class)
    val streaks = streakRetry.flatMapLatest {
        combine(repository.checkInDays, localDates) { days, today ->
            com.localjournal.fitness.features.streaks.StreaksState(today,
                com.localjournal.fitness.features.streaks.calculateWeeklyStreaksByDay(days, today))
        }.catch { error ->
            if (error is CancellationException) throw error
            emit(com.localjournal.fitness.features.streaks.StreaksState(error = "Check-in statistics could not be loaded. Try again."))
        }
    }.flowOn(Dispatchers.Default).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000),
        com.localjournal.fitness.features.streaks.StreaksState())
    fun retryStreaks() { streakRetry.update { it + 1 } }
    val theme = preferences.themeMode.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), ThemeMode.SYSTEM)
    private val mutableState = MutableStateFlow<FoundationState>(FoundationState.Loading)
    val state = mutableState.asStateFlow()
    private val mutableLibrary = MutableStateFlow(LibraryState())
    val library = mutableLibrary.asStateFlow()
    private val mutableDraft = MutableStateFlow(DraftState())
    val draft = mutableDraft.asStateFlow()
    private val mutableRecoverable = MutableStateFlow<Map<String, Int>>(emptyMap())
    val recoverable = mutableRecoverable.asStateFlow()
    private val mutableError = MutableStateFlow<String?>(null)
    val error = mutableError.asStateFlow()
    private val mutableWorking = MutableStateFlow(false)
    val working = mutableWorking.asStateFlow()
    // Serialize review edits with save/removal. The final keystroke cannot overtake a save.
    private val actions = Channel<suspend () -> Unit>(Channel.UNLIMITED)
    private var initialization: Job? = null
    private var libraryJob: Job? = null
    private var libraryFailure: String? = null
    private fun startLibrary() {
        libraryJob = viewModelScope.launch {
            repository.checkIns.map { entries ->
                LibraryState(entries, repository.photoAssets(entries.flatMap { it.photos }), true)
            }.catch { error ->
                if (error is CancellationException) throw error
                libraryFailure = "The journal could not be loaded. Try again; saved photographs are kept."
                mutableLibrary.update { it.copy(loaded = true) }
                mutableState.value = FoundationState.Error(libraryFailure!!)
            }.collect { library ->
                libraryFailure = null
                mutableLibrary.value = library
                refreshStorage()
            }
        }
    }
    init {
        startLibrary()
        viewModelScope.launch { for (action in actions) action() }
        retry()
    }
    private fun enqueue(message: String, busy: Boolean = true, storageMessage: String? = null, action: suspend () -> Unit) {
        if (busy && mutableDraft.value.busy) return
        if (busy) mutableDraft.update { it.copy(busy = true, error = null) }
        actions.trySend {
            try { action() }
            catch (error: Exception) {
                if (error is CancellationException) throw error
                val text = if (generateSequence<Throwable>(error) { it.cause }.any {
                    it is android.database.sqlite.SQLiteFullException || it.message?.contains("ENOSPC", true) == true ||
                        it.message?.contains("No space left", true) == true
                }) storageMessage ?: "Not enough device storage. Free up space and try again. Your unfinished check-in is kept."
                else message
                mutableDraft.update { it.copy(error = text) }
                mutableError.value = text
            } finally { if (busy) mutableDraft.update { it.copy(busy = false) } }
        }
    }
    private suspend fun refreshDrafts() {
        refreshStorage()
        mutableRecoverable.value = repository.recoverDrafts().mapValues { it.value.size }
    }
    fun clearError() { mutableError.value = null }
    fun retry() {
        if (initialization?.isActive == true) return
        if (libraryJob?.isCompleted == true) { libraryFailure = null; startLibrary() }
        initialization = viewModelScope.launch {
            mutableState.value = FoundationState.Loading
            try {
                val exportsRecovered = maintenance.recover()
                val report = repository.reconcile()
                refreshDrafts()
                mutableState.value = libraryFailure?.let { FoundationState.Error(it) } ?: FoundationState.Ready
                if (!exportsRecovered) mutableError.value = "An unfinished gallery copy could not be cleaned up. Your private journal is available; reopen the app to retry cleanup."
                if (report.missingOriginalIds.isNotEmpty() || report.unreadableThumbnailIds.isNotEmpty()) {
                    mutableError.value = "Some photographs or previews could not be opened. Their journal records have been kept."
                }
            } catch (error: Exception) {
                if (error is CancellationException) throw error
                mutableState.value = FoundationState.Error("Private journal storage could not be opened. Free up device storage and try again.")
            }
        }
    }
    fun setTheme(mode: ThemeMode) { viewModelScope.launch {
        try { preferences.setThemeMode(mode) }
        catch (_: IOException) { mutableError.value = "The appearance preference could not be saved. Free up device storage and try again." }
    } }
    fun createDraft(onReady: (String) -> Unit) = enqueue("An unfinished check-in could not be created. Free up storage and try again.") {
        val id = repository.createDraft()
        mutableDraft.value = DraftState(repository.loadDraft(id), busy = true)
        refreshDrafts()
        onReady(id)
    }
    fun openDraft(id: String) {
        if (mutableDraft.value.session?.id == id || mutableDraft.value.busy) return
        mutableDraft.value = DraftState(id = id)
        enqueue("This unfinished check-in could not be opened. Close this screen and try again.") {
            val session = repository.loadDraft(id)
            mutableDraft.value = DraftState(session, busy = true, completed = session == null, id = id)
        }
    }
    fun updateReview(note: String, photoId: String? = null, label: PhotoLabel? = null) {
        val session = mutableDraft.value.session ?: return
        if (mutableDraft.value.busy) return
        val next = session.copy(note = note, photos = session.photos.map {
            if (it.id == photoId) it.copy(label = label) else it
        })
        mutableDraft.update { it.copy(session = next) }
        enqueue("The latest review changes could not be kept. Try editing again before saving.", busy = false) {
            repository.updateDraft(next.id, next.note, next.photos.associate { it.id to it.label })
        }
    }
    fun removeDraftPhoto(photoId: String) = enqueue("The photograph could not be removed. Your draft is still here.") {
        val id = mutableDraft.value.session?.id ?: return@enqueue
        repository.removeDraftPhoto(id, photoId)
        mutableDraft.update { it.copy(session = repository.loadDraft(id)) }
        refreshDrafts()
    }
    fun saveDraft() = enqueue("Could not save this check-in. Your photographs and note are still here; try again.") {
        val session = mutableDraft.value.session ?: return@enqueue
        repository.updateDraft(session.id, session.note, session.photos.associate { it.id to it.label })
        repository.commitDraft(session.id, session.photos.map { it.id }, session.note.takeIf { it.isNotBlank() })
        mutableDraft.update { it.copy(completed = true) }
        refreshDrafts()
    }
    fun discardDraft(onDone: () -> Unit) = enqueue("The unfinished check-in could not be discarded. Try again.") {
        mutableDraft.value.id?.let { repository.discardDraft(it) }
        mutableDraft.value = DraftState(busy = true)
        refreshDrafts()
        onDone()
    }
    fun capture(id: String, imageCapture: ImageCapture) = enqueue("The camera could not save this photograph. Earlier photographs are kept; try the shutter again.") {
        camera.capture(id, imageCapture)
        mutableDraft.update { it.copy(session = repository.loadDraft(id)) }
        refreshDrafts()
    }
    fun importPhotos(existingId: String?, uris: List<Uri>, onReady: (String) -> Unit) {
        if (uris.isEmpty()) return
        enqueue("The selected photographs could not be copied. Your existing draft is kept; try selecting local images again.") {
            val id = existingId ?: repository.createDraft()
            mutableDraft.value = DraftState(repository.loadDraft(id), busy = true, importTotal = uris.size)
            onReady(id)
            var failed = 0
            for ((index, uri) in uris.withIndex()) {
                try {
                    withContext(Dispatchers.IO) {
                        val input = resolver.openInputStream(uri) ?: throw IOException("The selected photograph could not be opened.")
                        repository.stagePhoto(id, PhotoSource.IMPORT, input)
                    }
                } catch (error: Exception) { if (error is CancellationException) throw error; failed++ }
                mutableDraft.update { it.copy(importProgress = index + 1) }
            }
            val error = if (failed == 0) null else "$failed photograph(s) could not be imported. Other photographs are kept. Free up storage or select readable local images and try again."
            mutableDraft.value = DraftState(repository.loadDraft(id), busy = true, error = error)
            refreshDrafts()
        }
    }
    fun editPhoto(photoId: String, note: String, label: PhotoLabel?, onDone: () -> Unit) {
        if (mutableWorking.value) return
        mutableWorking.value = true
        enqueue("Changes could not be saved. The original photograph is unchanged.", busy = false) {
            try { repository.editPhoto(photoId, note, label); onDone() }
            finally { mutableWorking.value = false }
        }
    }
    fun deletePhoto(photoId: String, onDone: () -> Unit) {
        if (mutableWorking.value) return
        mutableWorking.value = true
        enqueue("The photograph could not be fully removed. Close and reopen the journal to retry private file cleanup.", busy = false) {
            try { repository.deletePhoto(photoId); onDone() }
            finally { mutableWorking.value = false }
        }
    }
    fun pickerUnavailable() { mutableError.value = "The system photo picker could not be opened. Try again or take a photograph instead." }
}
