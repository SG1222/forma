package com.localjournal.fitness.core.design

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.localjournal.fitness.data.preferences.ThemeMode

object JournalSpacing {
    val tiny = 4.dp; val small = 8.dp; val compact = 12.dp
    val standard = 16.dp; val section = 24.dp; val large = 32.dp
    val gridGutter = 2.dp; val touchTarget = 48.dp; val icon = 24.dp
}
object JournalCalendarStyle {
    val maximumWidth = 600.dp
    val dayHeight = 56.dp
    val dateMinimumSize = 32.dp
    val dotSize = 4.dp
    const val selectionOpacity = 0.10f
}
object JournalDockStyle {
    val horizontalMargin = 20.dp
    val bottomGap = 14.dp
    val elevation = 4.dp
    val contentPadding = 6.dp
    val itemHeight = 60.dp
    const val surfaceOpacity = 0.94f
    const val selectedOpacity = 0.10f
    const val animationMillis = 180
}
object JournalCorners {
    val dock = RoundedCornerShape(50)
    val photo = RoundedCornerShape(0.dp)
    val control = RoundedCornerShape(14.dp)
    val dialog = RoundedCornerShape(24.dp)
    val button = RoundedCornerShape(20.dp)
    val segmented = RoundedCornerShape(50)
}
object JournalColors {
    val comparisonCanvas = Color(0xFF101114)
    val darkDockSurface = Color(0xFF292F2D)
}
internal val JournalLightColors = lightColorScheme(
    primary = Color(0xFF3B7372), onPrimary = Color.White,
    background = Color(0xFFF4EDE3), onBackground = Color(0xFF352C27),
    surface = Color(0xFFFAF6F0), onSurface = Color(0xFF352C27),
    onSurfaceVariant = Color(0xFF6D6056), outlineVariant = Color(0xFFD9CFC2),
    error = Color(0xFFA63129), onError = Color.White,
    secondary = Color(0xFF3B7372), onSecondary = Color.White,
    secondaryContainer = Color(0xFFDCE9E3), onSecondaryContainer = Color(0xFF244B47),
    primaryContainer = Color(0xFFDCE9E3), onPrimaryContainer = Color(0xFF244B47),
    surfaceVariant = Color(0xFFEAE0D3), outline = Color(0xFF82766B), surfaceTint = Color.Transparent,
    surfaceContainerLowest = Color(0xFFFFFBF6), surfaceContainerLow = Color(0xFFFAF6F0),
    surfaceContainer = Color(0xFFF0E7DB), surfaceContainerHigh = Color(0xFFEAE0D3),
    surfaceContainerHighest = Color(0xFFE2D6C7), surfaceBright = Color(0xFFFAF6F0), surfaceDim = Color(0xFFE5DACC))
internal val JournalDarkColors = darkColorScheme(
    primary = Color(0xFFA5D1C9), onPrimary = Color(0xFF163B37),
    background = Color(0xFF171C1B), onBackground = Color(0xFFEDE8E1),
    surface = Color(0xFF1E2523), onSurface = Color(0xFFEDE8E1),
    onSurfaceVariant = Color(0xFFB6BDB8), outlineVariant = Color(0xFF3F4945),
    error = Color(0xFFFFB4AB), onError = Color(0xFF5F1410),
    secondary = Color(0xFFA5D1C9), onSecondary = Color(0xFF163B37),
    secondaryContainer = Color(0xFF304C46), onSecondaryContainer = Color(0xFFD0E7DF),
    primaryContainer = Color(0xFF304C46), onPrimaryContainer = Color(0xFFD0E7DF),
    surfaceVariant = Color(0xFF303936), outline = Color(0xFF89958E), surfaceTint = Color.Transparent,
    surfaceContainerLowest = Color(0xFF101513), surfaceContainerLow = Color(0xFF1B2220),
    surfaceContainer = Color(0xFF242D29), surfaceContainerHigh = Color(0xFF2B3530),
    surfaceContainerHighest = Color(0xFF36423C), surfaceBright = Color(0xFF3B4741), surfaceDim = Color(0xFF171C1B))
object JournalActionStyle {
    val primaryHeight = 52.dp
    val pressedAccent = Color(0xFF2E6260)
    const val disabledOpacity = 0.38f
    const val materialOpacity = 0.94f
}
private fun type(size: Int, line: Int, weight: FontWeight = FontWeight.Normal) = TextStyle(
    fontFamily = FontFamily.SansSerif, fontSize = size.sp, lineHeight = line.sp, fontWeight = weight)
private val journalTypography = Typography(
    headlineLarge = type(34, 40, FontWeight.SemiBold),
    headlineMedium = type(28, 34, FontWeight.SemiBold),
    titleLarge = type(20, 26, FontWeight.SemiBold),
    titleMedium = type(17, 24, FontWeight.SemiBold),
    bodyLarge = type(16, 24), bodyMedium = type(14, 21),
    labelLarge = type(14, 20, FontWeight.SemiBold), labelMedium = type(12, 16),
    displayMedium = type(44, 50, FontWeight.SemiBold))

@Composable fun JournalTheme(mode: ThemeMode = ThemeMode.SYSTEM, content: @Composable () -> Unit) {
    val isDark = when (mode) { ThemeMode.SYSTEM -> isSystemInDarkTheme(); ThemeMode.DARK -> true; ThemeMode.LIGHT -> false }
    MaterialTheme(colorScheme = if (isDark) JournalDarkColors else JournalLightColors, typography = journalTypography,
        shapes = Shapes(extraSmall = JournalCorners.control, small = JournalCorners.control,
                        medium = JournalCorners.control, large = JournalCorners.dialog, extraLarge = JournalCorners.dialog), content = content)
}
