package com.localjournal.fitness

import android.app.Application
import android.content.Context
import coil3.ImageLoader
import coil3.SingletonImageLoader
import com.localjournal.fitness.features.camera.CameraCaptureController
import androidx.room.Room
import com.localjournal.fitness.core.storage.PrivatePhotoStore
import com.localjournal.fitness.data.database.JournalDatabase
import com.localjournal.fitness.data.preferences.JournalPreferences
import com.localjournal.fitness.data.repositories.JournalRepository
import com.localjournal.fitness.data.repositories.LocalJournalRepository

class JournalApplication : Application(), SingletonImageLoader.Factory {
    override fun newImageLoader(context: Context) = ImageLoader.Builder(context).diskCache(null).build()
    val session by lazy { com.localjournal.fitness.core.security.AuthenticationSession(preferences) }
    val exporter by lazy { com.localjournal.fitness.core.export.PhotoExporter(contentResolver, java.io.File(filesDir, "export_jobs"), packageName) }
    val maintenance by lazy { com.localjournal.fitness.core.storage.JournalMaintenance(repository, preferences, exporter) }
    val localDates get() = com.localjournal.fitness.core.utilities.observeLocalDates(this)
    val camera by lazy { CameraCaptureController(this, repository) }
    // Manual application-scoped dependency graph; no service framework or hidden global activity state.
    val database by lazy { Room.databaseBuilder(this, JournalDatabase::class.java, "journal.db").build() }
    val repository: JournalRepository by lazy { LocalJournalRepository(database, PrivatePhotoStore(filesDir)) }
    val preferences by lazy { JournalPreferences(this) }
}
