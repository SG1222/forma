package com.localjournal.fitness.core.security

enum class AuthenticationPurpose { UNLOCK, ENABLE_LOCK, DISABLE_LOCK }
data class AccessState(val ready: Boolean = false, val enabled: Boolean = false, val authorized: Boolean = false,
    val foreground: Boolean = false, val purpose: AuthenticationPurpose? = null, val busy: Boolean = false,
    val message: String? = null) {
    val canShowPrivate get() = ready && foreground && (!enabled || authorized) && purpose == null && !busy
}

/** Process-memory authorization. Never save this in a Bundle, preference or database. */
class SessionPolicy(private val elapsed: () -> Long) {
    var state = AccessState(); private set
    private var backgroundAt: Long? = null
    fun configure(enabled: Boolean) {
        state = state.copy(ready = true, enabled = enabled,
            authorized = if (!enabled) true else if (!state.ready || !state.enabled) false else state.authorized)
    }
    fun resume() {
        val expired = backgroundAt?.let { elapsed() - it > 30_000L || elapsed() < it } ?: false
        state = state.copy(foreground = true, authorized = state.authorized && !expired)
        backgroundAt = null
    }
    fun pause() {
        if (backgroundAt == null) backgroundAt = elapsed()
        state = state.copy(foreground = false)
    }
    fun configurationChange() { backgroundAt = null }
    fun begin(purpose: AuthenticationPurpose): Boolean {
        if (!state.ready || state.busy || state.purpose != null) return false
        state = state.copy(purpose = purpose, authorized = false, message = null)
        return true
    }
    fun busy(value: Boolean) { state = state.copy(busy = value) }
    fun authenticated() {
        state = state.copy(authorized = true, purpose = null, busy = false, message = null)
        backgroundAt = null
    }
    fun failed(message: String, terminal: Boolean) {
        state = state.copy(message = message, purpose = if (terminal) null else state.purpose, busy = false)
    }
    fun preferencesUnavailable() { state = state.copy(ready = false, authorized = false, message = "Privacy settings could not be loaded. Free up storage and reopen the app.") }
}
