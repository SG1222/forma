package com.localjournal.fitness.features.viewer

import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.rememberTransformableState
import androidx.compose.foundation.gestures.transformable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.*
import androidx.compose.ui.text.style.TextAlign
import com.localjournal.fitness.core.design.JournalSpacing
import coil3.compose.AsyncImage
import java.io.File

@Composable fun ZoomablePhoto(file: File?, active: Boolean, onTap: () -> Unit, onZoom: (Boolean) -> Unit) {
    var zoom by remember(file) { mutableFloatStateOf(1f) }
    var offset by remember(file) { mutableStateOf(Offset.Zero) }
    var viewport by remember { mutableStateOf(Size.Zero) }
    var image by remember(file) { mutableStateOf(Size.Zero) }
    var failed by remember(file) { mutableStateOf(file == null) }
    val toggle by rememberUpdatedState(onTap)
    fun bounded(value: Offset, scale: Float): Offset {
        if (viewport.width == 0f || image.width <= 0f || image.height <= 0f) return Offset.Zero
        val fit = minOf(viewport.width / image.width, viewport.height / image.height)
        val x = maxOf(0f, (image.width * fit * scale - viewport.width) / 2)
        val y = maxOf(0f, (image.height * fit * scale - viewport.height) / 2)
        return Offset(value.x.coerceIn(-x, x), value.y.coerceIn(-y, y))
    }
    val transform = rememberTransformableState { scale, pan, _ ->
        val next = (zoom * scale).coerceIn(1f, 5f)
        offset = bounded(offset + pan, next)
        zoom = next
    }
    LaunchedEffect(active) { if (!active) { zoom = 1f; offset = Offset.Zero } }
    LaunchedEffect(zoom, active) { if (active) onZoom(zoom > 1.01f) }
    Box(Modifier.fillMaxSize().onSizeChanged {
        viewport = Size(it.width.toFloat(), it.height.toFloat())
        offset = bounded(offset, zoom)
    }
        .testTag(if (active) "zoom-photo-active" else "zoom-photo-inactive").semantics {
            contentDescription = if (failed) "Photograph unavailable. Return to Log or use More to remove it." else "Photograph. Pinch to zoom, drag to pan, double tap to zoom, tap to show or hide controls."
            stateDescription = if (zoom > 1.01f) "Zoomed" else "Fit to screen"
            customActions = listOf(CustomAccessibilityAction(if (zoom > 1.01f) "Reset zoom" else "Zoom in") {
                zoom = if (zoom > 1.01f) 1f else 2.5f; offset = Offset.Zero; true
            }, CustomAccessibilityAction("Show or hide controls") { toggle(); true })
        }
        .pointerInput(file) { detectTapGestures(onTap = { toggle() }, onDoubleTap = { point ->
            val next = if (zoom > 1.01f) 1f else 2.5f
            zoom = next
            offset = if (next == 1f) Offset.Zero else bounded((Offset(viewport.width / 2, viewport.height / 2) - point) * (next - 1), next)
        }) }
        .transformable(transform, canPan = { zoom > 1.01f }, lockRotationOnZoomPan = true),
        contentAlignment = Alignment.Center) {
        if (file != null) AsyncImage(model = file, contentDescription = null, contentScale = ContentScale.Fit,
            modifier = Modifier.fillMaxSize().graphicsLayer {
                scaleX = zoom; scaleY = zoom; translationX = offset.x; translationY = offset.y
            }, onSuccess = {
                val intrinsic = it.painter.intrinsicSize
                if (intrinsic.width > 0 && intrinsic.height > 0) image = intrinsic
                failed = false
            }, onError = { failed = true })
        if (failed) Text("This photograph could not be opened. Return to Log or remove it using More.",
            modifier = Modifier.padding(JournalSpacing.standard), color = Color.White, textAlign = TextAlign.Center)
    }
}
