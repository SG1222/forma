package com.localjournal.fitness.features.compare

import androidx.compose.runtime.*
import com.localjournal.fitness.core.design.JournalComparisonStyle
import androidx.compose.runtime.saveable.listSaver
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import com.localjournal.fitness.data.models.CheckIn
import com.localjournal.fitness.data.models.Photo
import java.time.LocalDate

/** Metadata only: comparison never owns or changes an original file. */
data class ComparisonPhoto(val photo: Photo, val date: LocalDate)
fun comparisonPhotos(entries: List<CheckIn>): List<ComparisonPhoto> = entries
    .sortedWith(compareByDescending<CheckIn> { it.createdAt }.thenBy { it.id })
    .flatMap { entry -> entry.photos.sortedBy { it.sortOrder }.map { ComparisonPhoto(it, entry.checkInDate) } }

fun suggestedComparison(current: Photo, entries: List<CheckIn>): String? {
    val label = current.label ?: return null
    return comparisonPhotos(entries).firstOrNull {
        it.photo.checkInId != current.checkInId && it.photo.label == label
    }?.photo?.id
}

enum class ComparisonMode { SIDE_BY_SIDE, SLIDER }
enum class AlignmentTarget { BOTH, A, B }
enum class PhotoSlot { A, B }

/** Translation uses fractions of the untransformed viewport, identically in both slider layers. */
data class PhotoTransform(val zoom: Float = 1f, val x: Float = 0f, val y: Float = 0f) {
    fun move(centroid: Offset, pan: Offset, factor: Float, viewport: Size, image: Size,
             alignment: Boolean): PhotoTransform {
        if (viewport.width <= 0f || viewport.height <= 0f || !factor.isFinite() || factor <= 0f) return this
        val next = (zoom * factor).coerceIn(1f, JournalComparisonStyle.maximumZoom)
        val ratio = next / zoom
        val cx = centroid.x / viewport.width - 0.5f
        val cy = centroid.y / viewport.height - 0.5f
        return PhotoTransform(next,
            cx + (x - cx) * ratio + pan.x / viewport.width,
            cy + (y - cy) * ratio + pan.y / viewport.height).bounded(viewport, image, alignment)
    }
    fun bounded(viewport: Size, image: Size, alignment: Boolean): PhotoTransform {
        if (viewport.width <= 0 || viewport.height <= 0 || image.width <= 0 || image.height <= 0) return copy(x = 0f, y = 0f)
        val fit = minOf(viewport.width / image.width, viewport.height / image.height)
        // Slider alignment may move a fitted image before zooming; keep part of it in view.
        val extra = if (alignment) 0.35f else 0f
        val limitX = maxOf(0f, (image.width * fit * zoom / viewport.width - 1) / 2) + extra
        val limitY = maxOf(0f, (image.height * fit * zoom / viewport.height - 1) / 2) + extra
        return copy(x = if (limitX == 0f) 0f else x.coerceIn(-limitX, limitX),
            y = if (limitY == 0f) 0f else y.coerceIn(-limitY, limitY))
    }
}

@Stable class ComparisonState {
    var firstId by mutableStateOf<String?>(null)
    var secondId by mutableStateOf<String?>(null)
    var mode by mutableStateOf(ComparisonMode.SIDE_BY_SIDE)
    var alignment by mutableStateOf(AlignmentTarget.BOTH)
    var divider by mutableFloatStateOf(0.5f)
    var sideA by mutableStateOf(PhotoTransform())
    var sideB by mutableStateOf(PhotoTransform())
    var sliderA by mutableStateOf(PhotoTransform())
    var sliderB by mutableStateOf(PhotoTransform())
    var initialized by mutableStateOf(false)
    var notice by mutableStateOf<String?>(null)

    fun choose(slot: PhotoSlot, id: String) {
        if (slot == PhotoSlot.A && firstId != id) { firstId = id; sideA = PhotoTransform(); sliderA = PhotoTransform() }
        if (slot == PhotoSlot.B && secondId != id) { secondId = id; sideB = PhotoTransform(); sliderB = PhotoTransform() }
        notice = null
    }
    fun reconcile(photos: List<ComparisonPhoto>) {
        val ids = photos.map { it.photo.id }.toSet()
        val missing = buildList {
            if (firstId != null && firstId !in ids) { firstId = null; sideA = PhotoTransform(); sliderA = PhotoTransform(); add("A") }
            if (secondId != null && secondId !in ids) { secondId = null; sideB = PhotoTransform(); sliderB = PhotoTransform(); add("B") }
        }
        if (missing.isNotEmpty()) notice = "Photo ${missing.joinToString(" and ")} was deleted. Choose another photograph."
        val a = photos.find { it.photo.id == firstId }; val b = photos.find { it.photo.id == secondId }
        if (a != null && b != null && a.photo.checkInId == b.photo.checkInId) {
            secondId = null; sideB = PhotoTransform(); sliderB = PhotoTransform()
            notice = "Choose photographs from two different check-ins."
        }
    }
    fun reset() {
        if (mode == ComparisonMode.SIDE_BY_SIDE) { sideA = PhotoTransform(); sideB = PhotoTransform() }
        else { sliderA = PhotoTransform(); sliderB = PhotoTransform() }
    }
    companion object {
        val Saver = listSaver<ComparisonState, Any>(save = { state ->
            buildList {
                add(state.firstId.orEmpty()); add(state.secondId.orEmpty()); add(state.mode.name)
                add(state.alignment.name); add(state.divider); add(state.initialized); add(state.notice.orEmpty())
                listOf(state.sideA, state.sideB, state.sliderA, state.sliderB).forEach { add(it.zoom); add(it.x); add(it.y) }
            }
        }, restore = { saved ->
            ComparisonState().apply {
                firstId = (saved[0] as String).ifEmpty { null }; secondId = (saved[1] as String).ifEmpty { null }
                mode = ComparisonMode.valueOf(saved[2] as String); alignment = AlignmentTarget.valueOf(saved[3] as String)
                divider = saved[4] as Float; initialized = saved[5] as Boolean; notice = (saved[6] as String).ifEmpty { null }
                fun transform(at: Int) = PhotoTransform(saved[at] as Float, saved[at+1] as Float, saved[at+2] as Float)
                sideA = transform(7); sideB = transform(10); sliderA = transform(13); sliderB = transform(16)
            }
        })
    }
}
