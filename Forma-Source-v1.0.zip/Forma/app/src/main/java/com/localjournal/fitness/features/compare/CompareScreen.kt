package com.localjournal.fitness.features.compare

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.window.DialogWindowProvider
import androidx.core.view.WindowCompat
import androidx.compose.ui.semantics.*
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.localjournal.fitness.LibraryState
import com.localjournal.fitness.core.design.*
import androidx.compose.ui.graphics.luminance
import com.localjournal.fitness.features.checkin.displayName
import java.time.format.DateTimeFormatter

@Composable fun CompareScreen(library: LibraryState, onLog: () -> Unit, initialPhotoId: String? = null,
    onClose: (() -> Unit)? = null) {
    val state = rememberSaveable(saver = ComparisonState.Saver) { ComparisonState() }
    val photos = remember(library.entries) { comparisonPhotos(library.entries) }
    var selecting by rememberSaveable { mutableStateOf<PhotoSlot?>(null) }
    LaunchedEffect(library.loaded, photos, initialPhotoId) {
        if (library.loaded) {
            if (!state.initialized) {
                state.initialized = true
                photos.find { it.photo.id == initialPhotoId }?.let {
                    state.firstId = it.photo.id
                    state.secondId = suggestedComparison(it.photo, library.entries)
                    if (state.secondId == null) state.notice = "Choose a photograph from another check-in."
                }
            }
            state.reconcile(photos)
        }
    }
    val first = photos.find { it.photo.id == state.firstId }
    val second = photos.find { it.photo.id == state.secondId }
    val enough = photos.map { it.photo.checkInId }.distinct().size >= 2
    CompositionLocalProvider(LocalContentColor provides MaterialTheme.colorScheme.onBackground) {
        Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)
            .then(if (onClose != null) Modifier.safeDrawingPadding() else Modifier)) {
            Row(Modifier.fillMaxWidth().padding(horizontal = JournalSpacing.small), verticalAlignment = Alignment.CenterVertically) {
                if (onClose != null) IconButton(onClick = onClose) {
                    Icon(Icons.AutoMirrored.Outlined.ArrowBack, "Back to photograph")
                }
                Text("Compare", style = MaterialTheme.typography.titleLarge,
                    modifier = Modifier.weight(1f).padding(horizontal = JournalSpacing.small, vertical = JournalSpacing.compact))
                if (first != null || second != null) JournalTertiaryButton(onClick = state::reset) { Text("Reset view") }
            }
            if (!library.loaded) {
                Text("Opening private library…", modifier = Modifier.padding(JournalSpacing.standard))
            } else if (!enough) {
                Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(JournalSpacing.standard)) {
                    Text("Compare photographs from different check-ins.", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(JournalSpacing.small))
                    Text("Add photographs to at least two check-ins to compare them.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    JournalTertiaryButton(onClick = onLog) { Text("Go to Log") }
                }
            } else {
                // Each date is also the change-selection action; no separate setup screen is needed.
                Row(Modifier.fillMaxWidth().padding(horizontal = JournalSpacing.small)) {
                    PhotoSelectionControl(PhotoSlot.A, first, Modifier.weight(1f)) { selecting = PhotoSlot.A }
                    PhotoSelectionControl(PhotoSlot.B, second, Modifier.weight(1f)) { selecting = PhotoSlot.B }
                }
                SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth().padding(horizontal = JournalSpacing.standard, vertical = JournalSpacing.small)) {
                    listOf(ComparisonMode.SIDE_BY_SIDE to "Side by Side", ComparisonMode.SLIDER to "Slider").forEachIndexed { index, (mode, title) ->
                        SegmentedButton(selected = state.mode == mode, onClick = { state.mode = mode },
                            shape = SegmentedButtonDefaults.itemShape(index, 2, JournalCorners.segmented),
                            colors = comparisonSegmentColors(state.mode == mode), icon = {}) { Text(title) }
                    }
                }
                state.notice?.let { Text(it, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(horizontal = JournalSpacing.standard)) }
                if (first != null && second != null) {
                    if (state.mode == ComparisonMode.SIDE_BY_SIDE) {
                        Row(Modifier.fillMaxWidth().weight(1f), horizontalArrangement = Arrangement.spacedBy(JournalSpacing.gridGutter)) {
                            ComparisonPane(library.assets[first.photo.id]?.original, PhotoSlot.A, { state.sideA },
                                { state.sideA = it }, Modifier.weight(1f).fillMaxHeight())
                            ComparisonPane(library.assets[second.photo.id]?.original, PhotoSlot.B, { state.sideB },
                                { state.sideB = it }, Modifier.weight(1f).fillMaxHeight())
                        }
                    } else {
                        SliderComparison(library.assets[first.photo.id]?.original, library.assets[second.photo.id]?.original,
                            state, Modifier.fillMaxWidth().weight(1f))
                        AlignmentControls(state)
                    }
                } else {
                    Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState())
                        .padding(JournalSpacing.standard), verticalArrangement = Arrangement.Center) {
                        Text("Choose ${if (first == null) "photo A" else "photo B"} above.",
                            style = MaterialTheme.typography.titleMedium)
                        Text("Each photograph must belong to a different check-in.", color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(top = JournalSpacing.small))
                    }
                }
            }
        }
        selecting?.let { slot ->
            val other = if (slot == PhotoSlot.A) second else first
            val selected = if (slot == PhotoSlot.A) first else second
            PhotoSelectionSheet(photos.filter { it.photo.checkInId != other?.photo?.checkInId }, library, slot, selected?.photo?.id,
                { selecting = null }, { state.choose(slot, it); selecting = null })
        }
    }
}

@Composable private fun PhotoSelectionControl(slot: PhotoSlot, photo: ComparisonPhoto?, modifier: Modifier,
    onClick: () -> Unit) {
    JournalTertiaryButton(onClick = onClick, modifier = modifier.testTag("select-${slot.name}")
        .semantics { contentDescription = "Change photo ${slot.name}" }) {
        Column(Modifier.fillMaxWidth()) {
            Text("Photo ${slot.name}" + (photo?.photo?.label?.let { " · ${it.displayName()}" } ?: ""),
                style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(photo?.date?.format(DateTimeFormatter.ofPattern("d MMM yyyy")) ?: "Choose photograph",
                style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable private fun AlignmentControls(state: ComparisonState) {
    var menu by remember { mutableStateOf(false) }
    Row(Modifier.fillMaxWidth().padding(horizontal = JournalSpacing.standard), verticalAlignment = Alignment.CenterVertically) {
        Box {
            JournalTertiaryButton(onClick = { menu = true }) {
                Text("Move: " + when (state.alignment) { AlignmentTarget.BOTH -> "Both"; AlignmentTarget.A -> "Photo A"; AlignmentTarget.B -> "Photo B" })
            }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                AlignmentTarget.entries.forEach { target ->
                    val title = when (target) { AlignmentTarget.BOTH -> "Both photographs"; AlignmentTarget.A -> "Photo A only"; AlignmentTarget.B -> "Photo B only" }
                    DropdownMenuItem(text = { Text(title) }, onClick = { state.alignment = target; menu = false })
                }
            }
        }
        Text("Pinch to zoom · Drag to align", color = MaterialTheme.colorScheme.onSurfaceVariant,
            style = MaterialTheme.typography.labelMedium, modifier = Modifier.weight(1f).padding(start = JournalSpacing.small))
    }
}

@Composable private fun PhotoSelectionSheet(photos: List<ComparisonPhoto>, library: LibraryState,
    slot: PhotoSlot, selectedId: String?, onClose: () -> Unit, onChoose: (String) -> Unit) {
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)) {
        val dialogView = LocalView.current
        val lightBars = MaterialTheme.colorScheme.background.luminance() > 0.5f
        SideEffect {
            val window = (dialogView.parent as? DialogWindowProvider)?.window
                ?: (dialogView as? DialogWindowProvider)?.window
            window?.let {
                WindowCompat.getInsetsController(it, dialogView).apply {
                    isAppearanceLightStatusBars = lightBars
                    isAppearanceLightNavigationBars = lightBars
                }
            }
        }
        BackHandler(onBack = onClose)
        Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).safeDrawingPadding()) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onClose) { Icon(Icons.AutoMirrored.Outlined.ArrowBack, "Cancel photo selection") }
                Text("Choose photo ${slot.name}", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
            }
            Text("From a different check-in", style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(horizontal = JournalSpacing.standard, vertical = JournalSpacing.small))
            LazyVerticalGrid(GridCells.Fixed(3), modifier = Modifier.weight(1f).testTag("comparison-picker"),
                horizontalArrangement = Arrangement.spacedBy(JournalSpacing.gridGutter),
                verticalArrangement = Arrangement.spacedBy(JournalSpacing.gridGutter),
                contentPadding = PaddingValues(bottom = JournalSpacing.standard)) {
                photos.groupBy { it.photo.checkInId }.forEach { (checkInId, group) ->
                    item(key = "date-$checkInId", span = { GridItemSpan(maxLineSpan) }) {
                        Text(group.first().date.format(DateTimeFormatter.ofPattern("d MMMM yyyy")),
                            style = MaterialTheme.typography.titleMedium,
                            modifier = Modifier.padding(JournalSpacing.standard))
                    }
                    items(group, key = { it.photo.id }) { item ->
                        val id = item.photo.id
                        val label = item.photo.label?.displayName() ?: "Unlabeled"
                        PrivateImage(library.assets[id]?.thumbnail, null,
                            Modifier.fillMaxWidth().aspectRatio(1f).testTag("pick-$id")
                                .then(if (id == selectedId) Modifier.border(2.dp, MaterialTheme.colorScheme.primary) else Modifier)
                                .semantics { contentDescription = "$label photo ${item.photo.sortOrder + 1}, ${item.date}"; selected = id == selectedId }
                                .clickable { onChoose(id) }, ContentScale.Crop)
                    }
                }
            }
        }
    }
}
