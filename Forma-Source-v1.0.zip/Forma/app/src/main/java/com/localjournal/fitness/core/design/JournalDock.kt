package com.localjournal.fitness.core.design

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp

data class JournalDockItem(val route: String, val label: String, val icon: ImageVector)

@Composable fun JournalDock(items: List<JournalDockItem>, selectedRoute: String, onSelect: (String) -> Unit) {
    val selectedIndex=items.indexOfFirst {it.route==selectedRoute}.coerceAtLeast(0)
    val indicator by animateFloatAsState(selectedIndex.toFloat(),tween(JournalMotion.selectionMillis),label="Dock position")
    val selectionColor=MaterialTheme.colorScheme.primaryContainer
    Box(Modifier.testTag("navigation-dock").fillMaxWidth().windowInsetsPadding(WindowInsets.navigationBars.only(WindowInsetsSides.Bottom))
        .padding(horizontal=JournalDockStyle.horizontalMargin).padding(bottom=JournalDockStyle.bottomGap)) {
        Surface(shape=JournalCorners.dock,
            color=(if(MaterialTheme.colorScheme.background.luminance()<.5f) JournalColors.darkDockSurface else MaterialTheme.colorScheme.surface).copy(alpha=JournalDockStyle.surfaceOpacity),
            border=BorderStroke(1.dp,MaterialTheme.colorScheme.outlineVariant.copy(alpha=.45f)),shadowElevation=JournalDockStyle.elevation) {
            Box(Modifier.padding(JournalDockStyle.contentPadding)) {
                // Only this drawing phase reads the animated position; the dock never moves or relays out.
                Canvas(Modifier.matchParentSize()) {
                    val gap=JournalSpacing.tiny.toPx();val width=(size.width-gap*(items.size-1))/items.size
                    drawRoundRect(selectionColor,topLeft=Offset((width+gap)*indicator,0f),size=Size(width,size.height),cornerRadius=CornerRadius(size.height/2))
                }
                Row(Modifier.fillMaxWidth().selectableGroup(),horizontalArrangement=Arrangement.spacedBy(JournalSpacing.tiny)) {
                    items.forEach { item ->
                        val selected=item.route==selectedRoute
                        val foreground by animateColorAsState(if(selected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant,
                            tween(JournalMotion.selectionMillis),label="Dock foreground")
                        Column(Modifier.weight(1f).heightIn(min=JournalDockStyle.itemHeight).clip(JournalCorners.dock)
                            .selectable(selected,onClick={if(!selected) onSelect(item.route)},role=Role.Tab).padding(vertical=JournalSpacing.small),
                            horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center) {
                            Icon(item.icon,null,tint=foreground,modifier=Modifier.size(JournalSpacing.icon))
                            Text(item.label,color=foreground,style=MaterialTheme.typography.labelMedium)
                        }
                    }
                }
            }
        }
    }
}
