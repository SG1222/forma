package com.localjournal.fitness.data.models

import java.time.Instant
import java.time.LocalDate

enum class PhotoLabel { FRONT, SIDE, BACK, OTHER }
enum class PhotoSource { CAMERA, IMPORT }

data class CheckIn(val id: String, val createdAt: Instant, val checkInDate: LocalDate,
                   val note: String?, val photos: List<Photo>)
data class Photo(val id: String, val checkInId: String, val originalFilePath: String,
                 val thumbnailFilePath: String?, val label: PhotoLabel?, val source: PhotoSource,
                 val originalCaptureDate: Instant?, val sortOrder: Int)

/** Lightweight saved-entry projection, independent of photograph count. */
data class CheckInDay(val checkInDate: LocalDate, val count: Int)
