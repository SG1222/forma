package com.localjournal.fitness.features.viewer

import android.app.Activity
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.core.tween
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.MoreVert
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.localjournal.fitness.LibraryState
import com.localjournal.fitness.core.design.*
import com.localjournal.fitness.features.checkin.*
import java.time.format.DateTimeFormatter

@OptIn(ExperimentalLayoutApi::class)
@Composable fun ViewerScreen(checkInId: String, initialPhotoId: String, library: LibraryState,
    working: Boolean, onClose: () -> Unit,
    onEdit: (String, String, com.localjournal.fitness.data.models.PhotoLabel?, () -> Unit) -> Unit,
    onDelete: (String, () -> Unit) -> Unit, onCompare: (String) -> Unit, exportDisclosureSeen: Boolean, onExport: (String) -> Unit) {
    val entry = library.entries.find { it.id == checkInId }
    LaunchedEffect(entry, library.loaded) { if (library.loaded && entry == null) onClose() }
    if (entry == null || entry.photos.isEmpty()) return
    val pager = rememberPagerState(initialPage = entry.photos.indexOfFirst { it.id == initialPhotoId }.coerceAtLeast(0),
        pageCount = { entry.photos.size })
    var controls by rememberSaveable { mutableStateOf(true) }
    var zoomed by remember { mutableStateOf(false) }
    var more by remember { mutableStateOf(false) }
    var edit by rememberSaveable { mutableStateOf(false) }
    var export by rememberSaveable { mutableStateOf(false) }
    var delete by rememberSaveable { mutableStateOf(false) }
    val view = LocalView.current
    val activity = view.context as? Activity
    DisposableEffect(controls, activity) {
        val controller = activity?.let { WindowCompat.getInsetsController(it.window, view) }
        controller?.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        if (controls) controller?.show(WindowInsetsCompat.Type.systemBars()) else controller?.hide(WindowInsetsCompat.Type.systemBars())
        onDispose { controller?.show(WindowInsetsCompat.Type.systemBars()) }
    }
    BackHandler { if (!working) { if (zoomed) { controls = true; onClose() } else onClose() } }
    val photo = entry.photos[pager.currentPage.coerceAtMost(entry.photos.lastIndex)]
    Box(Modifier.fillMaxSize().background(JournalColors.comparisonCanvas)) {
        HorizontalPager(state = pager, key = { entry.photos[it].id }, userScrollEnabled = !zoomed,
            modifier = Modifier.fillMaxSize()) { index ->
            val item = entry.photos[index]
            ZoomablePhoto(library.assets[item.id]?.original, index == pager.currentPage,
                onTap = { controls = !controls }, onZoom = { zoomed = it })
        }
        AnimatedVisibility(controls, modifier = Modifier.matchParentSize(), enter = fadeIn(tween(JournalMotion.enterMillis)), exit = fadeOut(tween(JournalMotion.exitMillis))) {
            Box(Modifier.fillMaxSize()) {
            Row(Modifier.align(Alignment.TopCenter).fillMaxWidth().padding(horizontal = JournalSpacing.small)
                .windowInsetsPadding(WindowInsets.statusBarsIgnoringVisibility), verticalAlignment = Alignment.CenterVertically) {
                JournalFloatingIconButton(onClose, Icons.AutoMirrored.Outlined.ArrowBack, "Back to Log", enabled = !working)
                Column(Modifier.weight(1f).padding(JournalSpacing.small).background(JournalColors.comparisonCanvas.copy(alpha = .94f), JournalCorners.control).padding(JournalSpacing.small)) {
                    Text(entry.checkInDate.format(DateTimeFormatter.ofPattern("d MMMM yyyy")), color = Color.White,
                        style = MaterialTheme.typography.titleMedium)
                    Text("${pager.currentPage + 1} of ${entry.photos.size}" + (photo.label?.let { " · ${it.displayName()}" } ?: ""),
                        color = Color.LightGray, style = MaterialTheme.typography.bodyMedium)
                }
            }
            Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                .windowInsetsPadding(WindowInsets.navigationBarsIgnoringVisibility).padding(horizontal = JournalSpacing.standard, vertical = JournalSpacing.small)) {
                Surface(shape = JournalCorners.dock, color = MaterialTheme.colorScheme.surfaceContainer.copy(alpha = JournalActionStyle.materialOpacity)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceEvenly) {
                    JournalTertiaryButton(onClick = { onCompare(photo.id) }, enabled = !working) { Text("Compare") }
                    JournalTertiaryButton(onClick = { export = true }, enabled = !working) { Text("Export") }
                    Box {
                        IconButton(onClick = { more = true }, enabled = !working) { Icon(Icons.Outlined.MoreVert, "More", tint = Color.White) }
                        DropdownMenu(expanded = more, onDismissRequest = { more = false }) {
                            DropdownMenuItem(text = { Text("Edit") }, onClick = { more = false; edit = true })
                            DropdownMenuItem(text = { Text("Delete") }, onClick = { more = false; delete = true })
                        }
                    }
                }
                }
            }
            }
        }
    }
    if (export) AlertDialog(onDismissRequest = { export = false }, title = { Text("Export photograph") },
        text = { Text(if (exportDisclosureSeen) "Save a copy of this photograph to your phone's gallery."
            else "Exported photos may appear in your phone's gallery and may be backed up by other apps.") },
        confirmButton = { JournalTertiaryButton(onClick = { export = false; onExport(photo.id) }) { Text("Save to Gallery") } },
        dismissButton = { JournalTertiaryButton(onClick = { export = false }) { Text("Cancel") } })
    if (edit) {
        var note by rememberSaveable(photo.id) { mutableStateOf(entry.note.orEmpty()) }
        var label by rememberSaveable(photo.id) { mutableStateOf(photo.label) }
        AlertDialog(onDismissRequest = { if (!working) edit = false }, title = { Text("Edit photograph") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    OutlinedTextField(note, onValueChange = { note = it }, enabled = !working,
                        label = { Text("Check-in note") }, minLines = 2, maxLines = 5)
                    Text("This note belongs to all photographs in this check-in.", style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.padding(vertical = JournalSpacing.small))
                    LabelSelector(label, !working) { label = it }
                }
            }, confirmButton = { JournalTertiaryButton(onClick = { onEdit(photo.id, note, label) { edit = false } }, enabled = !working) { Text("Save changes") } },
            dismissButton = { JournalTertiaryButton(onClick = { edit = false }, enabled = !working) { Text("Cancel") } })
    }
    if (delete) AlertDialog(onDismissRequest = { if (!working) delete = false },
        title = { Text(if (entry.photos.size == 1) "Delete photograph and check-in?" else "Delete photograph?") },
        text = { Text(if (entry.photos.size == 1) "This permanently removes the photograph, its preview, and this check-in’s note."
            else "This permanently removes this photograph and its preview. Other photographs in the check-in are kept.") },
        confirmButton = { JournalTertiaryButton(onClick = { onDelete(photo.id) { delete = false } }, enabled = !working) { Text("Delete permanently") } },
        dismissButton = { JournalTertiaryButton(onClick = { delete = false }, enabled = !working) { Text("Keep photograph") } })
}
