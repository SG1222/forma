package com.localjournal.fitness.core.storage

import com.localjournal.fitness.core.export.PhotoExporter
import com.localjournal.fitness.data.preferences.JournalPreferences
import com.localjournal.fitness.data.repositories.JournalRepository

class JournalMaintenance(private val repository: JournalRepository, private val preferences: JournalPreferences,
    private val exporter: PhotoExporter,
    private val cleanupExports: suspend () -> Unit = exporter::recoverPending) {
    suspend fun deleteAll() {
        cleanupExports() // Removes only tracked unpublished copies. Completed gallery exports stay untouched.
        repository.deleteAllJournalData()
        // Keep the security choice: clearing journal data must not bypass authenticated lock disabling.
        preferences.resetJournalPreferences()
        repository.finishDeletion()
    }
    suspend fun recover(): Boolean {
        if (repository.deletionPending()) { deleteAll(); return true }
        return try { cleanupExports(); true }
        catch (error: Exception) {
            if (error is kotlinx.coroutines.CancellationException) throw error
            // An unavailable public media volume must not prevent reading the private journal.
            // Keep the ledger and pending row for a later retry; never publish a partial export.
            false
        }
    }
}
