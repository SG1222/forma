package com.localjournal.fitness.core.design

/** Compose's Android motion-duration scale makes these instantaneous when animations are disabled. */
object JournalMotion {
    const val enterMillis = 180
    const val exitMillis = 120
    const val selectionMillis = 200
    const val pressMillis = 100
}
