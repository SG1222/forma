package com.localjournal.fitness.core.security

import android.content.Intent
import android.provider.Settings
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity

/** WEAK | CREDENTIAL is supported on API 29; STRONG | CREDENTIAL and CREDENTIAL-only are not. */
const val JOURNAL_AUTHENTICATORS = BiometricManager.Authenticators.BIOMETRIC_WEAK or BiometricManager.Authenticators.DEVICE_CREDENTIAL

class NativeAuthentication(private val activity: FragmentActivity, private val session: AuthenticationSession) {
    private val prompt = BiometricPrompt(activity, ContextCompat.getMainExecutor(activity), object : BiometricPrompt.AuthenticationCallback() {
        override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) { session.succeeded() }
        override fun onAuthenticationFailed() { session.failed("Authentication was not recognized. Try again.", false) }
        override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
            session.failed(when(errorCode) {
                BiometricPrompt.ERROR_USER_CANCELED, BiometricPrompt.ERROR_CANCELED, BiometricPrompt.ERROR_NEGATIVE_BUTTON -> if (session.state.value.purpose == AuthenticationPurpose.ENABLE_LOCK) "Authentication cancelled. App lock is still off." else "Authentication cancelled. Your journal remains locked."
                BiometricPrompt.ERROR_NO_BIOMETRICS, BiometricPrompt.ERROR_NO_DEVICE_CREDENTIAL -> "Set up a device PIN, pattern, password or supported biometric in Android security settings."
                else -> "Device authentication is unavailable right now. Try again or check Android security settings."
            })
        }
    })
    fun available() = BiometricManager.from(activity).canAuthenticate(JOURNAL_AUTHENTICATORS) == BiometricManager.BIOMETRIC_SUCCESS
    fun authenticate(purpose: AuthenticationPurpose) {
        if (!available()) { session.failed("Set up a device PIN, pattern, password or supported biometric in Android security settings."); return }
        if (!session.begin(purpose)) return
        try {
            prompt.authenticate(BiometricPrompt.PromptInfo.Builder().setTitle(when(purpose) {
                AuthenticationPurpose.UNLOCK -> activity.getString(com.localjournal.fitness.R.string.unlock_prompt)
                AuthenticationPurpose.ENABLE_LOCK -> "Enable app lock"
                AuthenticationPurpose.DISABLE_LOCK -> "Disable app lock"
            }).setSubtitle("Use your device's available authentication.")
                .setAllowedAuthenticators(JOURNAL_AUTHENTICATORS).build())
        } catch (_: Exception) { session.failed("Device authentication could not open. Try again or check Android security settings.") }
    }
    fun openSecuritySettings() {
        try { activity.startActivity(Intent(Settings.ACTION_SECURITY_SETTINGS)) }
        catch (_: Exception) { session.failed("Android security settings could not be opened on this device.") }
    }
}
