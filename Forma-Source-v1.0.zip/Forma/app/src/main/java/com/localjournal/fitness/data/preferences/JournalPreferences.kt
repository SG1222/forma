package com.localjournal.fitness.data.preferences

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

private val Context.journalPreferences by preferencesDataStore("journal_preferences")
enum class ThemeMode { SYSTEM, LIGHT, DARK }
class JournalPreferences(context: Context) {
    private val store = context.applicationContext.journalPreferences
    private val themeKey = stringPreferencesKey("theme_mode")
    private val lockKey = booleanPreferencesKey("require_authentication")
    private val exportKey = booleanPreferencesKey("export_disclosure_seen")
    // Fail closed at the security gate if DataStore cannot be read; never default a read error to unlocked.
    val requireAuthentication = store.data.map { it[lockKey] ?: false }
    val exportDisclosureSeen = store.data.map { it[exportKey] ?: false }
    suspend fun setRequireAuthentication(enabled: Boolean) { store.edit { it[lockKey] = enabled } }
    suspend fun acknowledgeExportDisclosure() { store.edit { it[exportKey] = true } }
    suspend fun resetJournalPreferences() { store.edit { prefs ->
        val keepLock = prefs[lockKey] ?: false
        prefs.clear()
        prefs[lockKey] = keepLock
    } }
    val themeMode = store.data.catch { error ->
        if (error is IOException) emit(emptyPreferences()) else throw error
    }.map { prefs -> ThemeMode.entries.find { it.name == prefs[themeKey] } ?: ThemeMode.SYSTEM }
    suspend fun setThemeMode(mode: ThemeMode) { store.edit { it[themeKey] = mode.name } }
}
