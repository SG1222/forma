package com.localjournal.fitness.core.export

import android.content.ContentResolver
import android.content.ContentValues
import android.net.Uri
import android.os.Environment
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import android.util.AtomicFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.*
import java.util.UUID

/** Explicit single-photo, byte-preserving public copy. Every unpublished row has a private recovery intent. */
class PhotoExporter(private val resolver: ContentResolver, private val jobs: File, private val packageName: String,
    private val copy: (InputStream, OutputStream) -> Long = { input, output -> input.copyTo(output) }) {
    private val mutex = Mutex()
    private val collection = MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
    private val relativePath = "${Environment.DIRECTORY_PICTURES}/Photo Journal/"
    private fun record(file: File, json: JSONObject) {
        val atomic = AtomicFile(file); val output = atomic.startWrite()
        try { output.write(json.toString().toByteArray()); atomic.finishWrite(output) }
        catch (error: Throwable) { atomic.failWrite(output); throw error }
    }
    suspend fun export(original: File): Uri = withContext(Dispatchers.IO) { mutex.withLock {
        require(original.isFile && original.length() > 0) { "The private original is unavailable." }
        val extension = original.extension.lowercase()
        val mime = when(extension) { "jpg", "jpeg" -> "image/jpeg"; "png" -> "image/png"; "webp" -> "image/webp"; "heic", "heif" -> "image/heic"; else -> throw IOException("This format cannot be exported.") }
        if (!jobs.isDirectory && !jobs.mkdirs()) throw IOException("Export recovery metadata could not be stored.")
        val id = UUID.randomUUID().toString(); val name = "PhotoJournal_$id.$extension"
        val ledger = File(jobs, "$id.json")
        val data = JSONObject().put("name", name)
        // Persist the name BEFORE insertion, so death between insert and URI journaling remains recoverable.
        record(ledger, data)
        var published = false
        try {
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, name); put(MediaStore.Images.Media.MIME_TYPE, mime)
                put(MediaStore.Images.Media.RELATIVE_PATH, relativePath); put(MediaStore.Images.Media.IS_PENDING, 1)
                put(MediaStore.Images.Media.DATE_EXPIRES, System.currentTimeMillis()/1000 + 86400)
            }
            val uri = resolver.insert(collection, values) ?: throw IOException("A gallery entry could not be created.")
            record(ledger, data.put("uri", uri.toString()))
            val descriptor = resolver.openFileDescriptor(uri, "w") ?: throw IOException("The gallery copy could not be opened.")
            val expected = original.length()
            val written = ParcelFileDescriptor.AutoCloseOutputStream(descriptor).use { output ->
                val count = original.inputStream().use { copy(it, output) }
                output.fd.sync(); count
            }
            if (written != expected) throw IOException("The gallery copy was incomplete.")
            val complete = ContentValues().apply {
                put(MediaStore.Images.Media.IS_PENDING, 0); putNull(MediaStore.Images.Media.DATE_EXPIRES)
            }
            if (resolver.update(uri, complete, null, null) != 1) throw IOException("The gallery copy could not be published.")
            published = true
            ledger.delete() // If this fails, recovery recognizes the completed row and removes only its ledger.
            uri
        } finally {
            if (!published) runCatching { cleanJob(ledger) }
        }
    } }
    @Suppress("DEPRECATION") // API-29-compatible pending-row visibility; query still restricts app owner + exact names.
    private fun pendingCollection() = MediaStore.setIncludePending(collection)
    private fun cleanJob(ledger: File) {
        val savedName = runCatching {
            JSONObject(AtomicFile(ledger).openRead().use { it.reader().readText() }).getString("name")
        }.getOrNull()?.takeIf { it.matches(Regex("PhotoJournal_[a-f0-9-]{36}\\.(jpg|jpeg|png|webp|heic|heif)")) }
        val names = if (savedName != null) listOf(savedName) else {
            // Damaged metadata must not strand a pending row or block the private journal.
            // The app-generated ledger UUID still scopes recovery to these exact possible names.
            val id = ledger.name.removeSuffix(".json")
            require(UUID.fromString(id).toString() == id)
            listOf("jpg", "jpeg", "png", "webp", "heic", "heif").map { "PhotoJournal_$id.$it" }
        }
        val pending = mutableListOf<Uri>()
        resolver.query(pendingCollection(), arrayOf(MediaStore.Images.Media._ID),
            "${MediaStore.Images.Media.DISPLAY_NAME} IN (${names.joinToString(",") { "?" }}) AND ${MediaStore.Images.Media.RELATIVE_PATH} = ? AND ${MediaStore.Images.Media.OWNER_PACKAGE_NAME} = ? AND ${MediaStore.Images.Media.IS_PENDING} = 1",
            (names + relativePath + packageName).toTypedArray(), null)?.use { cursor ->
            while(cursor.moveToNext()) pending += Uri.withAppendedPath(collection, cursor.getLong(0).toString())
        } ?: throw IOException("Unfinished exports could not be checked.")
        pending.forEach { if (resolver.delete(it, null, null) != 1) throw IOException("An unfinished gallery copy could not be removed.") }
        AtomicFile(ledger).delete()
        if (listOf(ledger, File(ledger.path + ".bak"), File(ledger.path + ".new")).any { it.exists() })
            throw IOException("Export recovery metadata could not be removed.")
    }
    suspend fun recoverPending() = withContext(Dispatchers.IO) { mutex.withLock {
        if (jobs.exists()) {
            val ledgers = jobs.listFiles() ?: throw IOException("Export recovery storage is unavailable.")
            ledgers.filter { it.extension == "json" || it.extension == "bak" }.map { if(it.extension == "bak") File(it.path.removeSuffix(".bak")) else it }
                .distinct().forEach(::cleanJob)
        }
    } }
}
