package com.localjournal.fitness.core.storage

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import androidx.core.graphics.scale
import android.util.AtomicFile
import androidx.exifinterface.media.ExifInterface
import com.localjournal.fitness.data.models.*
import org.json.JSONObject
import org.json.JSONArray
import java.io.*
import java.time.Instant
import java.util.UUID

/** All methods perform disk work. Repository owns IO dispatch and serializes mutations. */
internal class PrivatePhotoStore(private val root: File, private val deleteTree: (File) -> Boolean = { it.deleteRecursively() }) {
    private val resetMarker get() = File(root, "delete_journal.pending")
    fun deletionPending() = resetMarker.exists()
    fun beginDeletion() {
        val atomic = AtomicFile(resetMarker); val stream = atomic.startWrite()
        try { stream.write("delete-private-journal".toByteArray()); atomic.finishWrite(stream) }
        catch (error: Exception) { atomic.failWrite(stream); throw error }
    }
    fun deleteJournalFiles() {
        listOf("photos", "thumbnails", "drafts").forEach { name ->
            val file = File(root, name)
            if (file.exists() && !deleteTree(file)) throw IOException("Some private files could not be deleted. Retry Delete all data.")
        }
    }
    fun finishDeletion() {
        if (resetMarker.exists() && !resetMarker.delete()) throw IOException("Deletion could not be finalized. Retry Delete all data.")
    }
    fun journalBytes(): Long = listOf("photos", "thumbnails", "drafts", "export_jobs").sumOf { name ->
        val directory = File(root, name)
        if (!directory.exists()) 0L else directory.walkTopDown().filter { it.isFile }.sumOf { it.length() }
    }
    private fun directory(name: String) = File(root, name).also {
        if (!it.isDirectory && !it.mkdirs()) throw IOException("Private storage could not be opened.")
    }
    private fun id(value: String): String = UUID.fromString(value).toString().also {
        require(it == value) { "Invalid private identifier" }
    }
    fun resolve(relative: String): File {
        require(relative.matches(Regex("(photos|thumbnails)/[a-f0-9-]{36}\\.(jpg|png|webp|heic)")))
        val file = File(root, relative)
        require(file.canonicalFile.parentFile == File(root, relative.substringBefore('/')).canonicalFile)
        return file
    }
    private fun draftDir(draftId: String) = File(directory("drafts"), id(draftId))
    fun createDraft(): String = UUID.randomUUID().toString().also {
        if (!draftDir(it).mkdir()) throw IOException("A photo draft could not be created.")
    }
    fun stage(draftId: String, source: PhotoSource, input: InputStream,
              captureDate: Instant? = null, label: PhotoLabel? = null,
              stableId: String = UUID.randomUUID().toString()): DraftPhoto {
        val dir = draftDir(draftId)
        require(dir.isDirectory) { "Draft no longer exists" }
        val photoId = id(stableId)
        readDraft(draftId).find { it.id == photoId }?.let { input.close(); return it }
        val ordinal = (dir.listFiles().orEmpty().filter { it.extension == "json" }.maxOfOrNull { file ->
            JSONObject(AtomicFile(file).openRead().use { it.reader().readText() }).optLong("ordinal", file.lastModified())
        } ?: -1L) + 1L
        val temporary = File(dir, "$photoId.part")
        try {
            input.use { stream -> FileOutputStream(temporary).use { output ->
                stream.copyTo(output); output.fd.sync()
            } }
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(temporary.path, bounds)
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) throw IOException("This file is not a readable photograph.")
            val extension = when (bounds.outMimeType) {
                "image/jpeg" -> "jpg"; "image/png" -> "png"; "image/webp" -> "webp"
                "image/heif", "image/heic" -> "heic"
                else -> throw IOException("This photograph format is not supported.")
            }
            // Validate actual pixel decoding before publishing a recoverable draft.
            decodeThumbnail(temporary).recycle()
            val original = File(dir, "$photoId.$extension")
            if (!temporary.renameTo(original)) throw IOException("The photograph could not be staged.")
            val photo = DraftPhoto(photoId, original.name, source, captureDate, label)
            val metadata = AtomicFile(File(dir, "$photoId.json"))
            val output = metadata.startWrite()
            try {
                output.write(JSONObject().put("id", photo.id).put("file", photo.fileName)
                    .put("source", source.name).put("captureDate", captureDate?.toString())
                    .put("label", label?.name).put("ordinal", ordinal).toString().toByteArray())
                metadata.finishWrite(output)
            } catch (error: Exception) { metadata.failWrite(output); throw error }
            return photo
        } finally { temporary.delete() }
    }
    private fun review(draftId: String): JSONObject {
        val file = File(draftDir(draftId), "review.state")
        return if (file.exists()) JSONObject(AtomicFile(file).openRead().use { it.reader().readText() }) else JSONObject()
    }
    fun readDraft(draftId: String): List<DraftPhoto> {
        val state = review(draftId)
        val labels = state.optJSONObject("labels") ?: JSONObject()
        return draftDir(draftId).listFiles().orEmpty().filter { it.extension == "json" }
            .map { file -> file to JSONObject(AtomicFile(file).openRead().use { it.reader().readText() }) }
            .sortedBy { (file, json) -> json.optLong("ordinal", file.lastModified()) }
            .map { (_, json) ->
                val photoId = id(json.getString("id"))
                val name = json.getString("file")
                require(name.matches(Regex("${photoId}\\.(jpg|png|webp|heic)")))
                val label = if (labels.has(photoId)) labels.optString(photoId) else json.optString("label")
                DraftPhoto(photoId, name, PhotoSource.valueOf(json.getString("source")),
                    json.optString("captureDate").takeIf { it.isNotEmpty() && it != "null" }?.let(Instant::parse),
                    label.takeIf { it.isNotEmpty() && it != "null" }?.let(PhotoLabel::valueOf))
            }
    }
    fun session(draftId: String): DraftSession {
        require(draftDir(draftId).isDirectory) { "This unfinished check-in is no longer available." }
        recoverReadyCaptures(draftId)
        val photos = readDraft(draftId)
        return DraftSession(draftId, photos, review(draftId).optString("note"),
            photos.associate { it.id to File(draftDir(draftId), it.fileName) })
    }
    fun updateReview(draftId: String, note: String, labels: Map<String, PhotoLabel?>) {
        val existing = readDraft(draftId).map { it.id }.toSet()
        require(labels.keys.all { it in existing })
        val jsonLabels = JSONObject()
        labels.forEach { (key, value) -> jsonLabels.put(key, value?.name ?: JSONObject.NULL) }
        val json = JSONObject().put("note", note).put("labels", jsonLabels)
        val atomic = AtomicFile(File(draftDir(draftId), "review.state"))
        val stream = atomic.startWrite()
        try { stream.write(json.toString().toByteArray()); atomic.finishWrite(stream) }
        catch (error: Exception) { atomic.failWrite(stream); throw error }
    }
    fun removeDraftPhoto(draftId: String, photoId: String) {
        val photo = readDraft(draftId).find { it.id == photoId } ?: return
        val metadata = File(draftDir(draftId), "${id(photoId)}.json")
        if (!metadata.delete()) throw IOException("The photograph could not be removed from this draft.")
        val original = File(draftDir(draftId), photo.fileName)
        if (original.exists() && !original.delete()) throw IOException("The unused draft file could not be removed.")
    }
    fun reserveCapture(draftId: String): File {
        require(draftDir(draftId).isDirectory)
        return File(draftDir(draftId), "capture-${UUID.randomUUID()}.pending")
    }
    private fun validateCapture(draftId: String, file: File) {
        require(file.parentFile?.canonicalFile == draftDir(draftId).canonicalFile)
        require(file.name.matches(Regex("capture-[a-f0-9-]{36}\\.(pending|ready)")))
    }
    fun completeCapture(draftId: String, file: File): DraftPhoto {
        validateCapture(draftId, file)
        FileOutputStream(file, true).use { it.fd.sync() }
        val ready = File(file.parentFile, file.nameWithoutExtension + ".ready")
        if (!file.renameTo(ready)) throw IOException("The captured photograph could not be staged.")
        return promoteCapture(draftId, ready)
    }
    private fun promoteCapture(draftId: String, ready: File): DraftPhoto {
        val photoId = ready.nameWithoutExtension.removePrefix("capture-")
        val photo = stage(draftId, PhotoSource.CAMERA, ready.inputStream(), Instant.ofEpochMilli(ready.lastModified()), stableId = photoId)
        if (!ready.delete()) throw IOException("The captured draft could not be finalized. It can be recovered.")
        return photo
    }
    private fun recoverReadyCaptures(draftId: String) {
        draftDir(draftId).listFiles().orEmpty().filter { it.name.startsWith("capture-") && it.extension == "ready" }
            .forEach { promoteCapture(draftId, it) }
    }
    fun abandonCapture(draftId: String, file: File) {
        validateCapture(draftId, file)
        if (file.exists() && !file.delete()) throw IOException("The interrupted capture could not be cleaned up.")
    }
    fun draftIds(): List<String> = directory("drafts").listFiles().orEmpty()
        .filter { it.isDirectory && runCatching { id(it.name) }.isSuccess }.map { it.name }

    /** Copies rather than moves, keeping the draft recoverable until Room commits. */
    fun prepare(draftId: String, photo: DraftPhoto): StoredPhoto {
        id(photo.id)
        require(photo in readDraft(draftId))
        directory("photos"); directory("thumbnails")
        val originalPath = "photos/${photo.fileName}"
        val original = resolve(originalPath)
        val draft = File(draftDir(draftId), photo.fileName)
        if (!draft.isFile) throw IOException("A draft photograph is missing. The entry was not saved.")
        atomicWrite(original) { output -> draft.inputStream().use { it.copyTo(output) } }
        val thumbnailPath = "thumbnails/${photo.id}.jpg"
        generateThumbnail(original, resolve(thumbnailPath))
        return StoredPhoto(originalPath, thumbnailPath)
    }
    fun ensureThumbnail(originalPath: String, thumbnailPath: String) {
        val thumb = resolve(thumbnailPath)
        val valid = if (thumb.isFile) runCatching {
            decodeThumbnail(thumb).recycle(); true
        }.getOrDefault(false) else false
        if (!valid) generateThumbnail(resolve(originalPath), thumb)
    }
    private fun generateThumbnail(original: File, target: File) {
        val bitmap = decodeThumbnail(original)
        try { atomicWrite(target) { if (!bitmap.compress(Bitmap.CompressFormat.JPEG, 85, it))
            throw IOException("The thumbnail could not be saved.") } } finally { bitmap.recycle() }
    }
    private fun decodeThumbnail(file: File): Bitmap {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.path, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) throw IOException("This photograph cannot be decoded.")
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 1024) sample *= 2
        val decoded = BitmapFactory.decodeFile(file.path, BitmapFactory.Options().apply { inSampleSize = sample })
            ?: throw IOException("This photograph cannot be decoded.")
        val exif = ExifInterface(file)
        val matrix = Matrix().apply {
            if (exif.isFlipped) postScale(-1f, 1f)
            postRotate(exif.rotationDegrees.toFloat())
        }
        val oriented = Bitmap.createBitmap(decoded, 0, 0, decoded.width, decoded.height, matrix, true)
        if (oriented !== decoded) decoded.recycle()
        val ratio = minOf(1f, 512f / maxOf(oriented.width, oriented.height))
        val result = oriented.scale(maxOf(1, (oriented.width * ratio).toInt()),
            maxOf(1, (oriented.height * ratio).toInt()), true)
        if (result !== oriented) oriented.recycle()
        return result
    }
    private fun atomicWrite(target: File, writer: (FileOutputStream) -> Unit) {
        val temporary = File(target.parentFile, target.name + ".part")
        try {
            FileOutputStream(temporary).use { writer(it); it.fd.sync() }
            if (!temporary.renameTo(target)) throw IOException("Private photo storage could not be committed.")
        } finally { temporary.delete() }
    }
    fun discardDraft(draftId: String) {
        val dir = draftDir(draftId)
        if (dir.exists() && !dir.deleteRecursively()) throw IOException("The draft could not be removed.")
    }
    /** Only saved-file directories are reconciled; unfinished drafts are never swept. */
    fun removeUnreferenced(references: Set<String>) {
        listOf("photos", "thumbnails").forEach { name ->
            directory(name).listFiles().orEmpty().filter { "$name/${it.name}" !in references }.forEach {
                if (!it.delete()) throw IOException("Unused private files could not be removed.")
            }
        }
    }
}

data class DraftPhoto(val id: String, val fileName: String, val source: PhotoSource,
                      val originalCaptureDate: Instant?, val label: PhotoLabel?)
internal data class StoredPhoto(val originalPath: String, val thumbnailPath: String)

/** Read-only private image references. Coil performs decoding away from the UI thread. */
data class PhotoAssets(val original: File, val thumbnail: File?)
data class DraftSession(val id: String, val photos: List<DraftPhoto>, val note: String,
                        val previewFiles: Map<String, File>)
