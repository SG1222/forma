package com.localjournal.fitness.core.security

import android.os.SystemClock
import com.localjournal.fitness.data.preferences.JournalPreferences
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*

class AuthenticationSession(private val preferences: JournalPreferences,
    private val scope: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate),
    elapsed: () -> Long = SystemClock::elapsedRealtime) {
    private val policy = SessionPolicy(elapsed)
    private val mutable = MutableStateFlow(policy.state)
    val state = mutable.asStateFlow()
    init { scope.launch {
        try { preferences.requireAuthentication.collect { policy.configure(it); publish() } }
        catch (error: Exception) { if (error is CancellationException) throw error; policy.preferencesUnavailable(); publish() }
    } }
    private fun publish() { mutable.value = policy.state }
    fun resume() { policy.resume(); publish() }
    fun pause() { policy.pause(); publish() }
    fun configurationChange() { policy.configurationChange(); publish() }
    fun begin(purpose: AuthenticationPurpose): Boolean = policy.begin(purpose).also { publish() }
    fun failed(message: String, terminal: Boolean = true) { policy.failed(message, terminal); publish() }
    fun succeeded() {
        val purpose = state.value.purpose ?: return
        policy.busy(true); publish()
        scope.launch {
            try {
                when (purpose) {
                    AuthenticationPurpose.ENABLE_LOCK -> preferences.setRequireAuthentication(true)
                    AuthenticationPurpose.DISABLE_LOCK -> preferences.setRequireAuthentication(false)
                    AuthenticationPurpose.UNLOCK -> Unit
                }
                // Reflect the persisted policy before granting this process-only session.
                if (purpose != AuthenticationPurpose.UNLOCK) policy.configure(purpose == AuthenticationPurpose.ENABLE_LOCK)
                policy.authenticated(); publish()
            } catch (error: Exception) {
                if (error is CancellationException) throw error
                policy.failed("The privacy setting could not be saved. Free up storage and try again.", true); publish()
            }
        }
    }
}
