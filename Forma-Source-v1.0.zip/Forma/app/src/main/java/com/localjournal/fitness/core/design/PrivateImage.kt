package com.localjournal.fitness.core.design

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import coil3.compose.AsyncImage
import java.io.File

@Composable fun PrivateImage(file: File?, description: String?, modifier: Modifier = Modifier,
    contentScale: ContentScale = ContentScale.Fit) {
    var failed by remember(file) { mutableStateOf(file == null) }
    Box(modifier.background(JournalColors.comparisonCanvas), contentAlignment = Alignment.Center) {
        if (file != null) AsyncImage(model = file, contentDescription = description,
            modifier = Modifier.fillMaxSize(), contentScale = contentScale,
            onError = { failed = true }, onSuccess = { failed = false })
        if (failed) Text("Photo unavailable", color = androidx.compose.ui.graphics.Color.White,
            style = MaterialTheme.typography.bodyMedium)
    }
}
