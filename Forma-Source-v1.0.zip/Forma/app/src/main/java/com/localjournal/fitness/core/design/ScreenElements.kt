package com.localjournal.fitness.core.design

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier

@Composable fun JournalScreen(title: String, action: @Composable () -> Unit = {},
                              leading: (@Composable () -> Unit)? = null,
                              content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())
        .padding(horizontal = JournalSpacing.standard)) {
        Row(Modifier.fillMaxWidth().padding(top = JournalSpacing.compact, bottom = JournalSpacing.section),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            leading?.invoke()
            Text(title, style = MaterialTheme.typography.headlineLarge, modifier = Modifier.weight(1f))
            action()
        }
        content()
        Spacer(Modifier.height(JournalSpacing.section))
    }
}
@Composable fun SecondaryText(text: String) {
    Text(text, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
}
