package com.localjournal.fitness.features.streaks

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.outlined.KeyboardArrowRight
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.*
import androidx.compose.ui.unit.dp
import com.localjournal.fitness.core.design.*
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.util.Locale

private fun weeks(count: Int) = "$count ${if (count == 1) "week" else "weeks"}"
private fun checkIns(count: Int) = "$count ${if (count == 1) "check-in" else "check-ins"}"

@Composable fun StreaksScreen(state: StreaksState, onRetry: () -> Unit) {
    var monthKey by rememberSaveable { mutableStateOf<String?>(null) }
    var selectedKey by rememberSaveable { mutableStateOf<String?>(null) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).testTag("streaks-scroll"),
        horizontalAlignment = Alignment.CenterHorizontally) {
        Column(Modifier.widthIn(max = JournalCalendarStyle.maximumWidth).fillMaxWidth()) {
            Text("Streaks", style = MaterialTheme.typography.headlineLarge,
                modifier = Modifier.testTag("streaks-heading").padding(horizontal = JournalSpacing.standard)
                    .padding(top = JournalSpacing.compact, bottom = JournalSpacing.section))
            val statistics = state.statistics
            val today = state.today
            if (state.error != null) {
                Column(Modifier.padding(JournalSpacing.standard)) {
                    Text(state.error); TextButton(onClick = onRetry) { Text("Try again") }
                }
            } else if (statistics == null || today == null) {
                Text("Opening check-in history…", modifier = Modifier.padding(JournalSpacing.standard))
            } else {
                Column(Modifier.padding(horizontal = JournalSpacing.standard)) {
                    Text(weeks(statistics.currentWeeks), style = MaterialTheme.typography.displayMedium,
                        modifier = Modifier.testTag("current-streak"))
                    SecondaryText("Current streak")
                    Spacer(Modifier.height(JournalSpacing.section))
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                    Row(Modifier.fillMaxWidth().padding(vertical = JournalSpacing.standard),
                        horizontalArrangement = Arrangement.spacedBy(JournalSpacing.standard)) {
                        Column(Modifier.weight(1f)) {
                            Text(weeks(statistics.longestWeeks), style = MaterialTheme.typography.headlineMedium,
                                modifier = Modifier.testTag("longest-streak"))
                            Text("Longest streak", style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Column(Modifier.weight(1f)) {
                            Text(statistics.totalCheckIns.toString(), style = MaterialTheme.typography.headlineMedium,
                                modifier = Modifier.testTag("total-check-ins"))
                            Text("Total check-ins", style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                }
                Spacer(Modifier.height(JournalSpacing.standard))
                val month = monthKey?.let(YearMonth::parse) ?: YearMonth.from(today)
                CalendarMonth(month, today, statistics.checkInsByDate, selectedKey?.let(LocalDate::parse),
                    { next -> monthKey = next.toString(); selectedKey = null }, { selectedKey = it.toString() })
                val selected = selectedKey?.let(LocalDate::parse)?.takeIf { YearMonth.from(it) == month }
                Column(Modifier.padding(horizontal = JournalSpacing.standard).padding(top = JournalSpacing.compact)) {
                    Text(if (selected == null) "Each dot marks a day with a saved check-in."
                        else selected.format(DateTimeFormatter.ofPattern("d MMMM yyyy")) + " · " + checkIns(statistics.checkInsByDate[selected] ?: 0),
                        style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.testTag("calendar-detail").semantics { liveRegion = LiveRegionMode.Polite })
                    Text(if (statistics.totalCheckIns == 0) "Save a check-in to begin. Weeks run Monday to Sunday."
                        else "One check-in qualifies a week. Weeks run Monday to Sunday.",
                        style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = JournalSpacing.standard).testTag("streaks-end"))
                }
                Spacer(Modifier.height(JournalSpacing.section))
            }
        }
    }
}

@Composable private fun CalendarMonth(month: YearMonth, today: LocalDate, counts: Map<LocalDate, Int>,
    selected: LocalDate?, onMonth: (YearMonth) -> Unit, onDay: (LocalDate) -> Unit) {
    val locale = Locale.getDefault()
    Row(Modifier.fillMaxWidth().padding(start = JournalSpacing.standard, end = JournalSpacing.small),
        verticalAlignment = Alignment.CenterVertically) {
        Text(month.format(DateTimeFormatter.ofPattern("MMMM yyyy", locale)), style = MaterialTheme.typography.titleLarge,
            modifier = Modifier.weight(1f).testTag("calendar-month"))
        IconButton(onClick = { onMonth(month.minusMonths(1)) }, enabled = month.year > 1) {
            Icon(Icons.AutoMirrored.Outlined.KeyboardArrowLeft, "Previous month")
        }
        IconButton(onClick = { onMonth(month.plusMonths(1)) }, enabled = month.year < 9999) {
            Icon(Icons.AutoMirrored.Outlined.KeyboardArrowRight, "Next month")
        }
    }
    Row(Modifier.fillMaxWidth().padding(vertical = JournalSpacing.small)) {
        DayOfWeek.entries.forEach { day ->
            Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                Text(day.getDisplayName(TextStyle.SHORT, locale), style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.clearAndSetSemantics { contentDescription = day.getDisplayName(TextStyle.FULL, locale) })
            }
        }
    }
    monthCells(month).chunked(7).forEach { week ->
        Row(Modifier.fillMaxWidth()) {
            week.forEach { date ->
                if (date == null) Spacer(Modifier.weight(1f).height(JournalCalendarStyle.dayHeight))
                else CalendarDay(date, counts[date] ?: 0, date == today, date == selected,
                    Modifier.weight(1f)) { onDay(date) }
            }
        }
    }
}

@Composable private fun CalendarDay(date: LocalDate, count: Int, isToday: Boolean, isSelected: Boolean,
    modifier: Modifier, onClick: () -> Unit) {
    Column(modifier.heightIn(min = JournalCalendarStyle.dayHeight)
        .then(if (count > 0) Modifier.clickable(interactionSource = null, indication = null, role = Role.Button, onClick = onClick) else Modifier)
        .testTag("calendar-day-$date").semantics(mergeDescendants = true) {
            contentDescription = date.format(DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy"))
            stateDescription = (if (isToday) "Today. " else "") + checkIns(count)
            selected = isSelected
        }.padding(vertical = JournalSpacing.tiny), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.defaultMinSize(JournalCalendarStyle.dateMinimumSize, JournalCalendarStyle.dateMinimumSize)
            .then(if (isToday) Modifier.border(1.dp, MaterialTheme.colorScheme.primary, CircleShape) else Modifier)
            .then(if (isSelected) Modifier.background(MaterialTheme.colorScheme.primaryContainer, CircleShape) else Modifier)
            .padding(JournalSpacing.tiny), contentAlignment = Alignment.Center) {
            Text(date.dayOfMonth.toString(), style = MaterialTheme.typography.bodyMedium,
                color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else if (isToday) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.clearAndSetSemantics {})
        }
        Spacer(Modifier.height(JournalSpacing.tiny))
        if (count > 0) Box(Modifier.size(JournalCalendarStyle.dotSize).background(MaterialTheme.colorScheme.primary, CircleShape)
            .testTag("calendar-dot-$date"))
        else Spacer(Modifier.size(JournalCalendarStyle.dotSize))
    }
}
