package com.localjournal.fitness

import android.app.KeyguardManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.PowerManager
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toDrawable
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.TextView
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveableStateHolder
import androidx.compose.ui.graphics.toArgb
import androidx.core.view.WindowCompat
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.localjournal.fitness.core.design.*
import com.localjournal.fitness.core.navigation.JournalNavigation
import com.localjournal.fitness.core.security.*
import com.localjournal.fitness.data.preferences.ThemeMode
import kotlinx.coroutines.launch

class MainActivity : FragmentActivity() {
    private lateinit var cover: FrameLayout
    private lateinit var coverLabel: TextView
    private lateinit var privateRoot: View
    private lateinit var nativeAuthentication: NativeAuthentication
    private val graph get() = application as JournalApplication
    private var resumed = false
    private var topResumed = false
    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) { updateForeground() }
    }
    private fun updateForeground() {
        val interactive = getSystemService(PowerManager::class.java).isInteractive
        val keyguard = getSystemService(KeyguardManager::class.java).isKeyguardLocked
        val visible = resumed && topResumed && interactive && !keyguard
        if (visible) graph.session.resume() else { coverNow(); graph.session.pause() }
        applyPrivacyCover(graph.session.state.value)
    }
    private var renderedPrivate = false
    private var renderKnown = false
    private fun coverNow() {
        if (::cover.isInitialized) {
            cover.visibility = View.VISIBLE
            privateRoot.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS
        }
    }
    private fun mayReveal(state: AccessState) = resumed && state.ready && state.purpose == null && !state.busy && renderKnown &&
        (if (state.canShowPrivate) renderedPrivate else !renderedPrivate)
    private fun applyPrivacyCover(state: AccessState) {
        if (!::cover.isInitialized) return
        coverLabel.text = if (resumed && state.canShowPrivate && renderKnown && !renderedPrivate)
            getString(R.string.opening_journal) else getString(R.string.app_name)
        if (!mayReveal(state)) { coverNow(); return }
        // Wait for Compose's replacement branch to be applied/drawn; never reveal a stale private frame on resume.
        cover.postOnAnimation {
            if (mayReveal(graph.session.state.value)) {
                cover.visibility = View.GONE
                privateRoot.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_AUTO
            }
        }
    }
    private fun authenticate(purpose: AuthenticationPurpose) {
        coverNow() // Synchronous native cover BEFORE the system authentication window opens.
        nativeAuthentication.authenticate(purpose)
        applyPrivacyCover(graph.session.state.value)
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) setRecentsScreenshotEnabled(false)
        // No FLAG_SECURE: ordinary screenshots/recordings remain available.
        enableEdgeToEdge()
        nativeAuthentication = NativeAuthentication(this, graph.session)
        ContextCompat.registerReceiver(this, screenReceiver, IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF); addAction(Intent.ACTION_SCREEN_ON); addAction(Intent.ACTION_USER_PRESENT)
        }, ContextCompat.RECEIVER_NOT_EXPORTED)
        setContent {
            val model: JournalViewModel = viewModel(factory = viewModelFactory {
                initializer { JournalViewModel(graph.repository, graph.preferences, contentResolver, graph.camera,
                    graph.localDates, graph.exporter, graph.maintenance, graph) }
            })
            val theme by model.theme.collectAsStateWithLifecycle()
            val state by model.state.collectAsStateWithLifecycle()
            val access by graph.session.state.collectAsStateWithLifecycle()
            val generation by model.generation.collectAsStateWithLifecycle()
            var darkCanvas by remember { mutableStateOf(false) }
            val privateVisible = access.canShowPrivate && state !is FoundationState.Loading
            val dark = theme == ThemeMode.DARK || (theme == ThemeMode.SYSTEM && isSystemInDarkTheme())
            val holder = rememberSaveableStateHolder()
            var previousGeneration by remember { mutableIntStateOf(generation) }
            LaunchedEffect(generation) {
                if (previousGeneration != generation) holder.removeState("journal-$previousGeneration")
                previousGeneration = generation
            }
            JournalTheme(theme) {
                val background = if (privateVisible && darkCanvas) JournalColors.comparisonCanvas.toArgb() else MaterialTheme.colorScheme.background.toArgb()
                val foreground = MaterialTheme.colorScheme.onBackground.toArgb()
                SideEffect {
                    renderedPrivate = privateVisible
                    renderKnown = true
                    applyPrivacyCover(access)
                    window.setBackgroundDrawable(background.toDrawable())
                    if (::cover.isInitialized) { cover.setBackgroundColor(background); coverLabel.setTextColor(foreground) }
                    WindowCompat.getInsetsController(window, window.decorView).apply {
                        isAppearanceLightStatusBars = !(dark || (privateVisible && darkCanvas))
                        isAppearanceLightNavigationBars = !(dark || (privateVisible && darkCanvas))
                    }
                }
                Surface(color = MaterialTheme.colorScheme.background) {
                    if (privateVisible) holder.SaveableStateProvider("journal-$generation") {
                        JournalNavigation(model, state, theme, model::setTheme, model::retry,
                            { darkCanvas = it }, access, ::authenticate, nativeAuthentication::openSecuritySettings)
                    } else LockScreen(access, nativeAuthentication.available(), state is FoundationState.Loading && access.canShowPrivate,
                        { authenticate(AuthenticationPurpose.UNLOCK) }, nativeAuthentication::openSecuritySettings)
                }
            }
        }
        val content = findViewById<ViewGroup>(android.R.id.content)
        privateRoot = content.getChildAt(0)
        coverLabel = TextView(this).apply { setText(R.string.app_name); textSize = 20f; gravity = Gravity.CENTER }
        cover = FrameLayout(this).apply {
            setBackgroundColor(android.graphics.Color.rgb(250,250,250))
            isClickable = true; importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_YES
            addView(coverLabel, FrameLayout.LayoutParams(-1,-1))
        }
        content.addView(cover, ViewGroup.LayoutParams(-1,-1))
        coverNow()
        lifecycleScope.launch { graph.session.state.collect { applyPrivacyCover(it) } }
    }
    override fun onResume() { super.onResume(); resumed = true; updateForeground() }
    override fun onTopResumedActivityChanged(isTopResumedActivity: Boolean) {
        super.onTopResumedActivityChanged(isTopResumedActivity)
        topResumed = isTopResumedActivity
        updateForeground()
    }
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus || getSystemService(KeyguardManager::class.java).isKeyguardLocked) updateForeground()
    }
    override fun onDestroy() { unregisterReceiver(screenReceiver); super.onDestroy() }
    override fun onPause() { coverNow(); resumed = false; graph.session.pause(); super.onPause() }
    override fun onStop() {
        if (isChangingConfigurations) graph.session.configurationChange()
        super.onStop()
    }
}
