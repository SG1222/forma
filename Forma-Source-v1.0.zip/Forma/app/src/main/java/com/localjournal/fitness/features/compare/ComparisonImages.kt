package com.localjournal.fitness.features.compare

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.focusable
import androidx.compose.foundation.gestures.*
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.key.*
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.*
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import coil3.compose.AsyncImage
import com.localjournal.fitness.core.design.*
import java.io.File
import kotlin.math.roundToInt

@Composable internal fun ComparisonImage(file: File?, transform: () -> PhotoTransform, modifier: Modifier = Modifier,
    onSize: (Size) -> Unit = {}) {
    var failed by remember(file) { mutableStateOf(file == null) }
    var loading by remember(file) { mutableStateOf(file != null) }
    Box(modifier.fillMaxSize().background(JournalColors.comparisonCanvas).clipToBounds(), contentAlignment = Alignment.Center) {
        if (file != null) AsyncImage(model = file, contentDescription = null, contentScale = ContentScale.Fit,
            modifier = Modifier.fillMaxSize().graphicsLayer {
                val value = transform()
                scaleX = value.zoom; scaleY = value.zoom
                translationX = value.x * size.width; translationY = value.y * size.height
            }, onSuccess = {
                onSize(it.painter.intrinsicSize); failed = false; loading = false
            }, onError = { failed = true; loading = false })
        if (loading) Text("Opening photograph…", color = Color.LightGray, style = MaterialTheme.typography.bodyMedium)
        if (failed) Text("Photo unavailable. Choose another photograph above.", color = Color.White,
            style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(JournalSpacing.standard))
    }
}

/** Input remains in viewport coordinates; the image alone is transformed and clipped. */
@Composable internal fun ComparisonPane(file: File?, slot: PhotoSlot, transform: () -> PhotoTransform,
    onTransform: (PhotoTransform) -> Unit, modifier: Modifier = Modifier) {
    var viewport by remember { mutableStateOf(Size.Zero) }
    var intrinsic by remember(file) { mutableStateOf(Size.Zero) }
    val transformProvider by rememberUpdatedState(transform)
    fun current() = transformProvider()
    val change by rememberUpdatedState(onTransform)
    val center = { Offset(viewport.width / 2, viewport.height / 2) }
    fun zoom() { change(if (current().zoom > 1.01f) PhotoTransform() else current().move(center(), Offset.Zero, JournalComparisonStyle.doubleTapZoom, viewport, intrinsic, false)) }
    Box(modifier.clipToBounds().onSizeChanged { viewport = Size(it.width.toFloat(), it.height.toFloat()) }
        .testTag("compare-pane-${slot.name}").semantics {
            contentDescription = "Photo ${slot.name}. Pinch to zoom; drag to pan; double tap to reset or zoom."
            stateDescription = "Zoom ${"%.2f".format(java.util.Locale.ROOT, current().zoom)}; pan ${current().x}, ${current().y}"
            customActions = listOf(CustomAccessibilityAction("Zoom or reset photo ${slot.name}") { zoom(); true },
                CustomAccessibilityAction("Pan left") { change(current().move(center(), Offset(viewport.width * -0.1f, 0f), 1f, viewport, intrinsic, false)); true },
                CustomAccessibilityAction("Pan right") { change(current().move(center(), Offset(viewport.width * 0.1f, 0f), 1f, viewport, intrinsic, false)); true },
                CustomAccessibilityAction("Pan up") { change(current().move(center(), Offset(0f, -viewport.height * 0.1f), 1f, viewport, intrinsic, false)); true },
                CustomAccessibilityAction("Pan down") { change(current().move(center(), Offset(0f, viewport.height * 0.1f), 1f, viewport, intrinsic, false)); true })
        }.pointerInput(file) {
            detectTransformGestures { centroid, pan, scale, _ -> change(current().move(centroid, pan, scale, viewport, intrinsic, false)) }
        }.pointerInput(file) { detectTapGestures(onDoubleTap = { point ->
            change(if (current().zoom > 1.01f) PhotoTransform() else current().move(point, Offset.Zero, JournalComparisonStyle.doubleTapZoom, viewport, intrinsic, false))
        }) }) {
        ComparisonImage(file, transform, onSize = { intrinsic = it })
    }
}

@Composable internal fun SliderComparison(first: File?, second: File?, state: ComparisonState, modifier: Modifier = Modifier) {
    var viewport by remember { mutableStateOf(Size.Zero) }
    var sizeA by remember(first) { mutableStateOf(Size.Zero) }
    var sizeB by remember(second) { mutableStateOf(Size.Zero) }
    val handleWidth = with(LocalDensity.current) { JournalSpacing.touchTarget.toPx() }
    fun move(centroid: Offset, pan: Offset, factor: Float) {
        if (state.alignment != AlignmentTarget.B) state.sliderA = state.sliderA.move(centroid, pan, factor, viewport, sizeA, true)
        if (state.alignment != AlignmentTarget.A) state.sliderB = state.sliderB.move(centroid, pan, factor, viewport, sizeB, true)
    }
    fun reveal(value: Float) { state.divider = value.coerceIn(0f, 1f) }
    Box(modifier.clipToBounds().testTag("compare-slider")
        .onSizeChanged { viewport = Size(it.width.toFloat(), it.height.toFloat()) }
        .semantics {
            contentDescription = "Overlapping photographs. Pinch or drag to align ${state.alignment.name.lowercase()}."
            stateDescription = "A zoom ${state.sliderA.zoom}; pan ${state.sliderA.x}, ${state.sliderA.y}; B zoom ${state.sliderB.zoom}; pan ${state.sliderB.x}, ${state.sliderB.y}"
            customActions = listOf(CustomAccessibilityAction("Zoom selected alignment") {
                move(Offset(viewport.width/2, viewport.height/2), Offset.Zero, 1.5f); true
            }, CustomAccessibilityAction("Move selected alignment left") {
                move(Offset(viewport.width/2, viewport.height/2), Offset(-viewport.width * 0.1f, 0f), 1f); true
            }, CustomAccessibilityAction("Move selected alignment right") {
                move(Offset(viewport.width/2, viewport.height/2), Offset(viewport.width * 0.1f, 0f), 1f); true
            }, CustomAccessibilityAction("Move selected alignment up") {
                move(Offset(viewport.width/2, viewport.height/2), Offset(0f, -viewport.height * 0.1f), 1f); true
            }, CustomAccessibilityAction("Move selected alignment down") {
                move(Offset(viewport.width/2, viewport.height/2), Offset(0f, viewport.height * 0.1f), 1f); true
            })
        }
        .pointerInput(first, second) { detectTransformGestures { centroid, pan, factor, _ -> move(centroid, pan, factor) } }
        .pointerInput(first, second) { detectTapGestures(onDoubleTap = {
            if (state.sliderA.zoom > 1.01f || state.sliderB.zoom > 1.01f) state.reset()
            else move(it, Offset.Zero, JournalComparisonStyle.doubleTapZoom)
        }) }) {
        ComparisonImage(second, { state.sliderB }, onSize = { sizeB = it })
        // Clip the OVERLAY in fixed viewport coordinates. Moving the divider never changes either image's transform.
        Box(Modifier.fillMaxSize().drawWithContent {
            clipRect(right = size.width * state.divider) { this@drawWithContent.drawContent() }
        }) { ComparisonImage(first, { state.sliderA }, onSize = { sizeA = it }) }
        Canvas(Modifier.fillMaxSize()) {
            val x = size.width * state.divider
            drawLine(Color.Black.copy(alpha = 0.4f), Offset(x, 0f), Offset(x, size.height), 3.dp.toPx())
            drawLine(Color.White, Offset(x, 0f), Offset(x, size.height), 1.dp.toPx())
        }
        // Only the central handle claims divider drags. Elsewhere one/two fingers align images.
        Box(Modifier.align(Alignment.CenterStart).offset { IntOffset((viewport.width * state.divider - handleWidth / 2)
                .coerceIn(0f, maxOf(0f, viewport.width - handleWidth)).roundToInt(), 0) }
            .size(JournalSpacing.touchTarget).testTag("comparison-divider")
            .semantics {
                contentDescription = "Comparison divider"
                stateDescription = "${(state.divider * 100).roundToInt()} percent photo A"
                progressBarRangeInfo = ProgressBarRangeInfo(state.divider, 0f..1f)
                setProgress { reveal(it); true }
                customActions = listOf(CustomAccessibilityAction("Reveal more of photo A") { reveal(state.divider + 0.1f); true },
                    CustomAccessibilityAction("Reveal more of photo B") { reveal(state.divider - 0.1f); true })
            }.onKeyEvent {
                if (it.type != KeyEventType.KeyDown) false else when (it.key) {
                    Key.DirectionLeft -> { reveal(state.divider - 0.05f); true }
                    Key.DirectionRight -> { reveal(state.divider + 0.05f); true }
                    else -> false
                }
            }.focusable()
            .draggable(rememberDraggableState { delta -> if (viewport.width > 0) reveal(state.divider + delta / viewport.width) }, Orientation.Horizontal),
            contentAlignment = Alignment.Center) {
            Box(Modifier.size(width = 28.dp, height = 36.dp).background(Color.White, JournalCorners.control)
                .border(1.dp, Color.Black.copy(alpha = 0.15f), JournalCorners.control), contentAlignment = Alignment.Center) {
                Text("‹ ›", color = JournalColors.comparisonCanvas, style = MaterialTheme.typography.titleMedium)
            }
        }
    }
}
