package com.localjournal.fitness.features.settings

import android.text.format.Formatter
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.foundation.selection.toggleable
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import com.localjournal.fitness.core.design.*
import com.localjournal.fitness.core.security.*
import com.localjournal.fitness.data.preferences.ThemeMode
import com.localjournal.fitness.data.repositories.JournalStorageInfo

@Composable fun SettingsScreen(theme: ThemeMode, onTheme: (ThemeMode) -> Unit, onBack: () -> Unit,
    access: AccessState, onAuthenticate: (AuthenticationPurpose) -> Unit, onSecuritySettings: () -> Unit,
    storage: JournalStorageInfo?, storageError: String?, onRefreshStorage: () -> Unit,
    working: Boolean, onDeleteAll: () -> Unit) {
    var confirmDeletion by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { onRefreshStorage() }
    JournalScreen("Settings", leading = {
        IconButton(onClick = onBack, enabled = !working) { Icon(Icons.AutoMirrored.Outlined.ArrowBack, "Back to Log") }
    }) {
        Text("Privacy", style = MaterialTheme.typography.titleMedium)
        Row(Modifier.fillMaxWidth().heightIn(min = JournalSpacing.touchTarget)
            .toggleable(value = access.enabled, enabled = !working, role = Role.Switch,
                onValueChange = { onAuthenticate(if(it) AuthenticationPurpose.ENABLE_LOCK else AuthenticationPurpose.DISABLE_LOCK) })
            .testTag("require-authentication"), verticalAlignment = Alignment.CenterVertically) {
            Text("Require authentication", style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
            Switch(checked = access.enabled, onCheckedChange = null, enabled = !working)
        }
        SecondaryText("Photos are stored privately on this device.")
        Text("Uses your device's supported biometrics or screen lock. Returning after 30 seconds requires authentication.",
            style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = JournalSpacing.small))
        access.message?.let {
            Text(it, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(top = JournalSpacing.small))
            JournalTertiaryButton(onClick = onSecuritySettings) { Text("Android security settings") }
        }
        SettingsSeparator()
        Text("Appearance", style = MaterialTheme.typography.titleMedium)
        Column(Modifier.selectableGroup()) {
            ThemeMode.entries.forEach { mode ->
                Row(Modifier.fillMaxWidth().heightIn(min = JournalSpacing.touchTarget)
                    .selectable(selected = theme == mode, enabled = !working, role = Role.RadioButton, onClick = { onTheme(mode) }),
                    verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected = theme == mode, onClick = null)
                    Spacer(Modifier.width(JournalSpacing.compact))
                    Text(when(mode) { ThemeMode.SYSTEM -> "System theme"; ThemeMode.LIGHT -> "Light theme"; ThemeMode.DARK -> "Dark theme" },
                        style = MaterialTheme.typography.bodyLarge)
                }
            }
        }
        SettingsSeparator()
        Text("Storage", style = MaterialTheme.typography.titleMedium)
        if (storage != null) {
            StorageRow("Photos", storage.photoCount.toString(), "storage-photo-count")
            StorageRow("Storage used", Formatter.formatShortFileSize(LocalContext.current, storage.bytes), "storage-bytes")
        } else Text(storageError ?: "Calculating journal storage…", style = MaterialTheme.typography.bodyMedium)
        if (storageError != null) JournalTertiaryButton(onClick = onRefreshStorage) { Text("Retry storage calculation") }
        Text("Includes originals, previews and unfinished check-ins. Gallery exports are separate.", style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
        SettingsSeparator()
        Text("Data", style = MaterialTheme.typography.titleMedium)
        JournalTertiaryButton(onClick = { confirmDeletion = true }, enabled = !working,
            destructive = true) { Text("Delete all data") }
        if (working) Text("Deleting private journal…", style = MaterialTheme.typography.bodyMedium)
        Text("Gallery copies stay on your phone. App lock stays as you set it. Appearance and export notices reset.",
            style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(JournalSpacing.small))
        Text("Uninstalling removes this private journal. The app has no internet access. Android backup is disabled; device-transfer behavior can vary by manufacturer.",
            style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
    if (confirmDeletion) AlertDialog(onDismissRequest = { confirmDeletion = false }, title = { Text("Delete all data?") },
        text = { Text("All photos and check-ins stored in this app will be permanently deleted. This cannot be undone.") },
        confirmButton = { JournalTertiaryButton(onClick = { confirmDeletion = false; onDeleteAll() },
            destructive = true) { Text("Delete all data") } },
        dismissButton = { JournalTertiaryButton(onClick = { confirmDeletion = false }) { Text("Cancel") } })
}
@Composable private fun SettingsSeparator() {
    Spacer(Modifier.height(JournalSpacing.section)); HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
    Spacer(Modifier.height(JournalSpacing.section))
}
@Composable private fun StorageRow(label: String, value: String, tag: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = JournalSpacing.compact), horizontalArrangement = Arrangement.spacedBy(JournalSpacing.standard)) {
        Text(label, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
        Text(value, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.testTag(tag))
    }
}
