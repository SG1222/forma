package com.localjournal.fitness.features.log

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.Dp
import com.localjournal.fitness.*
import com.localjournal.fitness.core.design.*
import java.time.YearMonth
import java.time.format.DateTimeFormatter

@Composable fun LogScreen(state: FoundationState, library: LibraryState, drafts: Map<String, Int>,
    onSettings: () -> Unit, onRetry: () -> Unit, onAdd: () -> Unit,
    onDraft: (String) -> Unit, onPhoto: (String, String) -> Unit, grid: LazyGridState, dockClearance: Dp = 0.dp) {
    val months = remember(library.entries) {
        library.entries.groupBy { YearMonth.from(it.checkInDate) }.toSortedMap(compareByDescending { it })
    }
    Box(Modifier.fillMaxSize()) {
        LazyVerticalGrid(columns = GridCells.Fixed(3), state = grid,
            modifier = Modifier.fillMaxSize().testTag("photo-grid"),
            horizontalArrangement = Arrangement.spacedBy(JournalSpacing.gridGutter),
            verticalArrangement = Arrangement.spacedBy(JournalSpacing.gridGutter),
            contentPadding = PaddingValues(bottom = dockClearance + 88.dp)) {
            item(key = "heading", span = { GridItemSpan(maxLineSpan) }) {
                Row(Modifier.fillMaxWidth().padding(horizontal = JournalSpacing.standard)
                    .padding(top = JournalSpacing.compact, bottom = JournalSpacing.standard),
                    verticalAlignment = Alignment.CenterVertically) {
                    Text("Log", style = MaterialTheme.typography.headlineLarge, modifier = Modifier.weight(1f))
                    IconButton(onClick = onSettings) { Icon(Icons.Outlined.Settings, "Settings") }
                }
            }
            drafts.forEach { (id, count) ->
                item(key = "draft-$id", span = { GridItemSpan(maxLineSpan) }) {
                    JournalTertiaryButton(onClick = { onDraft(id) }, modifier = Modifier.padding(horizontal = JournalSpacing.small)) {
                        Text("Resume check-in · $count ${if (count == 1) "photo" else "photos"}")
                    }
                }
            }
            if (state is FoundationState.Loading || !library.loaded) {
                item(span = { GridItemSpan(maxLineSpan) }) {
                    Text("Opening private journal…", modifier = Modifier.padding(JournalSpacing.standard))
                }
            }
            if (state is FoundationState.Error) {
                item(span = { GridItemSpan(maxLineSpan) }) {
                    Column(Modifier.padding(JournalSpacing.standard)) {
                        Text(state.message); JournalTertiaryButton(onClick = onRetry) { Text("Try again") }
                    }
                }
            }
            if (library.loaded && library.entries.isEmpty() && state is FoundationState.Ready) {
                item(key = "empty", span = { GridItemSpan(maxLineSpan) }) {
                    Column(Modifier.padding(JournalSpacing.standard)) {
                        Text("Your photo journal is empty.", style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(JournalSpacing.small))
                        SecondaryText("Take a photo or import one to begin.")
                        Spacer(Modifier.height(JournalSpacing.section))
                        JournalPrimaryButton(onClick = onAdd) { Text("Add photos") }
                    }
                }
            }
            if (state !is FoundationState.Loading && library.loaded) months.forEach { (month, entries) ->
                item(key = "month-$month", span = { GridItemSpan(maxLineSpan) }) {
                    Text(month.format(DateTimeFormatter.ofPattern("MMMM yyyy")),
                        style = MaterialTheme.typography.titleMedium,
                        modifier = Modifier.padding(horizontal = JournalSpacing.standard)
                            .padding(top = JournalSpacing.standard, bottom = JournalSpacing.compact))
                }
                entries.forEach { checkIn ->
                    items(checkIn.photos, key = { it.id }, contentType = { "photo" }) { photo ->
                        val description = "Photo ${photo.sortOrder + 1}, ${checkIn.checkInDate}"
                        PrivateImage(library.assets[photo.id]?.thumbnail,
                            description, Modifier.fillMaxWidth().aspectRatio(1f).testTag("photo-${photo.id}")
                                .clickable { onPhoto(checkIn.id, photo.id) }, ContentScale.Crop)
                    }
                }
            }
        }
        FloatingActionButton(onClick = onAdd, modifier = Modifier.align(Alignment.BottomEnd)
            .padding(start = JournalSpacing.standard, end = JournalSpacing.standard,
                top = JournalSpacing.standard, bottom = dockClearance + JournalSpacing.standard), shape = androidx.compose.foundation.shape.CircleShape,
            containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = JournalActionStyle.materialOpacity), contentColor = MaterialTheme.colorScheme.onPrimaryContainer,
            elevation = FloatingActionButtonDefaults.elevation(0.dp, 0.dp, 0.dp, 0.dp)) {
            Icon(Icons.Outlined.Add, "Add photographs")
        }
    }
}
