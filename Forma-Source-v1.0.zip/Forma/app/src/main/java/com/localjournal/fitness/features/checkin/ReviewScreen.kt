package com.localjournal.fitness.features.checkin

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.localjournal.fitness.DraftState
import com.localjournal.fitness.core.design.*
import com.localjournal.fitness.data.models.PhotoLabel

@Composable fun ReviewScreen(state: DraftState, onClose: () -> Unit, onSave: () -> Unit,
    onChange: (String, String?, PhotoLabel?) -> Unit, onRemove: (String) -> Unit,
    onDiscard: () -> Unit, onCamera: () -> Unit, onImport: () -> Unit) {
    var discard by remember { mutableStateOf(false) }
    BackHandler { if (!state.busy) onClose() }
    val session = state.session
    BoxWithConstraints(Modifier.fillMaxSize().imePadding()) {
        val pictureHeight = (maxHeight * 0.48f).coerceIn(180.dp, 420.dp)
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onClose, enabled = !state.busy) { Icon(Icons.AutoMirrored.Outlined.ArrowBack, "Close review") }
                Text("Check-in", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                JournalTertiaryButton(onClick = { discard = true }, enabled = !state.busy) { Text("Discard") }
            }
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
                if (state.importTotal > 0) {
                    Text("Copying ${state.importProgress} of ${state.importTotal} photographs…",
                        modifier = Modifier.padding(JournalSpacing.standard))
                    LinearProgressIndicator(progress = { state.importProgress.toFloat() / state.importTotal },
                        modifier = Modifier.fillMaxWidth().padding(horizontal = JournalSpacing.standard))
                }
                if (session == null) {
                    Text(if (state.busy) "Opening check-in…" else "This check-in could not be opened.",
                        modifier = Modifier.padding(JournalSpacing.standard))
                } else if (session.photos.isEmpty()) {
                    Text(if (state.importTotal > 0) "Photographs will appear here as soon as copying finishes." else "No photographs in this check-in.", modifier = Modifier.padding(JournalSpacing.standard))
                    Row { JournalTertiaryButton(onClick = onCamera, enabled = !state.busy) { Text("Take Photo") }
                        JournalTertiaryButton(onClick = onImport, enabled = !state.busy) { Text("Import Photos") } }
                } else {
                    val pager = rememberPagerState(pageCount = { session.photos.size })
                    HorizontalPager(state = pager, key = { session.photos[it].id },
                        modifier = Modifier.fillMaxWidth().height(pictureHeight).testTag("review-pager")) { page ->
                        val photo = session.photos[page]
                        PrivateImage(session.previewFiles[photo.id], "Review photograph ${page + 1}", Modifier.fillMaxSize())
                    }
                    val photo = session.photos[pager.currentPage.coerceAtMost(session.photos.lastIndex)]
                    Row(Modifier.fillMaxWidth().padding(horizontal = JournalSpacing.small),
                        verticalAlignment = Alignment.CenterVertically) {
                        Text("${pager.currentPage + 1} of ${session.photos.size}", style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier.padding(horizontal = JournalSpacing.small).weight(1f))
                        LabelSelector(photo.label, !state.busy) { onChange(session.note, photo.id, it) }
                        IconButton(onClick = { onRemove(photo.id) }, enabled = !state.busy) { Icon(Icons.Outlined.Delete, "Remove from check-in") }
                    }
                    OutlinedTextField(value = session.note, onValueChange = { onChange(it, null, null) },
                        label = { Text("Note (optional)") }, enabled = !state.busy,
                        modifier = Modifier.fillMaxWidth().padding(horizontal = JournalSpacing.standard).testTag("review-note"),
                        minLines = 2, maxLines = 4)
                    Text("Dated when you save.", style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(JournalSpacing.standard))
                }
                state.error?.let { Text(it, color = MaterialTheme.colorScheme.error,
                    modifier = Modifier.padding(JournalSpacing.standard)) }
            }
            JournalPrimaryButton(onClick = onSave, enabled = !state.busy && !session?.photos.isNullOrEmpty(),
                
                modifier = Modifier.fillMaxWidth().padding(JournalSpacing.standard)) {
                Text(if (state.busy) "Keeping photographs…" else "Save Check-in")
            }
        }
    }
    if (discard) AlertDialog(onDismissRequest = { discard = false },
        title = { Text("Discard this check-in?") },
        text = { Text("Its unfinished photographs and note will be permanently removed. Saved check-ins are kept.") },
        confirmButton = { JournalTertiaryButton(onClick = { discard = false; onDiscard() }) { Text("Discard check-in") } },
        dismissButton = { JournalTertiaryButton(onClick = { discard = false }) { Text("Keep editing") } })
}
