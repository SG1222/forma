package com.localjournal.fitness.features.streaks

import com.localjournal.fitness.data.models.CheckInDay
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth
import java.time.temporal.TemporalAdjusters

/** Derived values only; the saved local date is never converted through a device timezone. */
data class StreakStatistics(val currentWeeks: Int, val longestWeeks: Int, val totalCheckIns: Int,
                            val checkInsByDate: Map<LocalDate, Int>)

fun mondayOf(date: LocalDate): LocalDate = date.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))

fun calculateWeeklyStreaks(savedDates: Iterable<LocalDate>, today: LocalDate): StreakStatistics =
    calculateWeeklyStreaksByDay(savedDates.groupingBy { it }.eachCount().map { CheckInDay(it.key, it.value) }, today)

/** Room supplies one row per date; no photograph decoding or mutable streak counter is involved. */
fun calculateWeeklyStreaksByDay(savedDays: List<CheckInDay>, today: LocalDate): StreakStatistics {
    val counts = savedDays.filter { it.count > 0 }.groupBy { it.checkInDate }
        .mapValues { (_, rows) -> rows.sumOf { it.count } }
    val weeks = counts.keys.map(::mondayOf).toSortedSet()
    var longest = 0
    var run = 0
    var previous: LocalDate? = null
    for (week in weeks) {
        run = if (previous?.plusWeeks(1) == week) run + 1 else 1
        longest = maxOf(longest, run)
        previous = week
    }
    val currentMonday = mondayOf(today)
    var cursor = if (currentMonday in weeks) currentMonday else currentMonday.minusWeeks(1)
    var current = 0
    while (cursor in weeks) { current++; cursor = cursor.minusWeeks(1) }
    return StreakStatistics(current, longest, counts.values.sum(), counts)
}

/** Leading/trailing blanks form complete Monday-first rows, including Sunday-start months. */
fun monthCells(month: YearMonth): List<LocalDate?> {
    val leading = month.atDay(1).dayOfWeek.value - 1
    val used = leading + month.lengthOfMonth()
    val size = ((used + 6) / 7) * 7
    return List(size) { index -> (index - leading + 1).takeIf { it in 1..month.lengthOfMonth() }?.let(month::atDay) }
}

data class StreaksState(val today: LocalDate? = null, val statistics: StreakStatistics? = null,
                        val error: String? = null)
