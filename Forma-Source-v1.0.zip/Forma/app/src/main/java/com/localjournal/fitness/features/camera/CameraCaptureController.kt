package com.localjournal.fitness.features.camera

import android.content.Context
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.core.content.ContextCompat
import com.localjournal.fitness.data.repositories.JournalRepository
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/** CameraX owns only a private pending file; the repository owns draft publication. */
class CameraCaptureController(private val context: Context, private val repository: JournalRepository) {
    suspend fun capture(draftId: String, imageCapture: ImageCapture) {
        val file = repository.reserveCapture(draftId)
        try {
            suspendCancellableCoroutine { continuation ->
                imageCapture.takePicture(ImageCapture.OutputFileOptions.Builder(file).build(),
                    ContextCompat.getMainExecutor(context), object : ImageCapture.OnImageSavedCallback {
                        override fun onImageSaved(result: ImageCapture.OutputFileResults) {
                            if (continuation.isActive) continuation.resume(Unit)
                        }
                        override fun onError(error: ImageCaptureException) {
                            if (continuation.isActive) continuation.resumeWithException(error)
                        }
                    })
            }
            repository.completeCapture(draftId, file)
        } finally {
            withContext(NonCancellable) { repository.abandonCapture(draftId, file) }
        }
    }
}
