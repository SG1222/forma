package com.localjournal.fitness.core.design

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.runtime.getValue
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.runtime.Composable

/** Workspace controls use Forma's teal/neutral roles, never library-default purple. */
object JournalComparisonStyle {
    const val selectedOpacity = 0.14f
    const val maximumZoom = 5f
    const val doubleTapZoom = 2.5f
}

@Composable fun comparisonSegmentColors(selected: Boolean): androidx.compose.material3.SegmentedButtonColors {
    val container by animateColorAsState(if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.background,
        tween(JournalMotion.selectionMillis), label = "Compare mode surface")
    val ink by animateColorAsState(if (selected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onBackground,
        tween(JournalMotion.selectionMillis), label = "Compare mode label")
    return SegmentedButtonDefaults.colors(
    activeContainerColor = container,
    activeContentColor = ink,
    activeBorderColor = MaterialTheme.colorScheme.outlineVariant,
    inactiveContainerColor = container,
    inactiveContentColor = ink,
    inactiveBorderColor = MaterialTheme.colorScheme.outlineVariant)

}
