package com.localjournal.fitness.data.repositories

import androidx.room.withTransaction
import com.localjournal.fitness.core.storage.*
import com.localjournal.fitness.data.database.*
import com.localjournal.fitness.data.models.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.flowOn
import java.io.InputStream
import java.io.File
import java.time.Clock
import java.time.Instant

data class JournalStorageInfo(val photoCount: Int, val bytes: Long)
interface JournalRepository {
    suspend fun storageInfo(): JournalStorageInfo
    suspend fun originalForExport(id: String): File
    suspend fun deleteAllJournalData()
    suspend fun finishDeletion()
    suspend fun deletionPending(): Boolean
    val checkInDays: kotlinx.coroutines.flow.Flow<List<CheckInDay>>
    val checkIns: kotlinx.coroutines.flow.Flow<List<CheckIn>>
    suspend fun createDraft(): String
    suspend fun stagePhoto(draftId: String, source: PhotoSource, input: InputStream,
                           originalCaptureDate: Instant? = null, label: PhotoLabel? = null): DraftPhoto
    suspend fun recoverDrafts(): Map<String, List<DraftPhoto>>
    suspend fun discardDraft(draftId: String)
    suspend fun commitDraft(draftId: String, orderedPhotoIds: List<String>, note: String? = null): String
    suspend fun deleteCheckIn(id: String)
    suspend fun loadDraft(id: String): DraftSession?
    suspend fun updateDraft(id: String, note: String, labels: Map<String, PhotoLabel?>)
    suspend fun removeDraftPhoto(id: String, photoId: String)
    suspend fun photoAssets(photos: List<Photo>): Map<String, PhotoAssets>
    suspend fun reserveCapture(id: String): File
    suspend fun completeCapture(id: String, file: File): DraftPhoto
    suspend fun abandonCapture(id: String, file: File)
    suspend fun editPhoto(id: String, note: String?, label: PhotoLabel?)
    suspend fun deletePhoto(id: String)
    suspend fun reconcile(): StorageReport
}
data class StorageReport(val missingOriginalIds: List<String>, val unreadableThumbnailIds: List<String>)

internal class LocalJournalRepository(private val database: JournalDatabase,
    private val files: PrivatePhotoStore, private val clock: Clock = Clock.systemUTC(),
    private val zoneProvider: () -> java.time.ZoneId = java.time.ZoneId::systemDefault) : JournalRepository {
    private val mutex = Mutex()
    private val dao = database.journalDao()
    override val checkInDays = dao.observeCheckInDays()
    override val checkIns = dao.observeCheckIns().map { rows -> rows.map { it.toModel() } }.flowOn(Dispatchers.Default)
    private suspend fun <T> disk(allowDeletion: Boolean = false, block: suspend () -> T): T = withContext(Dispatchers.IO) {
        mutex.withLock {
            if (!allowDeletion && files.deletionPending()) throw java.io.IOException("Deletion cleanup is pending. Retry Delete all data.")
            block()
        }
    }
    override suspend fun storageInfo() = disk(true) {
        val path = database.openHelper.writableDatabase.path ?: ""
        val databaseBytes = listOf(path, "$path-wal", "$path-shm").sumOf { File(it).takeIf(File::isFile)?.length() ?: 0L }
        JournalStorageInfo(dao.totalPhotoCount(), files.journalBytes() + databaseBytes)
    }
    override suspend fun originalForExport(id: String) = disk {
        val photo = dao.photo(id) ?: throw java.io.IOException("This photograph is no longer saved.")
        files.resolve(photo.originalFilePath)
    }
    override suspend fun deletionPending() = disk(true) { files.deletionPending() }
    override suspend fun deleteAllJournalData() = disk(true) {
        files.beginDeletion()
        // Room clears records, checkpoints WAL and vacuums; never claim a secure flash erase.
        database.clearAllTables()
        files.deleteJournalFiles()
    }
    override suspend fun finishDeletion() = disk(true) { files.finishDeletion() }
    override suspend fun createDraft() = disk { files.createDraft() }
    override suspend fun stagePhoto(draftId: String, source: PhotoSource, input: InputStream,
        originalCaptureDate: Instant?, label: PhotoLabel?) = input.use { stream -> disk {
        files.stage(draftId, source, stream, originalCaptureDate, label)
    } }
    override suspend fun recoverDrafts() = disk {
        files.draftIds().filter { dao.checkIn(it) == null }.associateWith {
            // One damaged unfinished entry must not hide every other recoverable draft.
            try { files.session(it).photos } catch (_: Exception) { emptyList() }
        }
    }
    override suspend fun discardDraft(draftId: String) = disk {
        files.discardDraft(draftId)
        // A failed pre-commit save may have prepared permanent copies of this draft.
        reconcileFiles()
        Unit
    }
    override suspend fun commitDraft(draftId: String, orderedPhotoIds: List<String>, note: String?) = disk {
        // Stable draft ID makes retries safe even after a process death following the DB commit.
        if (dao.checkIn(draftId) != null) return@disk draftId
        require(orderedPhotoIds.isNotEmpty() && orderedPhotoIds.distinct().size == orderedPhotoIds.size)
        val draft = files.readDraft(draftId).associateBy { it.id }
        val selected = orderedPhotoIds.map { draft[it] ?: error("A selected draft photograph is missing") }
        // Do not allow cancellation between committing the database and resolving file ownership.
        withContext(NonCancellable) {
            val stored = selected.map { files.prepare(draftId, it) }
            val now = clock.instant()
            database.withTransaction {
                dao.insertCheckIn(CheckInEntity(draftId, now, now.atZone(zoneProvider()).toLocalDate(), note))
                dao.insertPhotos(selected.mapIndexed { index, photo ->
                    PhotoEntity(photo.id, draftId, stored[index].originalPath, stored[index].thumbnailPath,
                        photo.label, photo.source, photo.originalCaptureDate, index)
                })
            }
            // A cleanup failure must not report a committed save as failed. Reconciliation retries it.
            runCatching { files.discardDraft(draftId) }
        }
        draftId
    }
    override suspend fun deleteCheckIn(id: String) = disk {
        database.withTransaction { dao.deleteCheckIn(id) }
        reconcileFiles()
        Unit
    }
    override suspend fun loadDraft(id: String) = disk {
        if (dao.checkIn(id) != null) null else files.session(id)
    }
    override suspend fun updateDraft(id: String, note: String, labels: Map<String, PhotoLabel?>) = disk {
        files.updateReview(id, note, labels)
    }
    override suspend fun removeDraftPhoto(id: String, photoId: String) = disk { files.removeDraftPhoto(id, photoId) }
    override suspend fun photoAssets(photos: List<Photo>) = disk(true) {
        photos.mapNotNull { photo ->
            try {
                val original = files.resolve(photo.originalFilePath)
                val thumbnail = try { photo.thumbnailFilePath?.let(files::resolve) }
                    catch (_: IllegalArgumentException) { null } catch (_: java.io.IOException) { null }
                photo.id to PhotoAssets(original, thumbnail)
            } catch (_: IllegalArgumentException) { null } catch (_: java.io.IOException) { null }
        }.toMap()
    }
    override suspend fun reserveCapture(id: String) = disk { files.reserveCapture(id) }
    override suspend fun completeCapture(id: String, file: File) = disk { files.completeCapture(id, file) }
    override suspend fun abandonCapture(id: String, file: File) = disk { files.abandonCapture(id, file) }
    override suspend fun editPhoto(id: String, note: String?, label: PhotoLabel?) = disk {
        database.withTransaction {
            val photo = dao.photo(id) ?: throw java.io.IOException("This photograph has already been deleted.")
            dao.updateNote(photo.checkInId, note?.takeIf { it.isNotBlank() })
            dao.updateLabel(id, label)
        }
    }
    override suspend fun deletePhoto(id: String) = disk {
        database.withTransaction {
            val photo = dao.photo(id) ?: return@withTransaction
            dao.deletePhoto(id)
            if (dao.photoCount(photo.checkInId) == 0) dao.deleteCheckIn(photo.checkInId)
        }
        reconcileFiles()
        Unit
    }
    override suspend fun reconcile() = disk { reconcileFiles() }
    private suspend fun reconcileFiles(): StorageReport {
        val photos = dao.allPhotos()
        val refs = photos.flatMap { listOfNotNull(it.originalFilePath, it.thumbnailFilePath) }.toSet()
        // Called under the same mutex as prepare/commit; never race an in-flight save.
        files.removeUnreferenced(refs)
        files.draftIds().filter { dao.checkIn(it) != null }.forEach { files.discardDraft(it) }
        val missing = mutableListOf<String>()
        val unreadable = mutableListOf<String>()
        photos.forEach { photo ->
            val original = try { files.resolve(photo.originalFilePath) }
                catch (_: IllegalArgumentException) { null } catch (_: java.io.IOException) { null }
            if (original?.isFile != true) missing += photo.id
            else {
                val path = photo.thumbnailFilePath ?: "thumbnails/${photo.id}.jpg"
                val rebuilt = runCatching { files.ensureThumbnail(photo.originalFilePath, path) }
                if (rebuilt.isFailure) unreadable += photo.id
                else if (photo.thumbnailFilePath == null) dao.updateThumbnailPath(photo.id, path)
            }
        }
        return StorageReport(missing, unreadable)
    }
}
