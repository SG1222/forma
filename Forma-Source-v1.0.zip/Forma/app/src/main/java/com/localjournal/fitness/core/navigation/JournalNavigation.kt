package com.localjournal.fitness.core.navigation

import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.core.tween
import com.localjournal.fitness.core.design.JournalMotion
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.material.icons.Icons
import com.localjournal.fitness.core.design.icons.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.localjournal.fitness.JournalViewModel
import com.localjournal.fitness.core.design.JournalTertiaryButton
import com.localjournal.fitness.core.design.JournalDock
import com.localjournal.fitness.core.design.JournalDockItem
import com.localjournal.fitness.core.design.JournalColors
import com.localjournal.fitness.core.design.JournalTheme
import com.localjournal.fitness.features.camera.CameraScreen
import com.localjournal.fitness.features.checkin.LocalPhotoPicker
import com.localjournal.fitness.features.checkin.ReviewScreen
import com.localjournal.fitness.features.viewer.ViewerScreen
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.compose.*
import com.localjournal.fitness.FoundationState
import com.localjournal.fitness.core.design.JournalSpacing
import com.localjournal.fitness.data.preferences.ThemeMode
import com.localjournal.fitness.features.log.LogScreen
import com.localjournal.fitness.features.compare.CompareScreen
import com.localjournal.fitness.features.streaks.StreaksScreen
import com.localjournal.fitness.features.settings.SettingsScreen

private enum class Tab(val route: String, val label: String, val icon: ImageVector) {
    LOG("log", "Log", Icons.Outlined.PhotoLibrary),
    COMPARE("compare", "Compare", Icons.Outlined.Compare),
    STREAKS("streaks", "Streaks", Icons.Outlined.CalendarMonth)
}
private fun NavHostController.openTab(route: String) {
    navigate(route) {
        popUpTo(graph.findStartDestination().id) { saveState = true }
        launchSingleTop = true
        restoreState = true
    }
}
@Composable fun JournalNavigation(model: JournalViewModel, state: FoundationState, theme: ThemeMode,
    onTheme: (ThemeMode) -> Unit, onRetry: () -> Unit, onDarkCanvas: (Boolean) -> Unit,
    access: com.localjournal.fitness.core.security.AccessState,
    onAuthenticate: (com.localjournal.fitness.core.security.AuthenticationPurpose) -> Unit,
    onSecuritySettings: () -> Unit) {
    val nav = rememberNavController()
    val logGrid = rememberLazyGridState()
    var logIndex by rememberSaveable { mutableIntStateOf(0) }
    var logOffset by rememberSaveable { mutableIntStateOf(0) }
    var restoreLog by rememberSaveable { mutableStateOf(false) }
    fun rememberLogPosition() {
        logIndex = logGrid.firstVisibleItemIndex
        logOffset = logGrid.firstVisibleItemScrollOffset
        restoreLog = true
    }
    val entry by nav.currentBackStackEntryAsState()
    val current = entry?.destination?.route ?: "log"
    val fullScreen = current.startsWith("viewer/") || current.startsWith("camera/") || current.startsWith("quick-compare/")
    val darkPhotoWorkspace = current.startsWith("viewer/") || current.startsWith("camera/")
    LaunchedEffect(darkPhotoWorkspace) { onDarkCanvas(darkPhotoWorkspace) }
    val streaks by model.streaks.collectAsStateWithLifecycle()
    val storage by model.storage.collectAsStateWithLifecycle()
    val storageError by model.storageError.collectAsStateWithLifecycle()
    val exportDisclosure by model.exportDisclosureSeen.collectAsStateWithLifecycle()
    val library by model.library.collectAsStateWithLifecycle()
    val draft by model.draft.collectAsStateWithLifecycle()
    val recoverable by model.recoverable.collectAsStateWithLifecycle()
    val error by model.error.collectAsStateWithLifecycle()
    val working by model.working.collectAsStateWithLifecycle()
    var showAdd by remember { mutableStateOf(false) }
    var importDraft by rememberSaveable { mutableStateOf<String?>(null) }
    fun closeToLog() { if (!nav.popBackStack("log", false)) nav.openTab("log") }
    val picker = rememberLauncherForActivityResult(LocalPhotoPicker()) { uris ->
        model.importPhotos(importDraft, uris) { id ->
            closeToLog()
            nav.navigate("review/$id") { launchSingleTop = true }
        }
    }
    fun launchImport(id: String?) {
        importDraft = id
        try { picker.launch(Unit) } catch (_: android.content.ActivityNotFoundException) { model.pickerUnavailable() }
    }
    val snackbar = remember { SnackbarHostState() }
    LaunchedEffect(error, current) { error?.let {
        if (!current.startsWith("review/") && !current.startsWith("camera/") || current.startsWith("quick-compare/")) snackbar.showSnackbar(it)
        model.clearError()
    } }
    Scaffold(containerColor = if (darkPhotoWorkspace) JournalColors.comparisonCanvas else MaterialTheme.colorScheme.background,
        contentColor = if (darkPhotoWorkspace) Color.White else MaterialTheme.colorScheme.onBackground,
        snackbarHost = { SnackbarHost(snackbar, Modifier.padding(bottom = if (current.startsWith("viewer/")) JournalSpacing.touchTarget + JournalSpacing.standard else 0.dp)) },
        contentWindowInsets = WindowInsets.safeDrawing,
        bottomBar = {
            if (Tab.entries.any { it.route == current }) {
                val dock: @Composable () -> Unit = {
                    JournalDock(Tab.entries.map { JournalDockItem(it.route, it.label, it.icon) }, current) { nav.openTab(it) }
                }
                dock()
            }
        }) { padding ->
        NavHost(navController = nav, startDestination = "log", modifier = Modifier.fillMaxSize(),
            enterTransition = { fadeIn(tween(JournalMotion.enterMillis)) }, exitTransition = { fadeOut(tween(JournalMotion.exitMillis)) },
            popEnterTransition = { fadeIn(tween(JournalMotion.enterMillis)) }, popExitTransition = { fadeOut(tween(JournalMotion.exitMillis)) }) {
            composable("log") {
                LaunchedEffect(Unit) {
                    if (restoreLog) {
                        // Restore after the tab bar and safe insets have their final measured size.
                        withFrameNanos { }
                        logGrid.scrollToItem(logIndex, logOffset)
                        restoreLog = false
                    }
                }
                Box(Modifier.padding(top = padding.calculateTopPadding(), start = padding.calculateLeftPadding(androidx.compose.ui.unit.LayoutDirection.Ltr), end = padding.calculateRightPadding(androidx.compose.ui.unit.LayoutDirection.Ltr))) {
                LogScreen(state, library, recoverable,
                    { rememberLogPosition(); nav.navigate("settings") { launchSingleTop = true } }, onRetry, { showAdd = true },
                    { nav.navigate("review/$it") { launchSingleTop = true } }, { checkIn, photo -> rememberLogPosition(); nav.navigate("viewer/$checkIn/$photo") { launchSingleTop = true } }, logGrid, padding.calculateBottomPadding())
                }
            }
            composable("camera/{draftId}") { backStack ->
                val id = backStack.arguments?.getString("draftId") ?: return@composable
                LaunchedEffect(id) { model.openDraft(id) }
                JournalTheme(ThemeMode.DARK) {
                    CameraScreen(if (draft.id == id) draft else com.localjournal.fitness.DraftState(busy = true), { model.capture(id, it) }, { closeToLog() },
                        { closeToLog(); nav.navigate("review/$id") { launchSingleTop = true } }, { launchImport(id) })
                }
            }
            composable("review/{draftId}") { backStack ->
                val id = backStack.arguments?.getString("draftId") ?: return@composable
                LaunchedEffect(id) { model.openDraft(id) }
                LaunchedEffect(draft.completed) { if (draft.completed && draft.id == id) closeToLog() }
                Box(Modifier.padding(padding).consumeWindowInsets(padding)) {
                ReviewScreen(if (draft.id == id) draft else com.localjournal.fitness.DraftState(busy = true), { closeToLog() }, model::saveDraft, model::updateReview,
                    model::removeDraftPhoto, { model.discardDraft { closeToLog() } },
                    { nav.navigate("camera/$id") { launchSingleTop = true } }, { launchImport(id) })
                }
            }
            composable("viewer/{checkInId}/{photoId}") { backStack ->
                val checkIn = backStack.arguments?.getString("checkInId") ?: return@composable
                val photo = backStack.arguments?.getString("photoId") ?: return@composable
                JournalTheme(ThemeMode.DARK) {
                    ViewerScreen(checkIn, photo, library, working, { closeToLog() }, model::editPhoto, model::deletePhoto,
                        { id -> nav.navigate("quick-compare/$id") { launchSingleTop = true } }, exportDisclosure, model::exportPhoto)
                }
            }
            composable("compare") { Box(Modifier.padding(padding).consumeWindowInsets(padding)) { CompareScreen(library, { nav.openTab("log") }) } }
            composable("quick-compare/{photoId}") { backStack ->
                CompareScreen(library, { closeToLog() }, backStack.arguments?.getString("photoId"), { nav.popBackStack() })
            }
            composable("streaks") { Box(Modifier.padding(padding).consumeWindowInsets(padding)) { StreaksScreen(streaks, model::retryStreaks) } }
            composable("settings") { Box(Modifier.padding(padding).consumeWindowInsets(padding)) { SettingsScreen(theme, onTheme, { nav.popBackStack() }, access, onAuthenticate, onSecuritySettings,
                storage, storageError, model::refreshStorage, working, model::deleteAllData) } }
        }
    }
    if (showAdd) AlertDialog(onDismissRequest = { showAdd = false }, title = { Text("Add photographs") },
        text = { Text("Take photographs for a new check-in or import photographs stored on this device.") },
        confirmButton = { JournalTertiaryButton(onClick = {
            showAdd = false
            model.createDraft { nav.navigate("camera/$it") { launchSingleTop = true } }
        }) { Text("Take Photo") } },
        dismissButton = { JournalTertiaryButton(onClick = { showAdd = false; launchImport(null) }) { Text("Import Photos") } })

}

