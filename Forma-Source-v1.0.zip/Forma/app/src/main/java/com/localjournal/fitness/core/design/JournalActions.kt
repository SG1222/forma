package com.localjournal.fitness.core.design

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.luminance
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp

/** Shared geometry and semantic colors; native Material interactions retain ripple/accessibility. */
@Composable fun JournalPrimaryButton(onClick: () -> Unit, modifier: Modifier = Modifier,
    enabled: Boolean = true, content: @Composable RowScope.() -> Unit) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val fill by animateColorAsState(if (!pressed) MaterialTheme.colorScheme.primary else if (MaterialTheme.colorScheme.background.luminance() < .5f)
        androidx.compose.ui.graphics.Color(0xFF8FBEB6) else JournalActionStyle.pressedAccent,
        tween(JournalMotion.pressMillis), label = "Action press")
    Button(onClick = onClick, enabled = enabled, shape = JournalCorners.button,
        interactionSource = interaction, colors = ButtonDefaults.buttonColors(containerColor = fill),
        modifier = modifier.heightIn(min = JournalActionStyle.primaryHeight),
        contentPadding = PaddingValues(horizontal = JournalSpacing.section, vertical = JournalSpacing.compact), content = content)
}
@Composable fun JournalSecondaryButton(onClick: () -> Unit, modifier: Modifier = Modifier,
    enabled: Boolean = true, content: @Composable RowScope.() -> Unit) {
    OutlinedButton(onClick = onClick, enabled = enabled, shape = JournalCorners.control,
        modifier = modifier.heightIn(min = JournalSpacing.touchTarget), content = content)
}
@Composable fun JournalTertiaryButton(onClick: () -> Unit, modifier: Modifier = Modifier,
    enabled: Boolean = true, destructive: Boolean = false, content: @Composable RowScope.() -> Unit) {
    TextButton(onClick = onClick, enabled = enabled, modifier = modifier.heightIn(min = JournalSpacing.touchTarget),
        shape = JournalCorners.control,
        colors = ButtonDefaults.textButtonColors(contentColor = if (destructive) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary), content = content)
}
@Composable fun JournalFloatingIconButton(onClick: () -> Unit, icon: ImageVector, label: String,
    modifier: Modifier = Modifier, enabled: Boolean = true) {
    Surface(onClick = onClick, enabled = enabled, shape = CircleShape,
        color = MaterialTheme.colorScheme.surfaceContainer.copy(alpha = JournalActionStyle.materialOpacity),
        contentColor = MaterialTheme.colorScheme.onSurface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = .5f)),
        modifier = modifier.size(JournalSpacing.touchTarget).semantics { contentDescription = label }) {
        Box(contentAlignment = androidx.compose.ui.Alignment.Center) { Icon(icon, null, Modifier.size(JournalSpacing.icon)) }
    }
}
