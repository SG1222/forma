package com.localjournal.fitness.core.utilities

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import androidx.core.content.ContextCompat
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.time.Clock
import java.time.Duration
import java.time.LocalDate
import java.time.ZoneId

fun currentLocalDate(clock: Clock, zone: ZoneId): LocalDate = clock.instant().atZone(zone).toLocalDate()

/** A cold source: restarting collection/foregrounding refreshes today without rewriting saved dates. */
fun observeLocalDates(context: Context, clock: Clock = Clock.systemUTC(),
                      zoneProvider: () -> ZoneId = ZoneId::systemDefault) = callbackFlow {
    fun refresh() { trySend(currentLocalDate(clock, zoneProvider())) }
    val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) { refresh() }
    }
    ContextCompat.registerReceiver(context, receiver, IntentFilter().apply {
        addAction(Intent.ACTION_DATE_CHANGED); addAction(Intent.ACTION_TIME_CHANGED); addAction(Intent.ACTION_TIMEZONE_CHANGED)
    }, ContextCompat.RECEIVER_NOT_EXPORTED)
    refresh()
    val timer = launch {
        while (isActive) {
            val now = clock.instant()
            val zone = zoneProvider()
            val date = now.atZone(zone).toLocalDate()
            trySend(date)
            val midnight = date.plusDays(1).atStartOfDay(zone).toInstant()
            delay(Duration.between(now, midnight).toMillis().coerceIn(1L, 60_000L))
        }
    }
    awaitClose { timer.cancel(); context.unregisterReceiver(receiver) }
}.distinctUntilChanged()
