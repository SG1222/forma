package com.localjournal.fitness.features.checkin

import androidx.compose.foundation.layout.Box
import androidx.compose.material3.*
import androidx.compose.runtime.*
import com.localjournal.fitness.core.design.JournalTertiaryButton
import com.localjournal.fitness.data.models.PhotoLabel

fun PhotoLabel?.displayName() = this?.name?.lowercase()?.replaceFirstChar { it.titlecase() } ?: "None"
@Composable fun LabelSelector(label: PhotoLabel?, enabled: Boolean = true, onLabel: (PhotoLabel?) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Box {
        JournalTertiaryButton(onClick = { expanded = true }, enabled = enabled) { Text("Label: ${label.displayName()}") }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            (listOf<PhotoLabel?>(null) + PhotoLabel.entries).forEach { option ->
                DropdownMenuItem(text = { Text(option.displayName()) },
                    onClick = { expanded = false; onLabel(option) })
            }
        }
    }
}
