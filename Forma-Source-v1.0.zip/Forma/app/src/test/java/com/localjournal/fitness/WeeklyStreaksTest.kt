package com.localjournal.fitness

import com.localjournal.fitness.core.utilities.currentLocalDate
import com.localjournal.fitness.data.models.CheckInDay
import com.localjournal.fitness.features.streaks.*
import org.junit.Assert.*
import org.junit.Test
import java.time.*

class WeeklyStreaksTest {
    private val today = LocalDate.parse("2026-10-20")
    private fun stats(vararg dates: String, on: LocalDate = today) = calculateWeeklyStreaks(dates.map(LocalDate::parse), on)
    @Test fun emptyJournal() {
        val result=stats();assertEquals(0,result.currentWeeks);assertEquals(0,result.longestWeeks);assertEquals(0,result.totalCheckIns)
    }
    @Test fun oneCurrentWeekCheckInUsesSingularCount() {
        val result=stats("2026-10-19");assertEquals(1,result.currentWeeks);assertEquals(1,result.longestWeeks);assertEquals(1,result.totalCheckIns)
    }
    @Test fun severalEntriesInOneWeekQualifyOnlyOnce() {
        val result=stats("2026-10-19","2026-10-19","2026-10-20")
        assertEquals(1,result.currentWeeks);assertEquals(3,result.totalCheckIns);assertEquals(2,result.checkInsByDate[LocalDate.parse("2026-10-19")])
    }
    @Test fun consecutiveQualifyingWeeks() {
        val result=stats("2026-10-05","2026-10-12","2026-10-19")
        assertEquals(3,result.currentWeeks);assertEquals(3,result.longestWeeks)
    }
    @Test fun incompleteCurrentWeekPreservesPreviousRunThroughSunday() {
        assertEquals(2,stats("2026-10-05","2026-10-18",on=LocalDate.parse("2026-10-25")).currentWeeks)
    }
    @Test fun fullyMissedWeekBreaksRunOnNextMonday() {
        assertEquals(0,stats("2026-10-05","2026-10-18",on=LocalDate.parse("2026-10-26")).currentWeeks)
    }
    @Test fun streakBrokenSeveralWeeksAgoIsZero() {
        val result=stats("2026-08-03","2026-08-10");assertEquals(0,result.currentWeeks);assertEquals(2,result.longestWeeks)
    }
    @Test fun longestCanExceedCurrentAfterGap() {
        val result=stats("2026-09-21","2026-09-28","2026-10-05","2026-10-19")
        assertEquals(1,result.currentWeeks);assertEquals(3,result.longestWeeks)
    }
    @Test fun deletingLastQualifyingEntryRecalculatesWeeksAndLongest() {
        val all=listOf("2026-10-05","2026-10-12","2026-10-19").map(LocalDate::parse)
        assertEquals(3,calculateWeeklyStreaks(all,today).currentWeeks)
        val after=calculateWeeklyStreaks(all.filter{it!=LocalDate.parse("2026-10-12")},today)
        assertEquals(1,after.currentWeeks);assertEquals(1,after.longestWeeks);assertEquals(2,after.totalCheckIns)
    }
    @Test fun deletingOneOfSeveralEntriesDoesNotUnqualifyWeek() {
        val dates=listOf("2026-10-12","2026-10-13","2026-10-19").map(LocalDate::parse)
        assertEquals(2,calculateWeeklyStreaks(dates.drop(1),today).currentWeeks)
    }
    @Test fun decemberJanuaryIsoWeekYearUsesSameMonday() {
        val result=stats("2020-12-21","2020-12-28","2021-01-01",on=LocalDate.parse("2021-01-03"))
        assertEquals(2,result.currentWeeks);assertEquals(2,result.longestWeeks)
        assertEquals(LocalDate.parse("2020-12-28"),mondayOf(LocalDate.parse("2021-01-03")))
        assertEquals(2,stats("2020-12-21","2021-01-01",on=LocalDate.parse("2021-01-04")).currentWeeks)
        assertEquals(0,stats("2020-12-21","2021-01-01",on=LocalDate.parse("2021-01-11")).currentWeeks)
    }
    @Test fun leapDayAndMarchBoundary() {
        val result=stats("2024-02-26","2024-02-29","2024-03-04",on=LocalDate.parse("2024-03-06"))
        assertEquals(2,result.currentWeeks);assertEquals(3,result.totalCheckIns)
    }
    @Test fun sundayIsPreviousWeekAndMondayStartsNewOne() {
        assertEquals(2,stats("2026-10-18","2026-10-19").currentWeeks)
        assertEquals(1,stats("2026-10-18",on=LocalDate.parse("2026-10-19")).currentWeeks)
        assertEquals(LocalDate.parse("2026-10-12"),mondayOf(LocalDate.parse("2026-10-18")))
    }
    @Test fun laterSavedWeeksDoNotExtendCurrentRunAfterDeviceDateMovesBack() {
        val result=stats("2026-10-19","2026-10-26","2026-11-02")
        assertEquals(1,result.currentWeeks);assertEquals(3,result.longestWeeks);assertEquals(3,result.totalCheckIns)
    }
    @Test fun aggregateCountsRetainEntriesButDeduplicateCalendarDots() {
        val result=calculateWeeklyStreaksByDay(listOf(CheckInDay(today,3),CheckInDay(today,2)),today)
        assertEquals(5,result.totalCheckIns);assertEquals(1,result.checkInsByDate.size);assertEquals(1,result.currentWeeks)
    }
    @Test fun clockAndZoneAffectTodayWithoutMovingHistoricalLocalDates() {
        val clock=Clock.fixed(Instant.parse("2026-10-19T23:30:00Z"),ZoneOffset.UTC)
        val india=currentLocalDate(clock,ZoneId.of("Asia/Kolkata"));val pacific=currentLocalDate(clock,ZoneId.of("America/Los_Angeles"))
        assertEquals(LocalDate.parse("2026-10-20"),india);assertEquals(LocalDate.parse("2026-10-19"),pacific)
        val saved=listOf(LocalDate.parse("2026-10-20"))
        assertEquals(saved.single(),calculateWeeklyStreaks(saved,pacific).checkInsByDate.keys.single())
        assertEquals(1,calculateWeeklyStreaks(saved,india).currentWeeks)
    }
    @Test fun sundayStartingMonthHasSixLeadingBlanks() {
        val cells=monthCells(YearMonth.of(2026,2));assertEquals(6,cells.indexOf(LocalDate.parse("2026-02-01")))
        assertEquals(LocalDate.parse("2026-02-02"),cells[7]);assertEquals(28,cells.count{it!=null})
    }
    @Test fun leapAndNonLeapFebruaryAndMonthNavigationAcrossYears() {
        assertEquals(29,monthCells(YearMonth.of(2024,2)).count{it!=null})
        assertEquals(28,monthCells(YearMonth.of(2025,2)).count{it!=null})
        val december=YearMonth.of(2026,12);assertEquals(YearMonth.of(2027,1),december.plusMonths(1))
        assertEquals(december,december.plusMonths(1).minusMonths(1))
    }
    @Test fun allCalendarCellsAlignToMondayAcrossElevenYears() {
        for (year in 2020..2030) for (month in 1..12) {
            val ym=YearMonth.of(year,month);val cells=monthCells(ym)
            assertEquals(0,cells.size%7);assertEquals(ym.lengthOfMonth(),cells.count{it!=null})
            cells.forEachIndexed{ index,date -> if(date!=null) assertEquals(date.dayOfWeek.value-1,index%7) }
            assertEquals((1..ym.lengthOfMonth()).toList(),cells.filterNotNull().map{it.dayOfMonth})
        }
    }
}
