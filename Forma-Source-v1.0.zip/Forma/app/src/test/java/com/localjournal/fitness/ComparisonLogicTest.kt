package com.localjournal.fitness

import androidx.compose.runtime.saveable.SaverScope
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import com.localjournal.fitness.data.models.*
import com.localjournal.fitness.features.compare.*
import org.junit.Assert.*
import org.junit.Test
import java.time.Instant
import java.time.LocalDate

class ComparisonLogicTest {
    private fun photo(id: String, check: String, label: PhotoLabel? = PhotoLabel.FRONT, order: Int = 0) =
        Photo(id, check, "photos/$id.png", null, label, PhotoSource.IMPORT, null, order)
    private fun entry(id: String, day: Int, vararg photos: Photo) = CheckIn(id, Instant.parse("2026-10-${day}T12:00:00Z"),
        LocalDate.of(2026, 10, day), null, photos.toList())
    @Test fun quickCompareUsesNewestOtherCheckInAndMatchingLabel() {
        val a = photo("a", "current"); val sibling = photo("sibling", "current")
        val older = photo("older", "old"); val newest = photo("newest", "new")
        val wrong = photo("wrong", "wrong", PhotoLabel.SIDE)
        val entries = listOf(entry("old", 17, older), entry("current", 20, a, sibling), entry("new", 19, newest), entry("wrong", 20, wrong))
        assertEquals("newest", suggestedComparison(a, entries))
        assertNull(suggestedComparison(a.copy(label = null), entries))
        assertNull(suggestedComparison(a.copy(label = PhotoLabel.BACK), entries))
    }
    @Test fun deletingOneSelectionKeepsOtherAndRequiresReplacement() {
        val a = photo("a", "a"); val b = photo("b", "b")
        val state = ComparisonState().apply { choose(PhotoSlot.A, a.id); choose(PhotoSlot.B, b.id); sliderA = PhotoTransform(3f, .2f, .1f) }
        state.reconcile(comparisonPhotos(listOf(entry("b", 19, b))))
        assertNull(state.firstId); assertEquals("b", state.secondId)
        assertEquals(PhotoTransform(), state.sliderA); assertTrue(state.notice!!.contains("deleted"))
    }
    @Test fun invalidSameCheckInSelectionIsRejected() {
        val state = ComparisonState().apply { firstId = "a"; secondId = "b" }
        state.reconcile(comparisonPhotos(listOf(entry("same", 20, photo("a", "same"), photo("b", "same")))))
        assertEquals("a", state.firstId); assertNull(state.secondId)
    }
    @Test fun changingOnePhotoKeepsOtherAlignmentAndMode() {
        val state = ComparisonState().apply {
            firstId = "a"; secondId = "b"; mode = ComparisonMode.SLIDER; divider = .3f
            sliderA = PhotoTransform(3f); sliderB = PhotoTransform(2f, .1f, .2f)
        }
        state.choose(PhotoSlot.A, "replacement")
        assertEquals(PhotoTransform(), state.sliderA); assertEquals(2f, state.sliderB.zoom)
        assertEquals(ComparisonMode.SLIDER, state.mode); assertEquals(.3f, state.divider)
    }
    @Test fun zoomKeepsTouchedCoordinateAndIgnoresInvalidViewport() {
        val viewport = Size(400f, 800f)
        val state = PhotoTransform().move(Offset(100f, 200f), Offset.Zero, 2f, viewport, viewport, false)
        assertEquals(PhotoTransform(2f, .25f, .25f), state)
        assertEquals(state, state.move(Offset.Zero, Offset.Zero, 2f, Size.Zero, viewport, false))
        assertEquals(state, state.move(Offset.Zero, Offset.Zero, Float.NaN, viewport, viewport, false))
    }
    @Test fun zoomLimitsAndAspectAwarePanBoundsProtectViewport() {
        val wide = Size(800f, 400f); val tall = Size(400f, 800f)
        val state = PhotoTransform().move(Offset.Zero, Offset(10000f, 10000f), 100f, tall, wide, false)
        assertEquals(5f, state.zoom); assertEquals(2f, state.x); assertEquals(.125f, state.y)
        val fit = state.move(Offset.Zero, Offset.Zero, .0001f, tall, wide, false)
        assertEquals(PhotoTransform(), fit)
    }
    @Test fun sliderAlignmentCanMoveAtFitWithoutMovingDivider() {
        val state = ComparisonState()
        state.sliderA = state.sliderA.move(Offset.Zero, Offset(40f, 20f), 1f, Size(400f, 800f), Size(400f, 800f), true)
        assertEquals(.1f, state.sliderA.x); assertEquals(.025f, state.sliderA.y)
        assertEquals(.5f, state.divider); assertEquals(PhotoTransform(), state.sliderB)
    }
    @Test fun saveRestorePreservesBothModeTransformsAndDivider() {
        val state = ComparisonState().apply {
            firstId = "a"; secondId = "b"; mode = ComparisonMode.SLIDER; alignment = AlignmentTarget.B; divider = .23f
            sideA = PhotoTransform(2f, .1f, .2f); sideB = PhotoTransform(3f, .3f, .4f)
            sliderA = PhotoTransform(4f, .5f, .6f); sliderB = PhotoTransform(5f, .7f, .8f); initialized = true
        }
        val saver = ComparisonState.Saver
        val saved = with(saver) { SaverScope { true }.save(state) }!!
        val restored = saver.restore(saved)!!
        assertEquals(state.firstId, restored.firstId); assertEquals(state.secondId, restored.secondId)
        assertEquals(state.mode, restored.mode); assertEquals(state.alignment, restored.alignment)
        assertEquals(state.divider, restored.divider); assertEquals(state.sideA, restored.sideA)
        assertEquals(state.sideB, restored.sideB); assertEquals(state.sliderA, restored.sliderA); assertEquals(state.sliderB, restored.sliderB)
    }
}
