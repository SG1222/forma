package com.localjournal.fitness

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import com.localjournal.fitness.core.design.JournalLightColors
import com.localjournal.fitness.core.design.JournalDarkColors
import org.junit.Test
import org.junit.Assert.assertTrue

class DesignContrastTest {
    private fun ratio(a:Color,b:Color):Float { val x=a.luminance();val y=b.luminance();return (maxOf(x,y)+.05f)/(minOf(x,y)+.05f) }
    @Test fun semanticTextAndActionPairsMeetNormalTextContrast() {
        for(c in listOf(JournalLightColors,JournalDarkColors)) {
            for((a,b) in listOf(c.onBackground to c.background,c.onSurface to c.surface,c.onSurfaceVariant to c.background,
                c.onSurfaceVariant to c.surfaceVariant,c.primary to c.background,c.onPrimary to c.primary,
                c.onPrimaryContainer to c.primaryContainer)) assertTrue("Normal text contrast ${ratio(a,b)}",ratio(a,b)>=4.5f)
        }
    }
}
