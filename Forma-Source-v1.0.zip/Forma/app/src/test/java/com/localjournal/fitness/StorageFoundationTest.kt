package com.localjournal.fitness

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.localjournal.fitness.core.storage.PrivatePhotoStore
import com.localjournal.fitness.data.database.*
import com.localjournal.fitness.data.models.*
import com.localjournal.fitness.data.repositories.LocalJournalRepository
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.flow.first
import org.junit.*
import org.junit.Assert.*
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import java.io.*
import java.time.*
import java.util.UUID

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35])
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class StorageFoundationTest {
    private lateinit var db: JournalDatabase
    private lateinit var files: PrivatePhotoStore
    private lateinit var repository: LocalJournalRepository
    private lateinit var root: File
    private val clock = Clock.fixed(Instant.parse("2026-10-19T23:30:00Z"), ZoneId.of("Asia/Kolkata"))
    @Before fun setup() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        root = File(context.filesDir, "test-${UUID.randomUUID()}").also { it.mkdirs() }
        db = Room.inMemoryDatabaseBuilder(context, JournalDatabase::class.java).build()
        files = PrivatePhotoStore(root)
        repository = LocalJournalRepository(db, files, clock) { clock.zone }
    }
    @After fun teardown() { db.close(); root.deleteRecursively() }
    private fun image(): ByteArray {
        val bitmap = Bitmap.createBitmap(40, 60, Bitmap.Config.ARGB_8888)
        bitmap.eraseColor(android.graphics.Color.BLUE)
        return ByteArrayOutputStream().use { output ->
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, output); bitmap.recycle(); output.toByteArray()
        }
    }
    @Test fun commitPreservesOriginalBytesAndSaveDate() = runTest {
        val bytes = image()
        val draft = repository.createDraft()
        val photo = repository.stagePhoto(draft, PhotoSource.IMPORT, bytes.inputStream(), Instant.EPOCH, PhotoLabel.FRONT)
        repository.commitDraft(draft, listOf(photo.id), "Test note")
        val saved = db.journalDao().checkIn(draft)!!
        assertEquals(LocalDate.parse("2026-10-20"), saved.checkIn.checkInDate)
        assertEquals(clock.instant(), saved.checkIn.createdAt)
        assertEquals(Instant.EPOCH, saved.photos.single().originalCaptureDate)
        assertEquals(PhotoLabel.FRONT, saved.photos.single().label)
        assertEquals("Test note", saved.checkIn.note)
        assertArrayEquals(bytes, files.resolve(saved.photos.single().originalFilePath).readBytes())
        assertTrue(saved.photos.single().originalFilePath.endsWith(".png"))
        assertNotNull(BitmapFactory.decodeFile(files.resolve(saved.photos.single().thumbnailFilePath!!).path))
        assertTrue(repository.recoverDrafts().isEmpty())
    }
    @Test fun retryAfterSuccessfulCommitIsIdempotent() = runTest {
        val draft = repository.createDraft()
        val photo = repository.stagePhoto(draft, PhotoSource.CAMERA, image().inputStream())
        repository.commitDraft(draft, listOf(photo.id))
        assertEquals(draft, repository.commitDraft(draft, listOf(photo.id)))
        assertEquals(1, db.journalDao().allPhotos().size)
    }
    @Test fun interruptedPrepareKeepsRecoverableDraftAndRemovesOrphans() = runTest {
        val draft = repository.createDraft()
        val photo = repository.stagePhoto(draft, PhotoSource.IMPORT, image().inputStream())
        val stored = files.prepare(draft, photo) // Simulate termination before Room transaction.
        val recreated = LocalJournalRepository(db, PrivatePhotoStore(root), clock) { clock.zone }
        recreated.reconcile()
        assertFalse(files.resolve(stored.originalPath).exists())
        assertEquals(photo.id, recreated.recoverDrafts()[draft]!!.single().id)
        recreated.commitDraft(draft, listOf(photo.id))
        assertNotNull(db.journalDao().checkIn(draft))
    }
    @Test fun missingDraftFileNeverCommitsBrokenReference() = runTest {
        val draft = repository.createDraft()
        val photo = repository.stagePhoto(draft, PhotoSource.CAMERA, image().inputStream())
        File(root, "drafts/$draft/${photo.fileName}").delete()
        assertTrue(runCatching { repository.commitDraft(draft, listOf(photo.id)) }.isFailure)
        assertNull(db.journalDao().checkIn(draft))
        assertEquals(1, repository.recoverDrafts()[draft]!!.size)
    }
    @Test fun failedRoomTransactionKeepsDraftForRetry() = runTest {
        val draft = repository.createDraft()
        val photo = repository.stagePhoto(draft, PhotoSource.CAMERA, image().inputStream())
        db.openHelper.writableDatabase.execSQL("CREATE TRIGGER reject_photos BEFORE INSERT ON photos BEGIN SELECT RAISE(ABORT, 'test failure'); END")
        assertTrue(runCatching { repository.commitDraft(draft, listOf(photo.id)) }.isFailure)
        assertNull(db.journalDao().checkIn(draft))
        assertEquals(photo.id, repository.recoverDrafts()[draft]!!.single().id)
        db.openHelper.writableDatabase.execSQL("DROP TRIGGER reject_photos")
        repository.reconcile()
        repository.commitDraft(draft, listOf(photo.id))
        assertEquals(1, db.journalDao().allPhotos().size)
    }
    @Test fun deleteCascadesAndReconcilesPrivateFiles() = runTest {
        val draft = repository.createDraft()
        val photo = repository.stagePhoto(draft, PhotoSource.CAMERA, image().inputStream())
        repository.commitDraft(draft, listOf(photo.id))
        val saved = db.journalDao().allPhotos().single()
        repository.deleteCheckIn(draft)
        assertTrue(db.journalDao().allPhotos().isEmpty())
        assertFalse(files.resolve(saved.originalFilePath).exists())
        assertFalse(files.resolve(saved.thumbnailFilePath!!).exists())
    }
    @Test fun missingAndCorruptThumbnailsRegenerateWithoutChangingOriginal() = runTest {
        val bytes = image()
        val draft = repository.createDraft()
        val photo = repository.stagePhoto(draft, PhotoSource.IMPORT, bytes.inputStream())
        repository.commitDraft(draft, listOf(photo.id))
        val row = db.journalDao().allPhotos().single()
        val thumbnail = files.resolve(row.thumbnailFilePath!!)
        thumbnail.delete()
        assertTrue(repository.reconcile().unreadableThumbnailIds.isEmpty())
        assertTrue(thumbnail.exists())
        thumbnail.writeText("corrupt")
        assertTrue(repository.reconcile().unreadableThumbnailIds.isEmpty())
        assertNotNull(BitmapFactory.decodeFile(thumbnail.path))
        assertArrayEquals(bytes, files.resolve(row.originalFilePath).readBytes())
    }
    @Test fun corruptInputLeavesNoPublishableDraftPhoto() = runTest {
        val draft = repository.createDraft()
        assertTrue(runCatching { repository.stagePhoto(draft, PhotoSource.IMPORT, "not an image".byteInputStream()) }.isFailure)
        assertTrue(repository.recoverDrafts()[draft]!!.isEmpty())
        assertTrue(File(root, "drafts/$draft").listFiles()!!.isEmpty())
    }
    @Test fun interruptedCopyCleansPartialFile() = runTest {
        val draft = repository.createDraft()
        val broken = object : InputStream() { override fun read(): Int = throw IOException("storage interruption") }
        assertTrue(runCatching { repository.stagePhoto(draft, PhotoSource.IMPORT, broken) }.isFailure)
        assertTrue(File(root, "drafts/$draft").listFiles()!!.isEmpty())
    }
    @Test fun privatePathsRejectTraversalAndAbsolutePaths() {
        listOf("../outside.jpg", "/tmp/photo.jpg", "drafts/../photos/a.jpg", "photos/not-a-uuid.jpg").forEach {
            assertTrue(runCatching { files.resolve(it) }.isFailure)
        }
    }
    @Test fun missingOriginalIsReportedWithoutDeletingRecord() = runTest {
        val draft = repository.createDraft()
        val photo = repository.stagePhoto(draft, PhotoSource.CAMERA, image().inputStream())
        repository.commitDraft(draft, listOf(photo.id))
        files.resolve(db.journalDao().allPhotos().single().originalFilePath).delete()
        assertEquals(listOf(photo.id), repository.reconcile().missingOriginalIds)
        assertNotNull(db.journalDao().checkIn(draft))
    }
    @Test fun emptyAndDuplicatePhotoSelectionAreRejected() = runTest {
        val draft = repository.createDraft()
        val photo = repository.stagePhoto(draft, PhotoSource.CAMERA, image().inputStream())
        assertTrue(runCatching { repository.commitDraft(draft, emptyList()) }.isFailure)
        assertTrue(runCatching { repository.commitDraft(draft, listOf(photo.id, photo.id)) }.isFailure)
        assertNull(db.journalDao().checkIn(draft))
    }
    @Test fun nullThumbnailReferenceIsRebuiltAndPersisted() = runTest {
        val draft = repository.createDraft()
        val photo = repository.stagePhoto(draft, PhotoSource.CAMERA, image().inputStream())
        repository.commitDraft(draft, listOf(photo.id))
        db.openHelper.writableDatabase.execSQL("UPDATE photos SET thumbnailFilePath = NULL")
        assertTrue(repository.reconcile().unreadableThumbnailIds.isEmpty())
        val path = db.journalDao().allPhotos().single().thumbnailFilePath!!
        assertTrue(files.resolve(path).isFile)
    }
    @Test fun explicitPhotoOrderSurvivesDatabaseRelationshipLoading() = runTest {
        val draft = repository.createDraft()
        val first = repository.stagePhoto(draft, PhotoSource.CAMERA, image().inputStream())
        val second = repository.stagePhoto(draft, PhotoSource.IMPORT, image().inputStream())
        repository.commitDraft(draft, listOf(second.id, first.id))
        assertEquals(listOf(second.id, first.id), db.journalDao().checkIn(draft)!!.toModel().photos.map { it.id })
    }

    @Test fun thumbnailAppliesExifRotationAndKeepsOriginalBytes() = runTest {
        val jpeg = File(root, "orientation-test.jpg")
        val bitmap = Bitmap.createBitmap(40, 60, Bitmap.Config.ARGB_8888)
        jpeg.outputStream().use { bitmap.compress(Bitmap.CompressFormat.JPEG, 95, it) }
        bitmap.recycle()
        androidx.exifinterface.media.ExifInterface(jpeg).apply {
            setAttribute(androidx.exifinterface.media.ExifInterface.TAG_ORIENTATION,
                androidx.exifinterface.media.ExifInterface.ORIENTATION_ROTATE_90.toString())
            saveAttributes()
        }
        val bytes = jpeg.readBytes()
        val draft = repository.createDraft()
        val photo = repository.stagePhoto(draft, PhotoSource.CAMERA, bytes.inputStream())
        repository.commitDraft(draft, listOf(photo.id))
        val row = db.journalDao().allPhotos().single()
        val thumbnail = BitmapFactory.decodeFile(files.resolve(row.thumbnailFilePath!!).path)
        assertEquals(60, thumbnail.width)
        assertEquals(40, thumbnail.height)
        thumbnail.recycle()
        assertArrayEquals(bytes, files.resolve(row.originalFilePath).readBytes())
    }

    @Test fun saveDateUsesTheCurrentDeviceZoneForEveryCommit() = runTest {
        var currentZone = ZoneId.of("UTC")
        val local = LocalJournalRepository(db, files, clock) { currentZone }
        suspend fun save(): String {
            val draft = local.createDraft()
            val photo = local.stagePhoto(draft, PhotoSource.CAMERA, image().inputStream())
            return local.commitDraft(draft, listOf(photo.id))
        }
        val before = save()
        currentZone = ZoneId.of("Asia/Kolkata")
        val after = save()
        assertEquals(LocalDate.parse("2026-10-19"), db.journalDao().checkIn(before)!!.checkIn.checkInDate)
        assertEquals(LocalDate.parse("2026-10-20"), db.journalDao().checkIn(after)!!.checkIn.checkInDate)
    }

    @Test fun reviewNoteLabelsAndRemovalSurviveRepositoryRecreation() = runTest {
        val draft = repository.createDraft()
        val first = repository.stagePhoto(draft, PhotoSource.IMPORT, image().inputStream())
        val second = repository.stagePhoto(draft, PhotoSource.CAMERA, image().inputStream())
        repository.updateDraft(draft, "An unfinished note", mapOf(first.id to PhotoLabel.SIDE, second.id to null))
        val recreated = LocalJournalRepository(db, PrivatePhotoStore(root), clock) { clock.zone }
        assertEquals("An unfinished note", recreated.loadDraft(draft)!!.note)
        assertEquals(PhotoLabel.SIDE, recreated.loadDraft(draft)!!.photos.first().label)
        recreated.removeDraftPhoto(draft, second.id)
        recreated.commitDraft(draft, listOf(first.id), recreated.loadDraft(draft)!!.note)
        assertEquals(PhotoLabel.SIDE, db.journalDao().checkIn(draft)!!.photos.single().label)
        assertFalse(File(root, "drafts/$draft/${second.fileName}").exists())
    }
    @Test fun metadataEditNeverChangesCreationDateOrOriginal() = runTest {
        val draft = repository.createDraft()
        val photo = repository.stagePhoto(draft, PhotoSource.IMPORT, image().inputStream())
        repository.commitDraft(draft, listOf(photo.id), "Before")
        val before = db.journalDao().checkIn(draft)!!
        val bytes = files.resolve(before.photos.single().originalFilePath).readBytes()
        repository.editPhoto(photo.id, "After", PhotoLabel.BACK)
        val after = db.journalDao().checkIn(draft)!!
        assertEquals(before.checkIn.createdAt, after.checkIn.createdAt)
        assertEquals(before.checkIn.checkInDate, after.checkIn.checkInDate)
        assertEquals("After", after.checkIn.note)
        assertEquals(PhotoLabel.BACK, after.photos.single().label)
        assertArrayEquals(bytes, files.resolve(after.photos.single().originalFilePath).readBytes())
    }
    @Test fun deletingOnePhotoKeepsItsSiblingsAndLastDeletionRemovesCheckIn() = runTest {
        val draft = repository.createDraft()
        val first = repository.stagePhoto(draft, PhotoSource.IMPORT, image().inputStream())
        val second = repository.stagePhoto(draft, PhotoSource.IMPORT, image().inputStream())
        repository.commitDraft(draft, listOf(first.id, second.id), "Kept")
        val path = db.journalDao().photo(first.id)!!.originalFilePath
        repository.deletePhoto(first.id)
        assertFalse(files.resolve(path).exists())
        assertEquals(listOf(second.id), db.journalDao().checkIn(draft)!!.photos.map { it.id })
        assertEquals("Kept", db.journalDao().checkIn(draft)!!.checkIn.note)
        repository.deletePhoto(second.id)
        assertNull(db.journalDao().checkIn(draft))
    }
    @Test fun incompleteCaptureNeverBecomesASavedReference() = runTest {
        val draft = repository.createDraft()
        val first = repository.stagePhoto(draft, PhotoSource.CAMERA, image().inputStream())
        val pending = repository.reserveCapture(draft)
        pending.writeText("interrupted camera write")
        val recreated = LocalJournalRepository(db, PrivatePhotoStore(root), clock) { clock.zone }
        assertEquals(listOf(first.id), recreated.loadDraft(draft)!!.photos.map { it.id })
        recreated.commitDraft(draft, listOf(first.id))
        assertEquals(1, db.journalDao().checkIn(draft)!!.photos.size)
        assertFalse(pending.exists())
    }
    @Test fun completedCaptureRecoversIdempotentlyAfterPublicationInterruption() = runTest {
        val draft = repository.createDraft()
        val pending = repository.reserveCapture(draft)
        pending.writeBytes(image())
        val photo = repository.completeCapture(draft, pending)
        // Simulate a duplicate ready marker left immediately after metadata publication.
        File(pending.parentFile, pending.nameWithoutExtension + ".ready").writeBytes(image())
        assertEquals(listOf(photo.id), repository.loadDraft(draft)!!.photos.map { it.id })
        assertEquals(PhotoSource.CAMERA, repository.loadDraft(draft)!!.photos.single().source)
    }
    @Test fun injectedNoSpaceDuringImportPreservesEarlierDraftAndSavedEntry() = runTest {
        val savedDraft = repository.createDraft()
        val saved = repository.stagePhoto(savedDraft, PhotoSource.CAMERA, image().inputStream())
        repository.commitDraft(savedDraft, listOf(saved.id))
        val draft = repository.createDraft()
        val retained = repository.stagePhoto(draft, PhotoSource.IMPORT, image().inputStream())
        val noSpace = object : InputStream() { override fun read(): Int = throw IOException("ENOSPC: No space left on device") }
        assertTrue(runCatching { repository.stagePhoto(draft, PhotoSource.IMPORT, noSpace) }.isFailure)
        assertEquals(listOf(retained.id), repository.loadDraft(draft)!!.photos.map { it.id })
        assertNotNull(db.journalDao().checkIn(savedDraft))
        assertEquals(1, File(root, "drafts/$draft").listFiles()!!.count { it.extension == "json" })
    }

    @Test fun discardingFailedSaveRemovesPreparedCopiesButKeepsSavedOriginals() = runTest {
        val savedDraft = repository.createDraft()
        val saved = repository.stagePhoto(savedDraft, PhotoSource.CAMERA, image().inputStream())
        repository.commitDraft(savedDraft, listOf(saved.id))
        val savedPath = db.journalDao().photo(saved.id)!!.originalFilePath
        val draft = repository.createDraft()
        val photo = repository.stagePhoto(draft, PhotoSource.IMPORT, image().inputStream())
        val prepared = files.prepare(draft, photo)
        repository.discardDraft(draft)
        assertFalse(files.resolve(prepared.originalPath).exists())
        assertFalse(files.resolve(prepared.thumbnailPath).exists())
        assertTrue(files.resolve(savedPath).exists())
    }

    @Test fun damagedDraftDoesNotHideOtherRecoverableDrafts() = runTest {
        val good = repository.createDraft()
        repository.stagePhoto(good, PhotoSource.CAMERA, image().inputStream())
        val bad = repository.createDraft()
        File(root, "drafts/$bad/${UUID.randomUUID()}.json").writeText("broken metadata")
        assertEquals(1, repository.recoverDrafts()[good]!!.size)
        assertTrue(repository.recoverDrafts().containsKey(bad))
        repository.discardDraft(bad)
        assertEquals(setOf(good), repository.recoverDrafts().keys)
    }

    @Test fun streakProjectionCountsSavedEntriesNotPhotographsAndUpdatesAfterDeletion() = runTest {
        suspend fun save(count: Int): String {
            val id = repository.createDraft()
            val photos = (0 until count).map { repository.stagePhoto(id, PhotoSource.CAMERA, image().inputStream()) }
            repository.commitDraft(id, photos.map { it.id })
            return id
        }
        val a = save(2); val b = save(3)
        val first = repository.checkInDays.first()
        assertEquals(1, first.size); assertEquals(2, first.single().count)
        val today = LocalDate.parse("2026-10-20")
        assertEquals(2, com.localjournal.fitness.features.streaks.calculateWeeklyStreaksByDay(first, today).totalCheckIns)
        repository.deleteCheckIn(a)
        assertEquals(1, repository.checkInDays.first().single().count)
        assertEquals(1, com.localjournal.fitness.features.streaks.calculateWeeklyStreaksByDay(repository.checkInDays.first(), today).currentWeeks)
        repository.deletePhoto(db.journalDao().checkIn(b)!!.photos.first().id)
        assertEquals(1, repository.checkInDays.first().single().count)
        repository.deleteCheckIn(b)
        assertTrue(repository.checkInDays.first().isEmpty())
    }
    @Test fun historicalImportQualifiesOnlySaveWeekInStreakProjection() = runTest {
        val bytes = image(); val id = repository.createDraft()
        val photo = repository.stagePhoto(id, PhotoSource.IMPORT, bytes.inputStream(), Instant.parse("2020-01-01T12:00:00Z"))
        repository.commitDraft(id, listOf(photo.id))
        val days = repository.checkInDays.first()
        val result = com.localjournal.fitness.features.streaks.calculateWeeklyStreaksByDay(days, LocalDate.parse("2026-10-20"))
        assertEquals(1, result.currentWeeks); assertEquals(setOf(LocalDate.parse("2026-10-20")), result.checkInsByDate.keys)
        assertArrayEquals(bytes, files.resolve(db.journalDao().photo(photo.id)!!.originalFilePath).readBytes())
    }
    @Test fun changingDeviceTimezoneDoesNotReinterpretSavedStreakDates() = runTest {
        var zone = ZoneId.of("Asia/Kolkata")
        val local = LocalJournalRepository(db, files, clock) { zone }
        val id = local.createDraft(); val photo = local.stagePhoto(id, PhotoSource.IMPORT, image().inputStream())
        local.commitDraft(id, listOf(photo.id))
        val before = db.journalDao().checkIn(id)!!.checkIn
        zone = ZoneId.of("America/Los_Angeles")
        assertEquals(LocalDate.parse("2026-10-20"), local.checkInDays.first().single().checkInDate)
        assertEquals(before, db.journalDao().checkIn(id)!!.checkIn)
    }

    @Test fun measuredStorageUsesActualFilesAndEntryPhotoCount() = runTest {
        val id=repository.createDraft()
        val photo=repository.stagePhoto(id,PhotoSource.IMPORT,image().inputStream())
        repository.commitDraft(id,listOf(photo.id),"Metadata")
        val info=repository.storageInfo()
        assertEquals(1,info.photoCount)
        val managed=listOf("photos","thumbnails","drafts","export_jobs").sumOf { name ->
            File(root,name).takeIf { it.exists() }?.walkTopDown()?.filter { it.isFile }?.sumOf { it.length() } ?: 0L
        }
        assertEquals(managed,info.bytes) // In-memory test database has no journal DB file.
        assertTrue(info.bytes>image().size)
        repository.deletePhoto(photo.id)
        assertEquals(0,repository.storageInfo().photoCount)
        assertTrue(repository.storageInfo().bytes<info.bytes)
    }
    @Test fun deleteAllRemovesSavedOriginalsThumbnailsDraftsAndRecords() = runTest {
        val id=repository.createDraft();val photo=repository.stagePhoto(id,PhotoSource.IMPORT,image().inputStream())
        repository.commitDraft(id,listOf(photo.id),"Saved note")
        val unfinished=repository.createDraft()
        repository.stagePhoto(unfinished,PhotoSource.CAMERA,image().inputStream())
        repository.updateDraft(unfinished,"Unfinished note",emptyMap())
        files.reserveCapture(unfinished).writeText("interrupted camera bytes")
        repository.deleteAllJournalData()
        assertTrue(repository.deletionPending())
        assertTrue(db.journalDao().allPhotos().isEmpty())
        listOf("photos","thumbnails","drafts").forEach { assertFalse(File(root,it).exists()) }
        repository.finishDeletion()
        assertFalse(repository.deletionPending())
        val fresh=repository.createDraft();repository.discardDraft(fresh)
    }
    @Test fun failedDeleteKeepsDurableIntentAndBlocksNewSavesUntilRetry() = runTest {
        val id=repository.createDraft();val photo=repository.stagePhoto(id,PhotoSource.IMPORT,image().inputStream())
        repository.commitDraft(id,listOf(photo.id))
        val broken=LocalJournalRepository(db,PrivatePhotoStore(root) { file -> if(file.name=="photos") false else file.deleteRecursively() },clock)
        try { broken.deleteAllJournalData();fail("Must not claim full deletion") } catch(_:IOException) { }
        assertTrue(repository.deletionPending())
        try { repository.createDraft();fail("Incomplete deletion must block new work") } catch(_:IOException) { }
        repository.deleteAllJournalData();repository.finishDeletion()
        assertFalse(repository.deletionPending());assertEquals(0,repository.storageInfo().photoCount)
    }

    @Test fun journalPreferenceResetPreservesTheAuthenticationChoice() = kotlinx.coroutines.runBlocking {
        val prefs = com.localjournal.fitness.data.preferences.JournalPreferences(ApplicationProvider.getApplicationContext())
        prefs.setRequireAuthentication(true)
        prefs.setThemeMode(com.localjournal.fitness.data.preferences.ThemeMode.DARK)
        prefs.acknowledgeExportDisclosure()
        prefs.resetJournalPreferences()
        assertTrue(prefs.requireAuthentication.first())
        assertEquals(com.localjournal.fitness.data.preferences.ThemeMode.SYSTEM, prefs.themeMode.first())
        assertFalse(prefs.exportDisclosureSeen.first())
        prefs.setRequireAuthentication(false)
    }

    @Test fun invalidSavedReferenceCannotHideOrDeleteAnotherOriginal() = runTest {
        val entry=repository.createDraft();val photo=repository.stagePhoto(entry,PhotoSource.IMPORT,image().inputStream())
        repository.commitDraft(entry,listOf(photo.id))
        val sentinel=File(root,"sentinel").apply{writeText("kept")}
        val badEntry=UUID.randomUUID().toString();val badPhoto=UUID.randomUUID().toString()
        db.journalDao().insertCheckIn(CheckInEntity(badEntry,clock.instant(),LocalDate.now(clock),null))
        db.journalDao().insertPhotos(listOf(PhotoEntity(badPhoto,badEntry,"../sentinel",null,null,PhotoSource.IMPORT,null,0)))
        assertTrue(repository.reconcile().missingOriginalIds.contains(badPhoto))
        val all=repository.checkIns.first().flatMap{it.photos};val assets=repository.photoAssets(all)
        assertTrue(assets.containsKey(photo.id));assertFalse(assets.containsKey(badPhoto))
        repository.deletePhoto(badPhoto)
        assertEquals("kept",sentinel.readText());assertTrue(files.resolve("photos/${photo.fileName}").exists())
    }
    @Test fun unavailableExportRecoveryDoesNotBlockPrivateJournalReads() = kotlinx.coroutines.runBlocking {
        val id=repository.createDraft();val photo=repository.stagePhoto(id,PhotoSource.IMPORT,image().inputStream())
        repository.commitDraft(id,listOf(photo.id))
        val context=ApplicationProvider.getApplicationContext<Context>()
        val prefs=com.localjournal.fitness.data.preferences.JournalPreferences(context)
        val exporter=com.localjournal.fitness.core.export.PhotoExporter(context.contentResolver,File(root,"export_jobs"),context.packageName)
        val maintenance=com.localjournal.fitness.core.storage.JournalMaintenance(repository,prefs,exporter) {throw IOException("Media volume unavailable")}
        assertFalse(maintenance.recover())
        assertEquals(1,repository.checkIns.first().sumOf{it.photos.size})
        assertArrayEquals(image(),files.resolve("photos/${photo.fileName}").readBytes())
    }
    @Test fun everyExifOrientationProducesTheExpectedPrivateThumbnail() = kotlinx.coroutines.runBlocking {
        val red=android.graphics.Color.RED;val green=android.graphics.Color.GREEN;val blue=android.graphics.Color.BLUE;val yellow=android.graphics.Color.YELLOW
        val expected=listOf(listOf(red,green,blue,yellow),listOf(green,red,yellow,blue),listOf(yellow,blue,green,red),listOf(blue,yellow,red,green),
            listOf(red,blue,green,yellow),listOf(blue,red,yellow,green),listOf(yellow,green,blue,red),listOf(green,yellow,red,blue))
        for(orientation in 1..8) {
            val bitmap=Bitmap.createBitmap(120,80,Bitmap.Config.ARGB_8888)
            val canvas=android.graphics.Canvas(bitmap);val paint=android.graphics.Paint()
            listOf(red,green,blue,yellow).forEachIndexed {index,color ->paint.color=color;val x=index%2*60f;val y=index/2*40f;canvas.drawRect(x,y,x+60,y+40,paint)}
            val source=File(root,"source-$orientation.jpg");source.outputStream().use{bitmap.compress(Bitmap.CompressFormat.JPEG,100,it)};bitmap.recycle()
            androidx.exifinterface.media.ExifInterface(source).apply{setAttribute(androidx.exifinterface.media.ExifInterface.TAG_ORIENTATION,orientation.toString());saveAttributes()}
            val id=repository.createDraft();val photo=repository.stagePhoto(id,PhotoSource.IMPORT,source.inputStream());repository.commitDraft(id,listOf(photo.id))
            val thumb=BitmapFactory.decodeFile(files.resolve("thumbnails/${photo.id}.jpg").path)
            assertEquals(if(orientation>=5) 80 else 120,thumb.width);assertEquals(if(orientation>=5) 120 else 80,thumb.height)
            expected[orientation-1].forEachIndexed {index,color ->
                val actual=thumb.getPixel(thumb.width*(if(index%2==0) 1 else 3)/4,thumb.height*(if(index/2==0) 1 else 3)/4)
                assertTrue("EXIF $orientation quadrant $index",kotlin.math.abs(android.graphics.Color.red(actual)-android.graphics.Color.red(color))<30 &&
                    kotlin.math.abs(android.graphics.Color.green(actual)-android.graphics.Color.green(color))<30 &&kotlin.math.abs(android.graphics.Color.blue(actual)-android.graphics.Color.blue(color))<30)
            };thumb.recycle()
            assertArrayEquals(source.readBytes(),files.resolve("photos/${photo.fileName}").readBytes())
        }
    }

}
