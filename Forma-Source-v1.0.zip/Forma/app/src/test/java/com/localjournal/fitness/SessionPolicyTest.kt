package com.localjournal.fitness

import com.localjournal.fitness.core.security.*
import org.junit.Assert.*
import org.junit.Test

class SessionPolicyTest {
    private var time = 0L
    private fun session(enabled: Boolean) = SessionPolicy { time }.apply { configure(enabled); resume() }
    @Test fun unknownPreferencesFailClosed() { assertFalse(SessionPolicy { time }.state.canShowPrivate) }
    @Test fun disabledLockPermitsAuthorizedForegroundOnly() {
        val s=session(false); assertTrue(s.state.canShowPrivate); s.pause(); assertFalse(s.state.canShowPrivate)
        time=99_000;s.resume();assertTrue(s.state.canShowPrivate)
    }
    @Test fun enabledLockRequiresExplicitSuccess() {
        val s=session(true);assertFalse(s.state.canShowPrivate);s.begin(AuthenticationPurpose.UNLOCK)
        assertFalse(s.state.canShowPrivate);s.authenticated();assertTrue(s.state.canShowPrivate)
    }
    @Test fun failedAndCancelledAttemptsDoNotUnlock() {
        val s=session(true);s.begin(AuthenticationPurpose.UNLOCK);s.failed("Not recognized",false)
        assertFalse(s.state.canShowPrivate);assertNotNull(s.state.purpose)
        s.failed("Cancelled",true);assertFalse(s.state.canShowPrivate);assertNull(s.state.purpose)
    }
    @Test fun thirtySecondMonotonicGraceAndExpiredReturn() {
        val s=session(true);s.begin(AuthenticationPurpose.UNLOCK);s.authenticated();s.pause()
        time=30_000;s.resume();assertTrue(s.state.canShowPrivate)
        s.pause();time=60_001;s.resume();assertFalse(s.state.canShowPrivate)
    }
    @Test fun freshProcessNeverInheritsAuthorization() {
        val old=session(true);old.authenticated();assertTrue(old.state.canShowPrivate)
        assertFalse(session(true).state.canShowPrivate)
    }
    @Test fun configurationChangePreservesAnAuthorizedSession() {
        val s=session(true);s.authenticated();s.pause();s.configurationChange();time=60_000;s.resume()
        assertTrue(s.state.canShowPrivate)
    }
    @Test fun disablingStartsWithConcealmentAndCancellationKeepsLock() {
        val s=session(true);s.authenticated();s.begin(AuthenticationPurpose.DISABLE_LOCK)
        assertFalse(s.state.canShowPrivate);s.failed("Cancelled",true)
        assertTrue(s.state.enabled);assertFalse(s.state.canShowPrivate)
    }
    @Test fun preferenceReadFailureConcealsImmediately() {
        val s=session(false);s.preferencesUnavailable();assertFalse(s.state.canShowPrivate)
    }
    @Test fun promptSuccessAfterCredentialActivityReturnsDoesNotLoop() {
        val s=session(true);s.begin(AuthenticationPurpose.UNLOCK);s.pause();time=45_000;s.authenticated();s.resume()
        assertTrue(s.state.canShowPrivate);assertNull(s.state.purpose)
    }
    @Test fun recompositionsDoNotStartAnotherPrompt() {
        val s=session(true);assertTrue(s.begin(AuthenticationPurpose.UNLOCK));assertFalse(s.begin(AuthenticationPurpose.UNLOCK))
        s.pause();s.configurationChange();s.resume();assertNotNull(s.state.purpose);assertFalse(s.state.canShowPrivate)
    }
}
