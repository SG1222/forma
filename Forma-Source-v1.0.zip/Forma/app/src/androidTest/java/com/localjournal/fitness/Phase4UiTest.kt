package com.localjournal.fitness

import android.graphics.Bitmap
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.localjournal.fitness.data.models.*
import com.localjournal.fitness.data.preferences.ThemeMode
import kotlinx.coroutines.runBlocking
import org.junit.*
import org.junit.Assert.*
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class Phase4UiTest {
    @get:Rule val compose = createAndroidComposeRule<MainActivity>()
    private val h get() = PrivacyTestSupport(compose)
    @Before fun clean() {
        runBlocking { h.graph.preferences.setRequireAuthentication(false) }
        h.waitFor { compose.onAllNodesWithTag("photo-grid").fetchSemanticsNodes().isNotEmpty() }
        runBlocking { h.graph.maintenance.deleteAll(); h.graph.preferences.setThemeMode(ThemeMode.LIGHT) }
    }
    @Test fun viewerControlsKeepImagePlaneFixedAndZoomBounded() {
        val photo=h.save()
        h.waitFor { compose.onAllNodesWithTag("photo-${photo.id}").fetchSemanticsNodes().isNotEmpty() }
        compose.onNodeWithTag("photo-${photo.id}").performClick()
        val before=compose.onNodeWithTag("zoom-photo-active").fetchSemanticsNode().boundsInRoot
        compose.onNodeWithTag("zoom-photo-active").performTouchInput { click(center) }
        h.waitFor { compose.onAllNodesWithText("Export").fetchSemanticsNodes().isEmpty() }
        assertEquals("Controls must not resize/reframe the photograph",before,compose.onNodeWithTag("zoom-photo-active").fetchSemanticsNode().boundsInRoot)
        compose.onNodeWithTag("zoom-photo-active").performTouchInput { doubleClick(center) }
        compose.onNodeWithTag("zoom-photo-active").performTouchInput { swipe(center,center+androidx.compose.ui.geometry.Offset(500f,500f),300) }
        compose.onNodeWithTag("zoom-photo-active").performTouchInput { doubleClick(center);click(center) }
        h.waitFor { compose.onAllNodesWithText("Export").fetchSemanticsNodes().isNotEmpty() }
        assertEquals(before,compose.onNodeWithTag("zoom-photo-active").fetchSemanticsNode().boundsInRoot)
        h.screenshot("viewer-stable-controls")
        assertTrue(h.device.swipe(1,h.device.displayHeight/2,h.device.displayWidth/2,h.device.displayHeight/2,20))
        h.waitFor{compose.onAllNodesWithTag("photo-grid").fetchSemanticsNodes().isNotEmpty()}
    }
    @Test fun allScreensBothThemesAndKeyboardReachability() {
        val id=runBlocking { h.graph.repository.createDraft() }
        val draft=runBlocking { (0..2).map { h.graph.repository.stagePhoto(id,PhotoSource.IMPORT,h.image().inputStream(),label=PhotoLabel.entries[it]) } }
        runBlocking { h.graph.repository.commitDraft(id,draft.map{it.id},"TEST DATA: multi-photo check-in") }
        val other=h.save(true)
        h.waitFor { compose.onAllNodesWithTag("photo-${other.id}").fetchSemanticsNodes().isNotEmpty() }
        for(mode in listOf(ThemeMode.LIGHT,ThemeMode.DARK)) {
            runBlocking { h.graph.preferences.setThemeMode(mode) }
            val name=mode.name.lowercase()
            h.screenshot("log-$name")
            compose.onNodeWithTag("photo-${draft.first().id}").performClick()
            h.screenshot("viewer-$name")
            compose.onNodeWithText("Export").performClick();h.screenshot("export-$name");compose.onNodeWithText("Cancel").performClick()
            compose.onNodeWithContentDescription("Back to Log").performClick()
            h.tab("Compare");compose.onNodeWithTag("select-A").performClick()
            h.screenshot("selection-$name");compose.onNodeWithTag("pick-${draft.first().id}").performClick()
            compose.onNodeWithTag("select-B").performClick();compose.onNodeWithTag("pick-${other.id}").performClick()
            compose.onNodeWithText("Side by Side").performClick();h.screenshot("side-by-side-$name")
            compose.onNodeWithText("Slider").performClick();h.screenshot("slider-$name")
            h.tab("Streaks");h.screenshot("streaks-$name")
            h.tab("Log");h.settings();h.screenshot("settings-$name")
            compose.onNodeWithText("Delete all data").performScrollTo();h.screenshot("settings-data-$name")
            compose.onNodeWithContentDescription("Back to Log").performScrollTo().performClick()
        }
        val unfinished=runBlocking { h.graph.repository.createDraft() }
        runBlocking { h.graph.repository.stagePhoto(unfinished,PhotoSource.IMPORT,h.image().inputStream()) }
        // Direct fixture staging bypasses the UI command; explicitly refresh the existing ViewModel.
        compose.runOnIdle { androidx.lifecycle.ViewModelProvider(compose.activity)[JournalViewModel::class.java].retry() }
        h.waitFor { compose.onAllNodesWithText("Resume check-in · 1 photo").fetchSemanticsNodes().isNotEmpty() }
        compose.onNodeWithText("Resume check-in · 1 photo").performClick()
        compose.onNodeWithTag("review-note").performClick().performTextInput("TEST DATA: the keyboard must not hide Save")
        compose.onNodeWithText("Save Check-in").assertIsDisplayed().assertIsEnabled()
        h.screenshot("review-keyboard")
        val inset=androidx.core.view.ViewCompat.getRootWindowInsets(compose.activity.window.decorView)!!.getInsets(androidx.core.view.WindowInsetsCompat.Type.ime()).bottom
        assertTrue("Keyboard must actually be visible",inset>0)
        val save=compose.onNodeWithText("Save Check-in").fetchSemanticsNode().boundsInRoot
        val gap=h.device.displayHeight-inset-save.bottom
        assertTrue("Save must stay close to the keyboard, without duplicated IME padding: $gap",gap>=0 && gap<120*compose.activity.resources.displayMetrics.density)
        compose.onNodeWithText("Save Check-in").performClick()
        h.waitFor { compose.onAllNodesWithTag("photo-grid").fetchSemanticsNodes().isNotEmpty() }
        assertTrue(runBlocking { h.graph.repository.recoverDrafts().isEmpty() })
    }
}
