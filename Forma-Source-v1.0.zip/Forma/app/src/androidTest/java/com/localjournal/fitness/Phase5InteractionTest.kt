package com.localjournal.fitness

import android.os.*
import android.view.FrameMetrics
import android.view.Window
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import kotlinx.coroutines.runBlocking
import org.json.JSONObject
import org.json.JSONArray
import org.junit.*
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList

/** Matched debug-build diagnostics, deliberately labelled with test-driver overhead. */
class Phase5InteractionTest {
    @get:Rule val compose=createAndroidComposeRule<MainActivity>()
    private val h get()=PrivacyTestSupport(compose)
    @Test fun profileInteractionsAndRapidTabState() {
        h.waitFor {compose.onAllNodesWithTag("photo-grid").fetchSemanticsNodes().isNotEmpty()}
        runBlocking {h.graph.maintenance.deleteAll()}
        val photos=(0 until 36).map {h.save()}
        h.waitFor {compose.onAllNodesWithTag("photo-${photos.last().id}").fetchSemanticsNodes().isNotEmpty()}
        h.tab("Compare");compose.onNodeWithTag("select-A").performClick();compose.onNodeWithTag("pick-${photos.last().id}").performClick()
        compose.onNodeWithTag("select-B").performClick();compose.onNodeWithTag("pick-${photos[34].id}").performClick()
        compose.onNodeWithText("Slider").performClick();compose.onNodeWithTag("compare-slider").assertIsDisplayed()
        h.tab("Streaks");compose.onNodeWithContentDescription("Previous month").performClick()
        val month=compose.onNodeWithTag("calendar-month").fetchSemanticsNode().config[androidx.compose.ui.semantics.SemanticsProperties.Text].joinToString {it.text}
        h.tab("Log")
        val frames=ConcurrentHashMap<String,CopyOnWriteArrayList<LongArray>>()
        val actions=mutableMapOf<String,MutableList<Double>>()
        var segment="warmup"
        val thread=HandlerThread("interaction-frame-metrics").apply {start()}
        val listener=Window.OnFrameMetricsAvailableListener {_,m,_->
            frames.getOrPut(segment){CopyOnWriteArrayList()}.add(longArrayOf(m.getMetric(FrameMetrics.TOTAL_DURATION),m.getMetric(FrameMetrics.LAYOUT_MEASURE_DURATION),m.getMetric(FrameMetrics.DRAW_DURATION),m.getMetric(FrameMetrics.GPU_DURATION)))
        }
        compose.runOnIdle {compose.activity.window.addOnFrameMetricsAvailableListener(listener,Handler(thread.looper))}
        fun measure(name:String,action:()->Unit) {
            segment=name;val start=SystemClock.elapsedRealtimeNanos();action();compose.waitForIdle();h.instrumentation.waitForIdleSync()
            actions.getOrPut(name){mutableListOf()}.add((SystemClock.elapsedRealtimeNanos()-start)/1_000_000.0)
        }
        try {
            repeat(2){h.tab("Compare");h.tab("Streaks");h.tab("Log")}
            repeat(10){
                measure("tabs"){h.tab("Compare")};compose.onNodeWithText("Slider").assertIsSelected()
                measure("tabs"){h.tab("Streaks")};compose.onNodeWithTag("calendar-month").assertTextEquals(month)
                measure("tabs"){h.tab("Log")}
            }
            repeat(10){measure("grid"){compose.onNodeWithTag("photo-grid").performTouchInput {swipeUp(durationMillis=180)}}}
            compose.onNodeWithTag("photo-grid").performScrollToIndex(0)
            repeat(5){
                measure("viewer-open"){compose.onNodeWithTag("photo-${photos.last().id}").performClick()}
                compose.onNodeWithTag("zoom-photo-active").assertIsDisplayed()
                compose.onNodeWithContentDescription("Back to Log").performClick()
            }
            h.tab("Compare")
            repeat(12){i->measure("slider"){compose.onNodeWithTag("comparison-divider").performTouchInput {swipe(center,center+Offset(if(i%2==0) 80f else -80f,0f),180)}}}
            // A burst of requests must retain selection and never leave duplicate tab destinations.
            repeat(6){h.tab("Log");h.tab("Compare")};compose.onNodeWithText("Slider").assertIsSelected()
            h.tab("Log");compose.onAllNodesWithTag("photo-grid").assertCountEquals(1)
        } finally {
            compose.runOnIdle {compose.activity.window.removeOnFrameMetricsAvailableListener(listener)};thread.quitSafely()
        }
        fun p(values:List<Double>,q:Double):Double=values.sorted().let {if(it.isEmpty()) -1.0 else it[((it.size-1)*q).toInt()]}
        val report=JSONObject().put("scope","Debug/API35/software graphics. Action-to-idle includes Compose test-driver overhead; frame times are Window FrameMetrics, not physical touch latency.")
        for(name in actions.keys){val list=frames[name].orEmpty();report.put(name,JSONObject().put("actions",actions[name]!!.size).put("driverMedianMs",p(actions[name]!!,.5)).put("driverP95Ms",p(actions[name]!!,.95)).put("frames",list.size)
            .put("frameP95Ms",p(list.map {it[0]/1_000_000.0},.95)).put("layoutP95Ms",p(list.map {it[1]/1_000_000.0},.95)).put("drawP95Ms",p(list.map {it[2]/1_000_000.0},.95)).put("gpuP95Ms",p(list.map {it[3]/1_000_000.0},.95)))}
        val info=Debug.MemoryInfo();Debug.getMemoryInfo(info);report.put("pssKiB",info.totalPss)
        File(h.graph.filesDir,"phase5-interactions.json").writeText(report.toString(2))
    }
}
