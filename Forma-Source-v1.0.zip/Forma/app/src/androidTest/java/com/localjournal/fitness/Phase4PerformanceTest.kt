package com.localjournal.fitness

import android.graphics.*
import android.os.*
import android.view.FrameMetrics
import android.view.Window
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.room.withTransaction
import com.localjournal.fitness.data.database.*
import com.localjournal.fitness.data.models.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.first
import org.json.JSONObject
import org.junit.*
import org.junit.Assert.*
import java.io.*
import java.time.*
import java.util.UUID
import java.util.concurrent.CopyOnWriteArrayList

/** Fixture insertion is deliberately batched; this measures browsing, not 1,000 manual captures. */
@androidx.test.filters.SdkSuppress(minSdkVersion=35)
class Phase4PerformanceTest {
    @get:Rule val compose=createAndroidComposeRule<MainActivity>()
    private val h get()=PrivacyTestSupport(compose)
    private fun jpeg(width:Int,height:Int):ByteArray {
        val bitmap=Bitmap.createBitmap(width,height,Bitmap.Config.RGB_565)
        Canvas(bitmap).apply { drawColor(Color.rgb(92,108,121));val p=Paint().apply {color=Color.WHITE;isAntiAlias=true;textSize=width*.055f}
            drawText("TEST PHOTO — $width × $height",width*.05f,height*.12f,p)
            p.style=Paint.Style.STROKE;p.strokeWidth=width*.005f;drawRect(width*.1f,height*.2f,width*.9f,height*.9f,p)
            drawCircle(width*.5f,height*.55f,width*.2f,p)
        }
        return ByteArrayOutputStream().use { bitmap.compress(Bitmap.CompressFormat.JPEG,92,it);bitmap.recycle();it.toByteArray() }
    }
    private fun memory():Long { val info=Debug.MemoryInfo();Debug.getMemoryInfo(info);return info.totalPss.toLong() }
    private fun report(values:JSONObject) { File(h.graph.filesDir,"phase4-performance.json").writeText(values.toString(2)) }
    @Test fun seedThousandPhotosAndProfileGridViewerComparison() {
        h.waitFor {compose.onAllNodesWithTag("photo-grid").fetchSemanticsNodes().isNotEmpty()}
        runBlocking { h.graph.maintenance.deleteAll() }
        val started=SystemClock.elapsedRealtime()
        val portrait=jpeg(1024,1536);val landscape=jpeg(1536,1024);val high=jpeg(4032,6048)
        val bitmap=BitmapFactory.decodeByteArray(portrait,0,portrait.size)
        val small=Bitmap.createScaledBitmap(bitmap,341,512,true);bitmap.recycle()
        val thumbnail=ByteArrayOutputStream().use {small.compress(Bitmap.CompressFormat.JPEG,85,it);small.recycle();it.toByteArray()}
        val wide=BitmapFactory.decodeByteArray(landscape,0,landscape.size)
        val wideSmall=Bitmap.createScaledBitmap(wide,512,341,true);wide.recycle()
        val wideThumb=ByteArrayOutputStream().use {wideSmall.compress(Bitmap.CompressFormat.JPEG,85,it);wideSmall.recycle();it.toByteArray()}
        val root=h.graph.filesDir;File(root,"photos").mkdirs();File(root,"thumbnails").mkdirs()
        val ids=mutableListOf<String>();val now=Instant.now();val days=mutableSetOf<java.time.YearMonth>()
        val entries=mutableListOf<CheckInEntity>();val photos=mutableListOf<PhotoEntity>()
        repeat(334) { entryIndex ->
            val entry=UUID.randomUUID().toString();val date=LocalDate.now().minusDays(entryIndex.toLong());days+=java.time.YearMonth.from(date)
            entries+=CheckInEntity(entry,now.minusSeconds(entryIndex*86400L),date,"TEST DATA: large-library fixture")
            repeat(if(entryIndex==333) 1 else 3) { order ->
                val index=ids.size;val id=UUID.randomUUID().toString();ids+=id
                val bytes=if(index%50==0) high else if(index%3==0) landscape else portrait
                File(root,"photos/$id.jpg").writeBytes(bytes);File(root,"thumbnails/$id.jpg").writeBytes(if(index%50!=0 && index%3==0) wideThumb else thumbnail)
                photos+=PhotoEntity(id,entry,"photos/$id.jpg","thumbnails/$id.jpg",PhotoLabel.FRONT,PhotoSource.IMPORT,null,order)
            }
        }
        runBlocking { withContext(Dispatchers.IO) { h.graph.database.withTransaction {
            entries.forEach {h.graph.database.journalDao().insertCheckIn(it)};h.graph.database.journalDao().insertPhotos(photos)
        } } }
        compose.waitUntil(60000) {compose.onAllNodesWithTag("photo-${ids.first()}").fetchSemanticsNodes().isNotEmpty()}
        assertEquals(1000,runBlocking {h.graph.repository.storageInfo().photoCount})
        val ready=SystemClock.elapsedRealtime();val frames=CopyOnWriteArrayList<Long>();val layoutTimes=CopyOnWriteArrayList<Long>();val drawTimes=CopyOnWriteArrayList<Long>();val gpuTimes=CopyOnWriteArrayList<Long>()
        val thread=HandlerThread("test-frame-metrics").apply {start()}
        val listener=Window.OnFrameMetricsAvailableListener {_,metrics,_->
            frames+=metrics.getMetric(FrameMetrics.TOTAL_DURATION);layoutTimes+=metrics.getMetric(FrameMetrics.LAYOUT_MEASURE_DURATION)
            drawTimes+=metrics.getMetric(FrameMetrics.DRAW_DURATION);gpuTimes+=metrics.getMetric(FrameMetrics.GPU_DURATION)
        }
        compose.runOnIdle {compose.activity.window.addOnFrameMetricsAvailableListener(listener,Handler(thread.looper))}
        val memoryPasses=mutableListOf<Long>();val total=1000+days.size+1;val scanStart=SystemClock.elapsedRealtime()
        try {
            repeat(3) {
                for(index in 0 until total step 30) compose.onNodeWithTag("photo-grid").performScrollToIndex(index)
                compose.onNodeWithTag("photo-grid").performScrollToIndex(total-1)
                compose.onNodeWithTag("photo-${ids.last()}").assertIsDisplayed()
                val photo=compose.onNodeWithTag("photo-${ids.last()}").fetchSemanticsNode().boundsInRoot
                val dock=compose.onNodeWithTag("navigation-dock").fetchSemanticsNode().boundsInRoot
                // Scroll extra clearance into view so the complete last row clears the floating controls.
                compose.onNodeWithTag("photo-grid").performTouchInput {swipeUp(durationMillis=150)}
                assertTrue(compose.onNodeWithTag("photo-${ids.last()}").fetchSemanticsNode().boundsInRoot.bottom<=dock.top)
                compose.onNodeWithTag("photo-grid").performScrollToIndex(0)
                repeat(12) {compose.onNodeWithTag("photo-grid").performTouchInput {swipeUp(durationMillis=150)}}
                System.gc();SystemClock.sleep(200);memoryPasses+=memory()
            }
            compose.onNodeWithTag("photo-grid").performScrollToIndex(0);h.screenshot("thousand-photo-log")
            compose.onNodeWithTag("photo-${ids.first()}").performClick()
            compose.onNodeWithTag("zoom-photo-active").performTouchInput {doubleClick(center);swipe(center,center+androidx.compose.ui.geometry.Offset(100f,100f),200);doubleClick(center)}
            h.screenshot("high-resolution-viewer")
            compose.onNodeWithText("Compare").performClick()
            compose.onNodeWithTag("select-B").performClick();compose.onNodeWithTag("comparison-picker").performScrollToIndex(63)
            compose.onNodeWithTag("pick-${ids[50]}").performClick();compose.onNodeWithText("Slider").performClick()
            compose.onNodeWithTag("compare-slider").performTouchInput {doubleClick(center)}
            compose.onNodeWithTag("comparison-divider").performTouchInput {swipe(center,center+androidx.compose.ui.geometry.Offset(80f,0f),300)}
            h.screenshot("high-resolution-slider")
        } finally {compose.runOnIdle {compose.activity.window.removeOnFrameMetricsAvailableListener(listener)};thread.quitSafely()}
        fun percentile(values:List<Long>,p:Double):Double {val sorted=values.filter{it>=0}.sorted();return if(sorted.isEmpty()) -1.0 else sorted[((sorted.size-1)*p).toInt()]/1_000_000.0}
        report(JSONObject().put("savedPhotos",1000).put("checkIns",334).put("originalFormats","JPEG: 1024x1536,1536x1024,twenty 4032x6048")
            .put("fixtureSetupAndInitialLibraryMs",ready-started).put("exerciseMs",SystemClock.elapsedRealtime()-scanStart)
            .put("pssKiBAfterThreePasses",org.json.JSONArray(memoryPasses)).put("frames",frames.size)
            .put("layoutMeasureP95Ms",percentile(layoutTimes,.95)).put("drawP95Ms",percentile(drawTimes,.95)).put("gpuP95Ms",percentile(gpuTimes,.95))
            .put("frameP50Ms",percentile(frames,.5)).put("frameP95Ms",percentile(frames,.95)).put("framesOver32ms",frames.count{it>32_000_000})
            .put("scope","Debug build on software/emulated graphics; includes test-driver pauses and screenshots; not a physical-device FPS claim."))
        assertTrue("Unbounded memory growth across repeated scans",memoryPasses.last()<memoryPasses.first()+131072)
    }
    @Test fun verifyColdLibraryAfterForceStop() {
        val begin=SystemClock.elapsedRealtime()
        compose.waitUntil(60000) {compose.onAllNodesWithTag("photo-grid").fetchSemanticsNodes().isNotEmpty()}
        assertEquals(1000,runBlocking {h.graph.repository.storageInfo().photoCount})
        assertEquals(1000,runBlocking {h.graph.repository.checkIns.first().sumOf{it.photos.size}})
        val file=File(h.graph.filesDir,"phase4-performance.json");val json=JSONObject(file.readText())
        json.put("freshInstrumentationWaitForReadyMs",SystemClock.elapsedRealtime()-begin);report(json)
        h.screenshot("thousand-photo-restart")
    }
}
