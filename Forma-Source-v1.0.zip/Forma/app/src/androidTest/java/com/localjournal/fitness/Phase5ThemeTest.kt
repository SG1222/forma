package com.localjournal.fitness

import android.app.UiModeManager
import android.content.Context
import android.content.res.Configuration
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import com.localjournal.fitness.data.preferences.ThemeMode
import kotlinx.coroutines.runBlocking
import org.junit.Test
import org.junit.Rule
import org.junit.Assert.*

/** Uses live DataStore and real system night-mode changes; no activity restart. */
class Phase5ThemeTest {
    @get:Rule val compose=createAndroidComposeRule<MainActivity>()
    private val h get()=PrivacyTestSupport(compose)
    @Test fun allTabsFollowLiveExplicitAndSystemTheme() {
        val manager=h.graph.getSystemService(Context.UI_MODE_SERVICE) as UiModeManager
        val original=manager.nightMode
        fun system(dark:Boolean) {
            h.instrumentation.uiAutomation.executeShellCommand("cmd uimode night "+if(dark) "yes" else "no").close()
            h.waitFor { (h.graph.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK == Configuration.UI_MODE_NIGHT_YES)==dark }
        }
        fun background():Int {
            compose.waitForIdle();h.instrumentation.waitForIdleSync()
            val b=h.instrumentation.uiAutomation.takeScreenshot()
            // The clear far-right header area above every tab's content, below system bars.
            return b.getPixel(b.width-8,b.height/8).also {b.recycle()}
        }
        try {
            h.waitFor {compose.onAllNodesWithTag("photo-grid").fetchSemanticsNodes().isNotEmpty()}
            for ((name,mode,night) in listOf(Triple("light-device-light",ThemeMode.LIGHT,false),Triple("light-device-dark",ThemeMode.LIGHT,true),Triple("dark-device-light",ThemeMode.DARK,false),Triple("dark-device-dark",ThemeMode.DARK,true),Triple("system-light",ThemeMode.SYSTEM,false),Triple("system-dark",ThemeMode.SYSTEM,true))) {
                system(night);runBlocking {h.graph.preferences.setThemeMode(mode)}
                h.tab("Log");h.screenshot("$name-log");val expected=background()
                h.tab("Compare");h.screenshot("$name-compare");assertEquals("Compare background must follow $name",expected,background())
                h.tab("Streaks");h.screenshot("$name-streaks");assertEquals("Streaks background must follow $name",expected,background())
                assertEquals("Resolved $name luminance",mode == ThemeMode.DARK || (mode == ThemeMode.SYSTEM && night),android.graphics.Color.red(expected)<100)
            }
        } finally {
            val value=when(original) {UiModeManager.MODE_NIGHT_YES->"yes";UiModeManager.MODE_NIGHT_NO->"no";else->"auto"}
            h.instrumentation.uiAutomation.executeShellCommand("cmd uimode night $value").close()
            runBlocking {h.graph.preferences.setThemeMode(ThemeMode.SYSTEM)}
        }
    }
}
