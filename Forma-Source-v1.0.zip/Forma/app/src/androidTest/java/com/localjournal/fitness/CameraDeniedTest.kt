package com.localjournal.fitness

import android.graphics.Bitmap
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import androidx.test.uiautomator.*
import org.junit.*
import org.junit.runner.RunWith
import java.io.File
import java.util.regex.Pattern

@RunWith(AndroidJUnit4::class)
class CameraDeniedTest {
    @get:Rule val compose = createAndroidComposeRule<MainActivity>()
    @Test fun denialExplainsImportAlternative() {
        compose.waitUntil(15000) { compose.onAllNodesWithText("Your photo journal is empty.").fetchSemanticsNodes().isNotEmpty() }
        compose.onNodeWithText("Add photos").performClick()
        compose.onNodeWithText("Take Photo").performSemanticsAction(androidx.compose.ui.semantics.SemanticsActions.OnClick) { it() }
        val device = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation())
        var deny: UiObject2? = null
        // Pump Compose frames until the effect opens the native permission window.
        // Native windows temporarily have no resumed Compose semantics owner.
        compose.waitUntil(15000) {
            deny = device.findObject(By.res(Pattern.compile(".*:id/permission_deny.*")))
            deny != null
        }
        if (deny == null) {
            val instrumentation = InstrumentationRegistry.getInstrumentation()
            device.dumpWindowHierarchy(File(instrumentation.targetContext.filesDir, "permission-diagnostic.xml"))
            val bitmap = instrumentation.uiAutomation.takeScreenshot()
            File(instrumentation.targetContext.filesDir, "permission-diagnostic.png").outputStream().use {
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, it)
            }
            bitmap.recycle()
            throw AssertionError("Android permission denial control not found")
        }
        deny!!.click()
        compose.waitUntil(10000) { runCatching {
            compose.onNodeWithText("Camera access").assertIsDisplayed(); true
        }.getOrDefault(false) }
        compose.onNodeWithText("Camera access").assertIsDisplayed()
        compose.onNodeWithText("Import Photos").assertIsEnabled()
        val instrumentation = InstrumentationRegistry.getInstrumentation()
        android.os.SystemClock.sleep(500)
        val file = File(instrumentation.targetContext.filesDir, "phase2-screenshots/camera-denied.png")
        file.parentFile!!.mkdirs()
        val bitmap = instrumentation.uiAutomation.takeScreenshot()
        file.outputStream().use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }; bitmap.recycle()
        compose.onNodeWithText("Back to Log").performClick()
        compose.onNodeWithText("Your photo journal is empty.").assertIsDisplayed()
    }
}
