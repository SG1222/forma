package com.localjournal.fitness

import android.content.ContentValues
import android.net.Uri
import android.os.SystemClock
import android.provider.MediaStore
import android.view.WindowManager
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.exifinterface.media.ExifInterface
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.uiautomator.*
import com.localjournal.fitness.core.export.PhotoExporter
import com.localjournal.fitness.data.preferences.ThemeMode
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.json.JSONObject
import org.junit.*
import org.junit.Assert.*
import org.junit.runner.RunWith
import java.io.File
import java.io.IOException
import java.util.UUID

@RunWith(AndroidJUnit4::class)
class Phase3cTest {
    @get:Rule val compose=createAndroidComposeRule<MainActivity>()
    private val h get()=PrivacyTestSupport(compose)
    private val graph get()=h.graph
    private val publicFixtures=mutableListOf<Uri>()
    private val collection get()=MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
    private fun rows(): Set<Long> = graph.contentResolver.query(collection,arrayOf("_id"),null,null,null)!!.use { c -> buildSet { while(c.moveToNext()) add(c.getLong(0)) } }
    private fun row(uri: Uri,column: String): String = graph.contentResolver.query(uri,arrayOf(column),null,null,null)!!.use { it.moveToFirst();it.getString(0) }
    @Before fun clean() {
        runBlocking { graph.preferences.setRequireAuthentication(false) }
        h.waitFor { compose.onAllNodesWithTag("photo-grid").fetchSemanticsNodes().isNotEmpty() }
        runBlocking { graph.maintenance.deleteAll();graph.preferences.setThemeMode(ThemeMode.LIGHT) }
    }
    @After fun cleanup() {
        publicFixtures.forEach { runCatching { graph.contentResolver.delete(it,null,null) } }
        runBlocking { graph.preferences.setRequireAuthentication(false) }
    }
    @Test fun nativeBiometricFailureCancelSuccessAndCredentialDisable() {
        h.settings();compose.onNodeWithTag("require-authentication").performClick();h.nativePrompt("Enable app lock")
        h.fingerprint(2)
        h.waitFor { graph.session.state.value.message?.contains("not recognized")==true }
        assertFalse(graph.session.state.value.canShowPrivate)
        SystemClock.sleep(2200) // Let the native rejection animation/sensor cooldown finish.
        h.fingerprint();h.waitFor { graph.session.state.value.enabled && graph.session.state.value.canShowPrivate }
        compose.onNodeWithTag("require-authentication").assertIsOn()
        assertTrue(runBlocking { graph.preferences.requireAuthentication.first() })
        compose.onNodeWithTag("require-authentication").performClick();h.nativePrompt("Disable app lock")
        h.device.pressBack();h.waitFor { graph.session.state.value.purpose==null }
        assertTrue(graph.session.state.value.enabled);assertFalse(graph.session.state.value.canShowPrivate)
        compose.onNodeWithText("Unlock").assertIsDisplayed()
        compose.onNodeWithTag("require-authentication").assertDoesNotExist()
        h.screenshot("lock-cancel-light")
        runBlocking {graph.preferences.setThemeMode(ThemeMode.DARK)};h.screenshot("lock-cancel-dark")
        compose.activityRule.scenario.recreate()
        compose.onNodeWithText("Unlock").assertIsDisplayed()
        compose.onNodeWithText("Unlock").performClick();h.nativePrompt("Unlock Forma");h.fingerprint()
        h.waitFor {graph.session.state.value.canShowPrivate}
        compose.onNodeWithTag("require-authentication").performClick();h.nativePrompt("Disable app lock");h.pin()
        h.waitFor { !graph.session.state.value.enabled && graph.session.state.value.canShowPrivate }
        compose.onNodeWithTag("require-authentication").assertIsOff()
        assertFalse(runBlocking {graph.preferences.requireAuthentication.first()})
    }
    @Test fun backgroundGraceRotationRecentsAndOrdinaryScreenshots() {
        val photo=h.save();h.settings()
        compose.onNodeWithTag("require-authentication").performClick();h.nativePrompt("Enable app lock");h.fingerprint()
        h.waitFor {graph.session.state.value.canShowPrivate}
        compose.onNodeWithContentDescription("Back to Log").performClick()
        h.waitFor {compose.onAllNodesWithTag("photo-${photo.id}").fetchSemanticsNodes().isNotEmpty()}
        compose.onNodeWithTag("photo-${photo.id}").performClick()
        assertEquals(0,compose.activity.window.attributes.flags and WindowManager.LayoutParams.FLAG_SECURE)
        fun redRatio(): Float {
            val bitmap=h.instrumentation.uiAutomation.takeScreenshot();var red=0;var total=0
            for(y in 0 until bitmap.height step 8) for(x in 0 until bitmap.width step 8) {
                val pixel=bitmap.getPixel(x,y);total++
                if(android.graphics.Color.red(pixel)>170 && android.graphics.Color.green(pixel)<100 && android.graphics.Color.blue(pixel)<90) red++
            }
            bitmap.recycle();return red.toFloat()/total
        }
        compose.waitForIdle();SystemClock.sleep(500)
        assertTrue("Normal screenshots must include the private fixture",redRatio()>.05f)
        h.device.pressRecentApps();SystemClock.sleep(1500)
        h.screenshot("recents-debug")
        assertFalse(graph.session.state.value.canShowPrivate)
        h.screenshot("recents-concealed")
        assertTrue("Recents must not contain the red photo fixture",redRatio()<.01f)
        h.resumeApp();h.waitFor {graph.session.state.value.canShowPrivate}
        compose.onNodeWithTag("zoom-photo-active").assertIsDisplayed()
        h.device.setOrientationLeft();SystemClock.sleep(500);h.device.setOrientationNatural()
        h.waitFor {graph.session.state.value.canShowPrivate};compose.onNodeWithTag("zoom-photo-active").assertIsDisplayed()
        h.device.pressHome();SystemClock.sleep(31_200)
        h.resumeApp();h.waitFor {graph.session.state.value.foreground}
        compose.onNodeWithText("Unlock").assertIsDisplayed()
        compose.onNodeWithTag("zoom-photo-active").assertDoesNotExist()
        assertFalse(graph.session.state.value.canShowPrivate)
        compose.onNodeWithText("Unlock").performClick();h.nativePrompt("Unlock Forma");h.fingerprint()
        h.waitFor {graph.session.state.value.canShowPrivate}
        compose.onNodeWithTag("zoom-photo-active").assertIsDisplayed()
    }
    @Test fun deviceLockAndUnlockKeepsPhotosConcealed() {
        val photo=h.save();h.settings()
        compose.onNodeWithTag("require-authentication").performClick();h.nativePrompt("Enable app lock");h.fingerprint()
        h.waitFor {graph.session.state.value.canShowPrivate}
        compose.onNodeWithContentDescription("Back to Log").performClick()
        h.waitFor {compose.onAllNodesWithTag("photo-${photo.id}").fetchSemanticsNodes().isNotEmpty()}
        compose.onNodeWithTag("photo-${photo.id}").performClick()
        h.device.sleep();SystemClock.sleep(1500)
        assertFalse(graph.session.state.value.canShowPrivate)
        h.device.wakeUp();SystemClock.sleep(500)
        // Wake animation can consume the first swipe on software graphics. Retry only
        // while the native PIN keypad is absent; authentication still uses its real keys.
        repeat(4) {
            if (!h.device.hasObject(By.res("com.android.systemui", "key2"))) {
                h.device.swipe(h.device.displayWidth/2,h.device.displayHeight*4/5,h.device.displayWidth/2,h.device.displayHeight/4,30)
                h.device.wait(Until.hasObject(By.res("com.android.systemui", "key2")), 1500)
            }
        }
        // Wait for the actual keyguard keypad; key events during its entrance animation
        // can be discarded by System UI on a software-rendered emulator.
        listOf("key2", "key4", "key6", "key8", "key_enter").forEach { key ->
            val button=h.device.wait(Until.findObject(By.res("com.android.systemui",key).enabled(true)),10_000)
                ?: error("Native keyguard control unavailable: $key")
            button.click()
        }
        h.waitFor {graph.session.state.value.canShowPrivate}
        compose.onNodeWithTag("zoom-photo-active").assertIsDisplayed()
    }
    @Test fun mediaStoreJpegPngFailureAndInterruptedRecoveryPreservePrivateOriginals() = runBlocking {
        val before=rows();val jpeg=h.save(true);val png=h.save()
        assertEquals("Private saves must not publish shared rows",before,rows())
        val storageBefore=graph.repository.storageInfo()
        for(photo in listOf(jpeg,png)) {
            val source=graph.repository.originalForExport(photo.id);val bytes=source.readBytes()
            val uri=graph.exporter.export(source);publicFixtures+=uri
            assertEquals("0",row(uri,MediaStore.Images.Media.IS_PENDING))
            assertArrayEquals(bytes,graph.contentResolver.openInputStream(uri)!!.use {it.readBytes()})
            assertArrayEquals(bytes,source.readBytes())
            if(photo==jpeg) assertEquals(90,graph.contentResolver.openInputStream(uri)!!.use {ExifInterface(it).rotationDegrees})
        }
        assertEquals(storageBefore,graph.repository.storageInfo())
        val successful=rows()
        for(message in listOf("simulated write failure","ENOSPC")) {
            val failing=PhotoExporter(graph.contentResolver,File(graph.filesDir,"export_jobs"),graph.packageName) {input,output ->
                output.write(input.read());throw IOException(message)
            }
            try { failing.export(graph.repository.originalForExport(png.id));fail("Export must fail") } catch(_:IOException) { }
            assertEquals(successful,rows())
            assertTrue(graph.repository.originalForExport(png.id).exists())
        }
        val id=UUID.randomUUID().toString();val name="PhotoJournal_$id.png"
        val pending=graph.contentResolver.insert(collection,ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME,name);put(MediaStore.Images.Media.MIME_TYPE,"image/png")
            put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/Photo Journal/");put(MediaStore.Images.Media.IS_PENDING,1)
        })!!
        val jobs=File(graph.filesDir,"export_jobs");jobs.mkdirs()
        // Simulate process death after insert but before the URI is journaled.
        File(jobs,"$id.json").writeText(JSONObject().put("name",name).toString())
        graph.exporter.recoverPending()
        assertFalse(rows().contains(pending.lastPathSegment!!.toLong()));assertEquals(successful,rows())
        // Simulate death after publication but before ledger removal: never remove the finished copy.
        val published=publicFixtures.first();val publishedName=row(published,MediaStore.Images.Media.DISPLAY_NAME)
        File(jobs,"${UUID.randomUUID()}.json").writeText(JSONObject().put("name",publishedName).put("uri",published.toString()).toString())
        graph.exporter.recoverPending();assertEquals(successful,rows())
        assertTrue(jobs.listFiles().orEmpty().isEmpty())
    }
    @Test fun settingsExportNoticeStorageCancelAndDeleteAllPreserveGallery() {
        val a=h.save(true);val b=h.save();h.waitFor {compose.onAllNodesWithTag("photo-${a.id}").fetchSemanticsNodes().isNotEmpty()}
        compose.onNodeWithTag("photo-${a.id}").performClick();compose.onNodeWithText("Export").performClick()
        compose.onNodeWithText("Exported photos may appear in your phone's gallery and may be backed up by other apps.").assertIsDisplayed()
        h.screenshot("export-disclosure")
        val before=rows();compose.onNodeWithText("Save to Gallery").performClick()
        h.waitFor {rows().size==before.size+1}
        val added=rows()-before;val uri=Uri.withAppendedPath(collection,added.single().toString());publicFixtures+=uri
        h.waitFor {runBlocking {graph.preferences.exportDisclosureSeen.first()}}
        h.waitFor {compose.onAllNodesWithText("Saved to Gallery").fetchSemanticsNodes().isNotEmpty()}
        h.waitFor {compose.onAllNodes(hasText("Export") and isEnabled()).fetchSemanticsNodes().isNotEmpty()}
        compose.onNodeWithText("Export").performClick()
        h.waitFor {compose.onAllNodesWithText("Save a copy of this photograph to your phone's gallery.").fetchSemanticsNodes().isNotEmpty()}
        compose.onNodeWithText("Save a copy of this photograph to your phone's gallery.").assertIsDisplayed()
        compose.onNodeWithText("Cancel").performClick()
        compose.onNodeWithContentDescription("Back to Log").performClick()
        h.tab("Compare");compose.onNodeWithTag("select-A").performClick();compose.onNodeWithTag("pick-${a.id}").performClick()
        compose.onNodeWithTag("select-B").performClick();compose.onNodeWithTag("pick-${b.id}").performClick()
        compose.onNodeWithText("Slider").performClick();h.tab("Log");h.settings()
        compose.onNodeWithTag("storage-photo-count").performScrollTo().assertTextEquals("2")
        val originalBytes=runBlocking {graph.repository.originalForExport(a.id).readBytes()}
        runBlocking {val draft=graph.repository.createDraft();graph.repository.stagePhoto(draft,com.localjournal.fitness.data.models.PhotoSource.IMPORT,h.image().inputStream())}
        compose.onNodeWithText("Delete all data").performScrollTo().performClick()
        compose.onNodeWithText("Cancel").performClick()
        assertEquals(2,runBlocking {graph.repository.storageInfo().photoCount})
        compose.onNodeWithText("Delete all data").performClick()
        compose.onAllNodesWithText("Delete all data").filter(hasClickAction()).onLast().performClick()
        h.waitFor {compose.onAllNodesWithText("Your photo journal is empty.").fetchSemanticsNodes().isNotEmpty()}
        assertEquals(0,runBlocking {graph.repository.storageInfo().photoCount})
        assertTrue(runBlocking {graph.repository.recoverDrafts().isEmpty()})
        assertArrayEquals(originalBytes,graph.contentResolver.openInputStream(uri)!!.use {it.readBytes()})
        assertEquals(ThemeMode.SYSTEM,runBlocking {graph.preferences.themeMode.first()})
        h.tab("Streaks");h.waitFor {compose.onAllNodesWithTag("current-streak").fetchSemanticsNodes().isNotEmpty()}
        compose.onNodeWithTag("current-streak").assertTextEquals("0 weeks")
        h.tab("Compare");compose.onNodeWithText("Add photographs to at least two check-ins to compare them.").assertIsDisplayed()
    }
    @Test fun settingsAndLockScreensBothThemes() {
        h.save();h.save(true);h.settings()
        for(mode in listOf(ThemeMode.LIGHT,ThemeMode.DARK)) {
            runBlocking {graph.preferences.setThemeMode(mode)}
            compose.onNodeWithText("Privacy").performScrollTo();h.screenshot("settings-top-${mode.name.lowercase()}")
            compose.onNodeWithText("Delete all data").performScrollTo();h.screenshot("settings-storage-${mode.name.lowercase()}")
        }
        runBlocking {graph.preferences.setRequireAuthentication(true)}
        h.waitFor {compose.onAllNodesWithText("Unlock").fetchSemanticsNodes().isNotEmpty()}
        for(mode in listOf(ThemeMode.LIGHT,ThemeMode.DARK)) {
            runBlocking{graph.preferences.setThemeMode(mode)};h.screenshot("lock-${mode.name.lowercase()}")
            compose.onNodeWithTag("storage-photo-count").assertDoesNotExist()
        }
    }
}
