package com.localjournal.fitness

import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import com.localjournal.fitness.data.models.*
import com.localjournal.fitness.data.preferences.ThemeMode
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.flow.first
import org.json.JSONObject
import org.junit.*
import org.junit.Assert.*
import java.io.File
import java.security.MessageDigest

/** Seed with Phase4 APK, install Forma with -r, verify in a fresh process without clearing data. */
class Phase5UpgradeTest {
    @get:Rule val compose=createAndroidComposeRule<MainActivity>()
    private val h get()=PrivacyTestSupport(compose)
    private fun hash(f:File)=MessageDigest.getInstance("SHA-256").digest(f.readBytes()).joinToString(""){"%02x".format(it)}
    @Test fun seedExistingData()=runBlocking {
        h.waitFor{compose.onAllNodesWithTag("photo-grid").fetchSemanticsNodes().isNotEmpty()}
        val a=h.save(true);val b=h.save();val draft=h.graph.repository.createDraft()
        val photo=h.graph.repository.stagePhoto(draft,PhotoSource.IMPORT,h.image().inputStream(),label=PhotoLabel.SIDE)
        h.graph.repository.updateDraft(draft,"UPGRADE TEST: retained unfinished note",mapOf(photo.id to PhotoLabel.SIDE))
        h.graph.preferences.setThemeMode(ThemeMode.DARK)
        val proof=JSONObject().put("first",a.id).put("second",b.id).put("draft",draft)
            .put("firstHash",hash(h.graph.repository.originalForExport(a.id))).put("secondHash",hash(h.graph.repository.originalForExport(b.id)))
        File(h.graph.filesDir,"phase5-upgrade-proof.json").writeText(proof.toString())
    }
    @Test fun verifyFormaUpdatePreservesData()=runBlocking {
        val proof=JSONObject(File(h.graph.filesDir,"phase5-upgrade-proof.json").readText())
        h.waitFor{compose.onAllNodesWithTag("photo-grid").fetchSemanticsNodes().isNotEmpty()}
        assertEquals(2,h.graph.repository.checkIns.first().size)
        assertEquals(proof.getString("firstHash"),hash(h.graph.repository.originalForExport(proof.getString("first"))))
        assertEquals(proof.getString("secondHash"),hash(h.graph.repository.originalForExport(proof.getString("second"))))
        val draft=h.graph.repository.loadDraft(proof.getString("draft"))!!
        assertEquals("UPGRADE TEST: retained unfinished note",draft.note);assertEquals(PhotoLabel.SIDE,draft.photos.single().label)
        assertEquals(ThemeMode.DARK,h.graph.preferences.themeMode.first())
        assertFalse(h.graph.preferences.requireAuthentication.first())
        compose.onNodeWithTag("photo-${proof.getString("first")}").performClick();compose.onNodeWithTag("zoom-photo-active").assertIsDisplayed()
        h.screenshot("forma-upgrade-existing-photo")
    }
}
