package com.localjournal.fitness

import android.Manifest
import android.content.Context
import android.graphics.Bitmap
import android.os.ParcelFileDescriptor
import android.provider.DocumentsContract
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.semantics.SemanticsProperties
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import androidx.test.rule.GrantPermissionRule
import androidx.test.uiautomator.*
import com.localjournal.fitness.core.storage.PrivatePhotoStore
import com.localjournal.fitness.data.models.*
import com.localjournal.fitness.data.preferences.ThemeMode
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.*
import org.junit.Assert.*
import org.junit.runner.RunWith
import java.io.File
import java.io.FileInputStream
import java.time.Instant
import java.time.LocalDate

@RunWith(AndroidJUnit4::class)
class CoreJournalTest {
    @get:Rule(order = 0) val permission: GrantPermissionRule = GrantPermissionRule.grant(Manifest.permission.CAMERA)
    @get:Rule(order = 1) val compose = createAndroidComposeRule<MainActivity>()
    private val instrumentation get() = InstrumentationRegistry.getInstrumentation()
    private val graph get() = instrumentation.targetContext.applicationContext as JournalApplication
    private val device get() = UiDevice.getInstance(instrumentation)
    private fun entries() = runBlocking { graph.repository.checkIns.first() }
    private fun waitFor(timeout: Long = 20000, condition: () -> Boolean) = compose.waitUntil(timeout, condition)
    @Before fun cleanJournal() {
        waitFor { compose.onAllNodesWithTag("photo-grid").fetchSemanticsNodes().isNotEmpty() }
        runBlocking {
            graph.preferences.setThemeMode(ThemeMode.LIGHT)
            entries().forEach { graph.repository.deleteCheckIn(it.id) }
            graph.repository.recoverDrafts().keys.forEach { graph.repository.discardDraft(it) }
        }
        waitFor { compose.onAllNodesWithText("Your photo journal is empty.").fetchSemanticsNodes().isNotEmpty() }
    }
    private fun screenshot(name: String) {
        compose.waitForIdle(); instrumentation.waitForIdleSync(); android.os.SystemClock.sleep(700)
        val file = File(graph.filesDir, "phase2-screenshots/$name.png"); file.parentFile!!.mkdirs()
        val bitmap = instrumentation.uiAutomation.takeScreenshot()
        file.outputStream().use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }; bitmap.recycle()
    }
    private fun addCamera() {
        compose.onNodeWithContentDescription("Add photographs").performClick()
        compose.onNodeWithText("Take Photo").performClick()
        waitFor(30000) { runCatching { compose.onNodeWithTag("shutter").assertIsEnabled(); true }.getOrDefault(false) }
    }
    private fun capture(count: Int) {
        compose.onNodeWithTag("shutter").performClick()
        waitFor(30000) { compose.onAllNodesWithText("$count ${if (count == 1) "photo" else "photos"}").fetchSemanticsNodes().isNotEmpty() }
    }
    private fun sharedMediaRows(): String {
        val descriptor = instrumentation.uiAutomation.executeShellCommand("content query --uri content://media/external/images/media --projection _id:_display_name")
        return ParcelFileDescriptor.AutoCloseInputStream(descriptor).bufferedReader().use { it.readText() }
    }
    @Test fun cameraMultiPhotoSaveViewEditDeleteAndPrivacy() {
        val before = sharedMediaRows()
        addCamera()
        capture(1)
        screenshot("camera-back")
        compose.onNodeWithText("Switch camera").assertIsEnabled().performClick()
        waitFor { runCatching { compose.onNodeWithTag("shutter").assertIsEnabled(); true }.getOrDefault(false) }
        if (compose.onAllNodesWithText("Flash: Off").fetchSemanticsNodes().isNotEmpty()) {
            compose.onNodeWithText("Flash: Off").performClick()
            compose.onNodeWithText("Flash: Auto").assertIsDisplayed().performClick()
            compose.onNodeWithText("Flash: On").assertIsDisplayed().performClick()
            compose.onNodeWithText("Flash: Off").assertIsDisplayed()
        }
        capture(2)
        screenshot("camera-front")
        compose.onNodeWithText("Continue").performClick()
        compose.onNodeWithText("Label: None").performClick()
        compose.onNodeWithText("Front", useUnmergedTree = true).performClick()
        compose.onNodeWithTag("review-note").performTextInput("Camera test check-in")
        androidx.test.espresso.Espresso.closeSoftKeyboard()
        screenshot("camera-review-light")
        compose.onNodeWithText("Save Check-in").performClick()
        waitFor { entries().size == 1 && compose.onAllNodesWithTag("photo-grid").fetchSemanticsNodes().isNotEmpty() }
        val saved = entries().single()
        assertEquals(2, saved.photos.size)
        assertEquals("Camera test check-in", saved.note)
        assertTrue(saved.photos.all { it.source == PhotoSource.CAMERA })
        val store = PrivatePhotoStore(graph.filesDir)
        saved.photos.forEach {
            assertTrue(store.resolve(it.originalFilePath).canonicalPath.startsWith(graph.filesDir.canonicalPath + "/"))
            assertTrue(store.resolve(it.originalFilePath).length() > 0)
        }
        assertEquals(before, sharedMediaRows())
        compose.activityRule.scenario.recreate()
        waitFor { compose.onAllNodesWithTag("photo-${saved.photos.first().id}").fetchSemanticsNodes().isNotEmpty() }
        compose.onNodeWithTag("photo-${saved.photos.first().id}").performClick()
        compose.onNodeWithText("Compare").assertIsEnabled()
        compose.onNodeWithText("Export").assertIsEnabled()
        compose.onNodeWithTag("zoom-photo-active").performTouchInput { swipeLeft() }
        compose.onNodeWithText("2 of 2").assertIsDisplayed()
        compose.onNodeWithTag("zoom-photo-active").performTouchInput { doubleClick(center) }
        compose.onNodeWithTag("zoom-photo-active").assert(SemanticsMatcher.expectValue(SemanticsProperties.StateDescription, "Zoomed"))
        compose.onNodeWithTag("zoom-photo-active").performTouchInput { swipe(center, center + Offset(80f, 100f), 400) }
        compose.onNodeWithText("2 of 2").assertIsDisplayed()
        compose.onNodeWithTag("zoom-photo-active").performTouchInput { doubleClick(center) }
        compose.onNodeWithTag("zoom-photo-active").assert(SemanticsMatcher.expectValue(SemanticsProperties.StateDescription, "Fit to screen"))
        compose.onNodeWithTag("zoom-photo-active").performTouchInput {
            down(0, Offset(center.x * .8f, center.y))
            down(1, Offset(center.x * 1.2f, center.y))
            for (step in 1..10) {
                moveTo(0, Offset(center.x * (.8f - step * .035f), center.y))
                moveTo(1, Offset(center.x * (1.2f + step * .035f), center.y))
            }
            up(0); up(1)
        }
        compose.onNodeWithTag("zoom-photo-active").assert(SemanticsMatcher.expectValue(SemanticsProperties.StateDescription, "Zoomed"))
        compose.onNodeWithTag("zoom-photo-active").performTouchInput { doubleClick(center) }
        compose.onNodeWithTag("zoom-photo-active").performTouchInput { click(center) }
        waitFor { compose.onAllNodesWithContentDescription("More").fetchSemanticsNodes().isEmpty() }
        compose.onNodeWithContentDescription("More").assertDoesNotExist()
        screenshot("viewer-controls-hidden")
        compose.onNodeWithTag("zoom-photo-active").performTouchInput { click(center) }
        waitFor { compose.onAllNodesWithContentDescription("More").fetchSemanticsNodes().isNotEmpty() }
        compose.onNodeWithContentDescription("More").performClick()
        compose.onNodeWithText("Edit").performClick()
        compose.onNodeWithText("Check-in note").performTextReplacement("Edited camera note")
        compose.onNodeWithText("Label: None").performClick()
        compose.onNodeWithText("Side", useUnmergedTree = true).performClick()
        compose.onNodeWithText("Save changes").performClick()
        waitFor { entries().single().note == "Edited camera note" }
        assertEquals(saved.createdAt, entries().single().createdAt)
        assertEquals(saved.checkInDate, entries().single().checkInDate)
        assertEquals(PhotoLabel.SIDE, entries().single().photos[1].label)
        compose.onNodeWithContentDescription("More").performClick()
        compose.onNodeWithText("Delete").performClick()
        compose.onNodeWithText("Keep photograph").performClick()
        assertEquals(2, entries().single().photos.size)
        compose.onNodeWithContentDescription("More").performClick()
        compose.onNodeWithText("Delete").performClick()
        compose.onNodeWithText("Delete permanently").performClick()
        waitFor { entries().single().photos.size == 1 && !store.resolve(saved.photos[1].originalFilePath).exists() &&
            runCatching { compose.onNodeWithContentDescription("More").assertIsEnabled(); true }.getOrDefault(false) }
        assertFalse(store.resolve(saved.photos[1].originalFilePath).exists())
        compose.onNodeWithContentDescription("More").performClick()
        compose.onNodeWithText("Delete").performClick()
        compose.onNodeWithText("Delete photograph and check-in?").assertIsDisplayed()
        compose.onNodeWithText("Delete permanently").performClick()
        waitFor { entries().isEmpty() && saved.photos.all { !store.resolve(it.originalFilePath).exists() } &&
            compose.onAllNodesWithText("Your photo journal is empty.").fetchSemanticsNodes().isNotEmpty() }
        assertTrue(saved.photos.all { !store.resolve(it.originalFilePath).exists() })
        assertEquals(before, sharedMediaRows())
    }
    @Test fun systemPickerImportsMultipleReadOnlyLocalPhotos() {
        compose.onNodeWithText("Add photos").performClick()
        compose.onNodeWithText("Import Photos").performClick()
        // This interacts with Android DocumentsUI, not a mocked activity result.
        val drawer = device.wait(Until.findObject(By.desc("Show roots")), 10000)
            ?: device.findObject(By.desc("Navigate up"))
        drawer?.click()
        assertTrue("Test document provider root not found", device.wait(Until.hasObject(By.text("Journal Test Images")), 10000))
        device.findObjects(By.text("Journal Test Images")).last().click()
        val front = device.wait(Until.findObject(By.descStartsWith("Front test.png,")), 10000)
        if (front == null) {
            val bitmap = instrumentation.uiAutomation.takeScreenshot()
            File(graph.filesDir, "picker-diagnostic.png").outputStream().use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
            bitmap.recycle()
            device.dumpWindowHierarchy(File(graph.filesDir, "picker-diagnostic.xml"))
            throw AssertionError("First local test photograph not shown")
        }
        front.longClick()
        device.findObject(By.descStartsWith("Side test.png,")).click()
        val select = device.findObject(By.res("com.google.android.documentsui", "action_menu_select"))
            ?: device.findObject(By.res("com.android.documentsui", "action_menu_select"))
            ?: device.findObject(By.text("Select")) ?: device.findObject(By.text("SELECT"))
            ?: device.findObject(By.desc("Select")) ?: device.findObject(By.text("OPEN")) ?: device.findObject(By.text("Open"))
        select?.click() ?: throw AssertionError("System multiple selection action not found")
        waitFor { compose.onAllNodesWithText("1 of 2").fetchSemanticsNodes().isNotEmpty() }
        compose.onNodeWithTag("review-note").performTextInput("Imported local test photographs")
        androidx.test.espresso.Espresso.closeSoftKeyboard()
        screenshot("import-review-light")
        compose.onNodeWithText("Save Check-in").performClick()
        waitFor { entries().size == 1 && entries().single().photos.size == 2 }
        val saved = entries().single()
        assertTrue(saved.photos.all { it.source == PhotoSource.IMPORT })
        assertEquals(LocalDate.now(), saved.checkInDate)
        assertTrue(graph.contentResolver.persistedUriPermissions.isEmpty())
        saved.photos.zip(listOf("Front test.png", "Side test.png")).forEach { (photo, name) ->
            val uri = DocumentsContract.buildDocumentUri(LocalTestDocumentsProvider.AUTHORITY, name)
            val source = graph.contentResolver.openInputStream(uri)!!.use { it.readBytes() }
            assertArrayEquals(source, PrivatePhotoStore(graph.filesDir).resolve(photo.originalFilePath).readBytes())
        }
    }
    @Test fun populatedLibraryReviewViewerBothThemesAndScrollRestoration() {
        val photos = mutableListOf<Photo>()
        runBlocking {
            repeat(6) { group ->
                val id = graph.repository.createDraft()
                val selected = (0..2).map { index ->
                    val bytes = java.io.ByteArrayOutputStream().use { output ->
                        LocalTestDocumentsProvider.fixture(index).also { it.compress(Bitmap.CompressFormat.PNG, 100, output); it.recycle() }
                        output.toByteArray()
                    }
                    graph.repository.stagePhoto(id, PhotoSource.IMPORT, bytes.inputStream())
                }
                graph.repository.commitDraft(id, selected.map { it.id }, "Labeled test fixtures")
                val month = if (group < 3) 10 else 9
                val date = "2026-${month.toString().padStart(2, '0')}-${20-group}"
                graph.database.openHelper.writableDatabase.execSQL("UPDATE check_ins SET checkInDate = ?, createdAt = ? WHERE id = ?",
                    arrayOf<Any>(date, Instant.parse(date + "T12:00:00Z").toEpochMilli(), id))
                photos += graph.repository.checkIns.first().first { it.id == id }.photos
            }
        }
        waitFor { entries().sumOf { it.photos.size } == 18 }
        val sample = photos.last()
        for (mode in listOf(ThemeMode.LIGHT, ThemeMode.DARK)) {
            runBlocking { graph.preferences.setThemeMode(mode) }
            val suffix = mode.name.lowercase()
            waitFor { compose.onAllNodesWithTag("photo-grid").fetchSemanticsNodes().isNotEmpty() }
            compose.onNodeWithTag("photo-grid").performScrollToIndex(0)
            screenshot("log-populated-$suffix")
            compose.onNodeWithTag("photo-grid").performScrollToKey(sample.id)
            val photoBounds = compose.onNodeWithTag("photo-${sample.id}").fetchSemanticsNode().boundsInRoot
            val dockBounds = compose.onNodeWithTag("navigation-dock").fetchSemanticsNode().boundsInRoot
            assertTrue("Last photo row must clear the floating dock", photoBounds.bottom <= dockBounds.top)
            screenshot("log-bottom-$suffix")
            val range = compose.onNodeWithTag("photo-grid").fetchSemanticsNode().config[SemanticsProperties.VerticalScrollAxisRange]
            val position = range.value()
            compose.onNodeWithTag("photo-${sample.id}").performClick()
            screenshot("viewer-$suffix")
            compose.onNodeWithContentDescription("Back to Log").performClick()
            val after = compose.onNodeWithTag("photo-grid").fetchSemanticsNode().config[SemanticsProperties.VerticalScrollAxisRange].value()
            assertEquals(position, after, 0.1f)
            val draft = runBlocking {
                val id = graph.repository.createDraft()
                repeat(2) { index ->
                    val bytes = java.io.ByteArrayOutputStream().use { output ->
                        LocalTestDocumentsProvider.fixture(index).also { it.compress(Bitmap.CompressFormat.PNG, 100, output); it.recycle() }
                        output.toByteArray()
                    }
                    graph.repository.stagePhoto(id, PhotoSource.IMPORT, bytes.inputStream())
                }
                id
            }
            // Refresh recoverable sessions via the production retry path, then open the actual review route.
            compose.runOnUiThread { androidx.lifecycle.ViewModelProvider(compose.activity)[JournalViewModel::class.java].retry() }
            waitFor { compose.onAllNodesWithTag("photo-grid").fetchSemanticsNodes().isNotEmpty() }
            compose.onNodeWithTag("photo-grid").performScrollToIndex(0)
            waitFor { compose.onAllNodesWithText("Resume check-in · 2 photos").fetchSemanticsNodes().isNotEmpty() }
            compose.onNodeWithText("Resume check-in · 2 photos").performScrollTo().performClick()
            compose.onNodeWithTag("review-note").performTextInput("Reviewing test photographs")
            androidx.test.espresso.Espresso.closeSoftKeyboard()
            compose.onNodeWithTag("review-pager").performScrollTo()
            screenshot("review-$suffix")
            compose.onNodeWithText("Label: None").performClick()
            compose.onNodeWithText("Back", useUnmergedTree = true).performClick()
            compose.onNodeWithContentDescription("Remove from check-in").performClick()
            compose.onNodeWithText("1 of 1").assertIsDisplayed()
            compose.onNodeWithText("Discard").performClick()
            compose.onNodeWithText("Discard check-in").performClick()
            waitFor { compose.onAllNodesWithTag("photo-grid").fetchSemanticsNodes().isNotEmpty() &&
                runBlocking { draft !in graph.repository.recoverDrafts() } }
        }
    }
    @Test fun saveFailureRetainsReviewAndCanRetry() {
        val draftId = runBlocking {
            val id = graph.repository.createDraft()
            val bytes = java.io.ByteArrayOutputStream().use { output ->
                LocalTestDocumentsProvider.fixture(0).also { it.compress(Bitmap.CompressFormat.PNG, 100, output); it.recycle() }
                output.toByteArray()
            }
            graph.repository.stagePhoto(id, PhotoSource.IMPORT, bytes.inputStream())
            id
        }
        compose.runOnUiThread { androidx.lifecycle.ViewModelProvider(compose.activity)[JournalViewModel::class.java].retry() }
        waitFor { compose.onAllNodesWithTag("photo-grid").fetchSemanticsNodes().isNotEmpty() }
            compose.onNodeWithTag("photo-grid").performScrollToIndex(0)
        waitFor { compose.onAllNodesWithText("Resume check-in · 1 photo").fetchSemanticsNodes().isNotEmpty() }
        compose.onNodeWithText("Resume check-in · 1 photo").performClick()
        compose.onNodeWithTag("review-note").performTextInput("Retained after failed save")
        androidx.test.espresso.Espresso.closeSoftKeyboard()
        val directory = File(graph.filesDir, "photos")
        val held = File(graph.filesDir, "photos-test-held")
        assertTrue(directory.renameTo(held))
        directory.writeText("Injected storage write failure")
        try {
            compose.onNodeWithText("Save Check-in").performClick()
            waitFor { compose.onAllNodesWithText("Could not save this check-in. Your photographs and note are still here; try again.").fetchSemanticsNodes().isNotEmpty() }
            assertTrue(entries().isEmpty())
            assertEquals(1, runBlocking { graph.repository.loadDraft(draftId)!!.photos.size })
            compose.onNodeWithTag("review-note").assertTextContains("Retained after failed save")
            screenshot("save-failure-retained-draft")
        } finally {
            directory.delete(); assertTrue(held.renameTo(directory))
        }
        compose.onNodeWithText("Save Check-in").performClick()
        waitFor { entries().size == 1 }
        assertEquals("Retained after failed save", entries().single().note)
    }

    @Test fun unreadableDraftCanBeDiscardedWithoutTrappingNavigation() {
        val id = runBlocking { graph.repository.createDraft() }
        File(graph.filesDir, "drafts/$id/${java.util.UUID.randomUUID()}.json").writeText("broken metadata")
        compose.runOnUiThread { androidx.lifecycle.ViewModelProvider(compose.activity)[JournalViewModel::class.java].retry() }
        waitFor { compose.onAllNodesWithTag("photo-grid").fetchSemanticsNodes().isNotEmpty() }
            compose.onNodeWithTag("photo-grid").performScrollToIndex(0)
        waitFor { compose.onAllNodesWithText("Resume check-in · 0 photos").fetchSemanticsNodes().isNotEmpty() }
        compose.onNodeWithText("Resume check-in · 0 photos").performClick()
        waitFor { compose.onAllNodesWithText("This unfinished check-in could not be opened. Close this screen and try again.").fetchSemanticsNodes().isNotEmpty() }
        compose.onNodeWithContentDescription("Close review").assertIsEnabled()
        compose.onNodeWithText("Discard").performClick()
        compose.onNodeWithText("Discard check-in").performClick()
        waitFor { compose.onAllNodesWithTag("photo-grid").fetchSemanticsNodes().isNotEmpty() }
        assertFalse(File(graph.filesDir, "drafts/$id").exists())
    }

}
