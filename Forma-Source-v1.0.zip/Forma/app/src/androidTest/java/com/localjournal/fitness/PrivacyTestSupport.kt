package com.localjournal.fitness

import android.content.Intent
import android.graphics.*
import android.os.SystemClock
import android.view.KeyEvent
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.AndroidComposeTestRule
import androidx.test.ext.junit.rules.ActivityScenarioRule
import androidx.test.platform.app.InstrumentationRegistry
import androidx.test.uiautomator.*
import com.localjournal.fitness.data.models.*
import kotlinx.coroutines.runBlocking
import java.io.*
import java.util.UUID

internal class PrivacyTestSupport(val compose: AndroidComposeTestRule<ActivityScenarioRule<MainActivity>,MainActivity>) {
    val instrumentation get() = InstrumentationRegistry.getInstrumentation()
    val graph get() = instrumentation.targetContext.applicationContext as JournalApplication
    val device get() = UiDevice.getInstance(instrumentation)
    fun waitFor(condition: () -> Boolean) = compose.waitUntil(20000,condition)
    fun settings() { compose.onNodeWithContentDescription("Settings").performClick();compose.onNodeWithText("Privacy").assertExists() }
    fun tab(label: String) { compose.onNode(hasText(label) and hasClickAction()).performClick() }
    fun fingerprint(id: Int=1) {
        val command="$id:${UUID.randomUUID()}"
        File(graph.filesDir,"auth-command").writeText(command)
        waitFor { File(graph.filesDir,"auth-ack").let{it.exists() && it.readText()==command} }
    }
    fun nativePrompt(title: String) {
        compose.mainClock.advanceTimeBy(300);compose.waitForIdle();instrumentation.waitForIdleSync()
        if (!device.wait(Until.hasObject(By.text(title)),10000)) {
            device.dumpWindowHierarchy(File(graph.filesDir,"auth-failure-ui.xml"));error("Native prompt missing: $title")
        }
    }
    fun pin() {
        val fallback=device.wait(Until.findObject(By.textContains("PIN")),10000) ?: error("Native PIN fallback unavailable")
        fallback.click();SystemClock.sleep(400)
        listOf(KeyEvent.KEYCODE_2,KeyEvent.KEYCODE_4,KeyEvent.KEYCODE_6,KeyEvent.KEYCODE_8).forEach { device.pressKeyCode(it) }
        device.pressEnter()
    }
    fun resumeApp() {
        graph.startActivity(Intent(graph,MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP))
    }
    fun image(jpeg: Boolean=false, exif: Boolean=false): ByteArray {
        val bitmap=Bitmap.createBitmap(300,500,Bitmap.Config.ARGB_8888);val canvas=Canvas(bitmap)
        canvas.drawColor(Color.rgb(210,65,50));canvas.drawText("TEST IMAGE",20f,250f,Paint().apply { color=Color.WHITE;textSize=28f })
        val bytes=ByteArrayOutputStream().use {bitmap.compress(if(jpeg) Bitmap.CompressFormat.JPEG else Bitmap.CompressFormat.PNG,95,it);bitmap.recycle();it.toByteArray()}
        if (!exif) return bytes
        val file=File(graph.cacheDir,"privacy-exif.jpg")
        return try {file.writeBytes(bytes);androidx.exifinterface.media.ExifInterface(file).apply {
            setAttribute(androidx.exifinterface.media.ExifInterface.TAG_ORIENTATION,"6");saveAttributes()
        };file.readBytes()} finally {file.delete()}
    }
    fun save(jpeg: Boolean=false): Photo = runBlocking {
        val id=graph.repository.createDraft();val photo=graph.repository.stagePhoto(id,PhotoSource.IMPORT,image(jpeg,jpeg).inputStream(),label=PhotoLabel.FRONT)
        graph.repository.commitDraft(id,listOf(photo.id),"PRIVATE TEST NOTE")
        com.localjournal.fitness.data.models.Photo(photo.id,id,"photos/${photo.fileName}","thumbnails/${photo.id}.jpg",PhotoLabel.FRONT,PhotoSource.IMPORT,null,0)
    }
    fun screenshot(name: String) {
        compose.mainClock.advanceTimeBy(1000);compose.waitForIdle();instrumentation.waitForIdleSync();SystemClock.sleep(600)
        val file=File(graph.filesDir,"phase3c-screenshots/$name.png");file.parentFile!!.mkdirs()
        val bitmap=instrumentation.uiAutomation.takeScreenshot()
        file.outputStream().use {bitmap.compress(Bitmap.CompressFormat.PNG,100,it)};bitmap.recycle()
    }
}
