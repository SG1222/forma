package com.localjournal.fitness

import android.graphics.*
import androidx.compose.ui.semantics.SemanticsProperties
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.lifecycle.ViewModelProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.localjournal.fitness.data.models.*
import com.localjournal.fitness.data.preferences.ThemeMode
import com.localjournal.fitness.features.streaks.mondayOf
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.*
import org.junit.Assert.*
import org.junit.runner.RunWith
import java.io.ByteArrayOutputStream
import java.io.File
import java.time.*
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit

@RunWith(AndroidJUnit4::class)
class StreaksTest {
    @get:Rule val compose=createAndroidComposeRule<MainActivity>()
    private val instrumentation get()=InstrumentationRegistry.getInstrumentation()
    private val graph get()=instrumentation.targetContext.applicationContext as JournalApplication
    private lateinit var model: JournalViewModel
    private fun entries()=runBlocking { graph.repository.checkIns.first() }
    private fun waitFor(condition: ()->Boolean)=compose.waitUntil(20000,condition)
    private fun tab(name: String) { compose.onNode(hasText(name) and hasClickAction()).performClick() }
    private fun waitTotal(count: Int) { waitFor { model.streaks.value.statistics?.totalCheckIns==count }; compose.waitForIdle() }
    private fun today()=model.streaks.value.today!!
    private fun stats(current: Int,longest: Int,total: Int) {
        waitTotal(total)
        compose.onNodeWithTag("current-streak").assertTextEquals("$current ${if(current==1) "week" else "weeks"}")
        compose.onNodeWithTag("longest-streak").assertTextEquals("$longest ${if(longest==1) "week" else "weeks"}")
        compose.onNodeWithTag("total-check-ins").assertTextEquals(total.toString())
    }
    @Before fun reset() {
        waitFor { compose.onAllNodesWithTag("photo-grid").fetchSemanticsNodes().isNotEmpty() }
        compose.runOnUiThread { model=ViewModelProvider(compose.activity)[JournalViewModel::class.java] }
        runBlocking { entries().forEach { graph.repository.deleteCheckIn(it.id) }; graph.preferences.setThemeMode(ThemeMode.LIGHT) }
        waitTotal(0)
    }
    private fun image(): ByteArray {
        val bitmap=Bitmap.createBitmap(80,120,Bitmap.Config.ARGB_8888)
        val canvas=Canvas(bitmap);canvas.drawColor(Color.DKGRAY)
        canvas.drawText("TEST",8f,65f,Paint().apply { color=Color.WHITE;textSize=20f })
        return ByteArrayOutputStream().use { bitmap.compress(Bitmap.CompressFormat.PNG,100,it);bitmap.recycle();it.toByteArray() }
    }
    private fun save(date: LocalDate,count: Int=1): CheckIn = runBlocking {
        val id=graph.repository.createDraft()
        val photos=(0 until count).map { graph.repository.stagePhoto(id,PhotoSource.IMPORT,image().inputStream(),Instant.EPOCH) }
        graph.repository.commitDraft(id,photos.map{it.id},"TEST DATA: weekly calendar")
        // Fixture-only dates never introduce a product backdating path.
        graph.database.openHelper.writableDatabase.execSQL("UPDATE check_ins SET checkInDate = ? WHERE id = ?",arrayOf<Any>(date.toString(),id))
        entries().first{it.id==id}
    }
    private fun seed(): List<CheckIn> {
        val now=today();val week=mondayOf(now)
        val dates=listOf(week.minusWeeks(12),week.minusWeeks(11),week.minusWeeks(10),week.minusWeeks(9),week.minusWeeks(2),week.minusWeeks(1),now,now)
        return dates.mapIndexed { index,date -> save(date,if(index==0) 2 else 1) }.also { waitTotal(8) }
    }
    private fun monthTitle(month: YearMonth)=month.format(DateTimeFormatter.ofPattern("MMMM yyyy"))
    private fun navigateMonth(from: YearMonth,to: YearMonth) {
        compose.onNodeWithTag("calendar-month").performScrollTo()
        val distance=from.until(to,ChronoUnit.MONTHS).toInt()
        repeat(kotlin.math.abs(distance)) { compose.onNodeWithContentDescription(if(distance<0) "Previous month" else "Next month").performClick() }
        compose.onNodeWithTag("calendar-month").assertTextEquals(monthTitle(to))
    }
    private fun assertDockClearance() {
        compose.onNodeWithTag("streaks-end").performScrollTo().assertIsDisplayed()
        val end=compose.onNodeWithTag("streaks-end").fetchSemanticsNode().boundsInRoot
        val dock=compose.onNodeWithTag("navigation-dock").fetchSemanticsNode().boundsInRoot
        assertTrue("Streak content must scroll fully above floating dock",end.bottom<=dock.top)
    }
    private fun screenshot(name: String) {
        compose.mainClock.advanceTimeBy(1000);compose.waitForIdle();instrumentation.waitForIdleSync();android.os.SystemClock.sleep(500)
        val file=File(graph.filesDir,"phase3b-screenshots/$name.png");file.parentFile!!.mkdirs()
        val bitmap=instrumentation.uiAutomation.takeScreenshot()
        file.outputStream().use { bitmap.compress(Bitmap.CompressFormat.PNG,100,it) };bitmap.recycle()
    }
    @Test fun emptySaveAndDeletionUpdateWithoutRestartAndCountEntries() {
        tab("Streaks");stats(0,0,0)
        compose.onNodeWithTag("calendar-month").assertTextEquals(monthTitle(YearMonth.from(today())))
        val a=save(today(),2);stats(1,1,1)
        val b=save(today());stats(1,1,2)
        compose.onAllNodesWithTag("calendar-dot-${today()}", useUnmergedTree=true).assertCountEquals(1)
        compose.onNodeWithTag("calendar-day-${today()}").performScrollTo().performClick()
        compose.onNodeWithTag("calendar-detail").assertTextContains("2 check-ins",substring=true)
        runBlocking { graph.repository.deletePhoto(a.photos.first().id) };stats(1,1,2)
        runBlocking { graph.repository.deleteCheckIn(a.id) };stats(1,1,1)
        runBlocking { graph.repository.deletePhoto(b.photos.single().id) };stats(0,0,0)
        compose.onNodeWithTag("calendar-dot-${today()}", useUnmergedTree=true).assertDoesNotExist()
        compose.onNodeWithTag("calendar-detail").assertTextContains("0 check-ins",substring=true)
        assertDockClearance()
        instrumentation.runOnMainSync { compose.activity.onBackPressedDispatcher.onBackPressed() }
        compose.onNodeWithTag("photo-grid").assertIsDisplayed()
    }
    @Test fun populatedNavigationStateAndFinalWeekDeletion() {
        val saved=seed();val now=today();val currentMonth=YearMonth.from(now)
        val originalRows=entries().associateBy{it.id}
        tab("Streaks");stats(3,4,8)
        compose.onNodeWithTag("calendar-day-$now").performScrollTo().performClick()
        compose.onNodeWithTag("calendar-detail").assertTextContains("2 check-ins",substring=true)
        navigateMonth(currentMonth,YearMonth.of(2026,2))
        compose.onNodeWithTag("calendar-day-2026-02-01").performScrollTo()
        val sunday=compose.onNodeWithTag("calendar-day-2026-02-01").fetchSemanticsNode().boundsInRoot
        val monday=compose.onNodeWithTag("calendar-day-2026-02-02").fetchSemanticsNode().boundsInRoot
        assertTrue(sunday.left>monday.left)
        navigateMonth(YearMonth.of(2026,2),YearMonth.of(2025,12))
        compose.onNodeWithContentDescription("Next month").performClick()
        compose.onNodeWithTag("calendar-month").assertTextEquals("January 2026")
        compose.activityRule.scenario.recreate()
        compose.onNodeWithTag("calendar-month").assertTextEquals("January 2026")
        tab("Log");tab("Streaks")
        compose.onNodeWithTag("calendar-month").assertTextEquals("January 2026")
        navigateMonth(YearMonth.of(2026,1),currentMonth)
        runBlocking { graph.repository.deleteCheckIn(saved[6].id) };stats(3,4,7)
        runBlocking { graph.repository.deleteCheckIn(saved[7].id) };stats(2,4,6)
        compose.onNodeWithTag("calendar-dot-$now", useUnmergedTree=true).assertDoesNotExist()
        runBlocking { graph.repository.deletePhoto(saved[5].photos.single().id) };stats(0,4,5)
        entries().forEach { entry ->
            assertEquals(originalRows[entry.id]!!.createdAt,entry.createdAt)
            assertEquals(originalRows[entry.id]!!.checkInDate,entry.checkInDate)
        }
        assertDockClearance()
    }
    @Test fun streaksScreensBothThemes() {
        tab("Streaks");stats(0,0,0)
        for(mode in listOf(ThemeMode.LIGHT,ThemeMode.DARK)) {
            runBlocking{graph.preferences.setThemeMode(mode)}
            compose.onNodeWithTag("streaks-scroll").performTouchInput { swipeDown() }
            screenshot("empty-${mode.name.lowercase()}")
        }
        seed();stats(3,4,8)
        for(mode in listOf(ThemeMode.LIGHT,ThemeMode.DARK)) {
            runBlocking{graph.preferences.setThemeMode(mode)}
            compose.onNodeWithTag("streaks-heading").performScrollTo()
            screenshot("populated-${mode.name.lowercase()}")
            compose.onNodeWithTag("calendar-month").performScrollTo()
            compose.onNodeWithTag("calendar-day-${today()}").performScrollTo().performClick()
            assertDockClearance()
            screenshot("calendar-${mode.name.lowercase()}")
        }
    }
}
