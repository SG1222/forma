package com.localjournal.fitness

import android.Manifest
import android.graphics.Bitmap
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import androidx.test.rule.GrantPermissionRule
import com.localjournal.fitness.core.storage.PrivatePhotoStore
import com.localjournal.fitness.data.models.PhotoSource
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.*
import org.junit.Assert.*
import org.junit.runner.RunWith
import java.io.File

/** Run seed and verify in separate instrumentation processes, with host force-stop between them. */
@RunWith(AndroidJUnit4::class)
class RecoveryScenarioTest {
    @get:Rule(order = 0) val permission: GrantPermissionRule = GrantPermissionRule.grant(Manifest.permission.CAMERA)
    @get:Rule(order = 1) val compose = createAndroidComposeRule<MainActivity>()
    private val graph get() = InstrumentationRegistry.getInstrumentation().targetContext.applicationContext as JournalApplication
    @Test fun seed() {
        compose.waitUntil(15000) { compose.onAllNodesWithText("Your photo journal is empty.").fetchSemanticsNodes().isNotEmpty() }
        compose.onNodeWithText("Add photos").performClick()
        compose.onNodeWithText("Take Photo").performClick()
        compose.waitUntil(30000) { runCatching { compose.onNodeWithTag("shutter").assertIsEnabled(); true }.getOrDefault(false) }
        compose.onNodeWithTag("shutter").performClick()
        compose.waitUntil(30000) { compose.onAllNodesWithText("1 photo").fetchSemanticsNodes().isNotEmpty() }
        compose.onNodeWithText("Continue").performClick()
        compose.onNodeWithTag("review-note").performTextInput("Recovered draft note")
        androidx.test.espresso.Espresso.closeSoftKeyboard()
        compose.onNodeWithText("Label: None").performClick()
        compose.onNodeWithText("Back", useUnmergedTree = true).performClick()
        compose.waitUntil(10000) {
            runBlocking {
                val id = graph.repository.recoverDrafts().keys.single()
                val session = graph.repository.loadDraft(id)!!
                session.note == "Recovered draft note" && session.photos.single().label?.name == "BACK"
            }
        }
    }
    @Test fun verifyAfterForceStop() {
        compose.waitUntil(15000) { compose.onAllNodesWithText("Resume check-in · 1 photo").fetchSemanticsNodes().isNotEmpty() }
        compose.onNodeWithText("Resume check-in · 1 photo").performClick()
        compose.onNodeWithTag("review-note").assertTextContains("Recovered draft note")
        compose.onNodeWithText("Label: Back").assertIsDisplayed()
        compose.onNodeWithText("Save Check-in").performClick()
        compose.waitUntil(15000) { runBlocking { graph.repository.checkIns.first().size == 1 } }
        val entry = runBlocking { graph.repository.checkIns.first().single() }
        assertEquals(1, entry.photos.size)
        assertEquals("Recovered draft note", entry.note)
        assertTrue(PrivatePhotoStore(graph.filesDir).resolve(entry.photos.single().originalFilePath).isFile)
    }
}
