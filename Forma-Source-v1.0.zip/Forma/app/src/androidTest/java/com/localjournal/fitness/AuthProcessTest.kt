package com.localjournal.fitness

import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.test.ext.junit.runners.AndroidJUnit4
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.*
import org.junit.Assert.*
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class AuthProcessTest {
    @get:Rule val compose=createAndroidComposeRule<MainActivity>()
    private val h get()=PrivacyTestSupport(compose)
    @Test fun seedLockedPreference() {
        h.waitFor {compose.onAllNodesWithTag("photo-grid").fetchSemanticsNodes().isNotEmpty()}
        h.save();h.settings();compose.onNodeWithTag("require-authentication").performClick()
        h.nativePrompt("Enable app lock");h.fingerprint()
        h.waitFor {h.graph.session.state.value.enabled && h.graph.session.state.value.canShowPrivate}
        assertTrue(runBlocking {h.graph.preferences.requireAuthentication.first()})
        compose.onNodeWithContentDescription("Back to Log").performClick()
    }
    @Test fun verifyFreshProcessRequiresRealAuthentication() {
        h.waitFor {compose.onAllNodesWithText("Unlock").fetchSemanticsNodes().isNotEmpty()}
        assertTrue(runBlocking {h.graph.preferences.requireAuthentication.first()})
        assertFalse(h.graph.session.state.value.authorized)
        compose.onNodeWithTag("photo-grid").assertDoesNotExist()
        h.screenshot("lock-after-force-stop")
        compose.onNodeWithText("Unlock").performClick();h.nativePrompt("Unlock Forma");h.fingerprint()
        h.waitFor {h.graph.session.state.value.canShowPrivate}
        compose.onNodeWithTag("photo-grid").assertIsDisplayed()
    }
}

@RunWith(AndroidJUnit4::class)
class AuthUnavailableTest {
    @get:Rule val compose=createAndroidComposeRule<MainActivity>()
    @Test fun unavailableDeviceSecurityKeepsLockOffAndOffersSettings() {
        val h=PrivacyTestSupport(compose)
        h.waitFor {compose.onAllNodesWithTag("photo-grid").fetchSemanticsNodes().isNotEmpty()}
        h.settings();compose.onNodeWithTag("require-authentication").performClick()
        compose.onNodeWithText("Android security settings").assertIsDisplayed()
        compose.onNodeWithTag("require-authentication").assertIsOff()
        assertFalse(runBlocking {h.graph.preferences.requireAuthentication.first()})
        h.screenshot("authentication-unavailable")
    }
}
