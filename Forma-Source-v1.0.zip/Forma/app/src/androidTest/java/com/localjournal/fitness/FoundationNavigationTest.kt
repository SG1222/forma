package com.localjournal.fitness

import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import android.graphics.Bitmap
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import java.io.File

@RunWith(AndroidJUnit4::class)
class FoundationNavigationTest {
    @get:Rule val compose = createAndroidComposeRule<MainActivity>()
    private fun screenshot(name: String) {
        compose.waitForIdle()
        val instrumentation = InstrumentationRegistry.getInstrumentation()
        instrumentation.waitForIdleSync()
        // Compose idleness does not include the platform launch fade, system bars, or touch ripple.
        android.os.SystemClock.sleep(600)
        val destination = File(instrumentation.targetContext.filesDir, "test-screenshots/$name.png")
        destination.parentFile!!.mkdirs()
        instrumentation.uiAutomation.takeScreenshot().also { bitmap ->
            if (name == "log-dark") {
                org.junit.Assert.assertTrue("Dark Log status inset must remain dark after Activity recreation",
                    android.graphics.Color.luminance(bitmap.getPixel(1, 1)) < 0.1f)
                org.junit.Assert.assertTrue("Dark Log navigation inset must remain dark",
                    android.graphics.Color.luminance(bitmap.getPixel(1, bitmap.height - 2)) < 0.1f)
            }
            destination.outputStream().use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
            bitmap.recycle()
        }
    }
    @Test fun tabsSettingsThemeAndNativeBack() {
        compose.waitUntil(15000) { compose.onAllNodesWithText("Your photo journal is empty.").fetchSemanticsNodes().isNotEmpty() }
        compose.onNodeWithText("Add photos").assertIsEnabled()
        screenshot("log-light")
        compose.onNodeWithText("Compare", useUnmergedTree = true).performClick()
        compose.onNodeWithText("Compare photographs from different check-ins.").assertIsDisplayed()
        screenshot("compare-light")
        compose.onNodeWithText("Go to Log").performClick()
        compose.onNodeWithText("Your photo journal is empty.").assertIsDisplayed()
        compose.onNodeWithText("Streaks", useUnmergedTree = true).performClick()
        screenshot("streaks-light")
        compose.onNodeWithText("Log", useUnmergedTree = true).performClick()
        compose.onNodeWithContentDescription("Settings").performClick()
        compose.onNodeWithText("Dark theme").performScrollTo().performClick()
        compose.waitUntil(10000) { runCatching { compose.onNodeWithText("Dark theme").assertIsSelected(); true }.getOrDefault(false) }
        compose.onNodeWithText("Settings").performScrollTo()
        screenshot("settings-dark")
        compose.activityRule.scenario.recreate()
        compose.onNodeWithText("Dark theme").performScrollTo().assertIsSelected()
        compose.onNodeWithText("Settings").performScrollTo()
        compose.onNodeWithContentDescription("Back to Log").performClick()
        screenshot("log-dark")
        compose.onNodeWithContentDescription("Settings").performClick()
        compose.onNodeWithText("Light theme").performScrollTo().performClick()
        compose.waitUntil(10000) { runCatching { compose.onNodeWithText("Light theme").assertIsSelected(); true }.getOrDefault(false) }
        compose.onNodeWithText("Settings").performScrollTo()
        screenshot("settings-light")
        // Exercise native Back, not just the explicit toolbar control.
        androidx.test.platform.app.InstrumentationRegistry.getInstrumentation().runOnMainSync {
            compose.activity.onBackPressedDispatcher.onBackPressed()
        }
        compose.onNodeWithText("Your photo journal is empty.").assertIsDisplayed()
    }
}
