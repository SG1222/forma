package com.localjournal.fitness;

import android.database.Cursor;
import android.database.MatrixCursor;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.provider.DocumentsContract.Document;
import android.provider.DocumentsContract.Root;
import android.provider.DocumentsProvider;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Arrays;

/** Test APK only. Uses framework APIs so this standalone provider needs no target APK classes. */
public class LocalTestDocumentsProvider extends DocumentsProvider {
    public static final String AUTHORITY = "com.localjournal.fitness.test.documents";
    public static final String[] NAMES = {"Front test.png", "Side test.png", "Back test.png"};
    public static Bitmap fixture(int index) {
        Bitmap bitmap = Bitmap.createBitmap(720, 1080, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        int[] colors = {Color.rgb(210,218,211), Color.rgb(210,213,223), Color.rgb(224,215,205)};
        canvas.drawColor(colors[index % 3]);
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setColor(Color.rgb(52,57,65)); paint.setTextSize(42f);
        canvas.drawText("LOCAL TEST IMAGE", 48f, 84f, paint);
        paint.setTextSize(28f); canvas.drawText(NAMES[index % 3], 48f, 132f, paint);
        paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(3f);
        canvas.drawRect(80f, 220f, 640f, 930f, paint);
        canvas.drawLine(360f, 220f, 360f, 930f, paint);
        canvas.drawCircle(360f + (index - 1) * 70f, 500f, 110f, paint);
        paint.setTextSize(24f); paint.setStyle(Paint.Style.FILL);
        canvas.drawText("Fixture for journal verification", 80f, 1000f, paint);
        paint.setTextSize(56f); canvas.drawText("TEST IMAGE", 140f, 840f, paint);
        return bitmap;
    }
    @Override public boolean onCreate() {
        for (int i = 0; i < NAMES.length; i++) {
            File file = new File(getContext().getFilesDir(), NAMES[i]);
            if (!file.exists()) {
                Bitmap bitmap = fixture(i);
                try (FileOutputStream output = new FileOutputStream(file)) {
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, output);
                } catch (IOException error) { throw new IllegalStateException(error); }
                finally { bitmap.recycle(); }
            }
        }
        return true;
    }
    @Override public Cursor queryRoots(String[] projection) {
        String[] columns = projection != null ? projection : new String[]{Root.COLUMN_ROOT_ID, Root.COLUMN_DOCUMENT_ID, Root.COLUMN_TITLE, Root.COLUMN_FLAGS, Root.COLUMN_MIME_TYPES};
        MatrixCursor cursor = new MatrixCursor(columns);
        MatrixCursor.RowBuilder row = cursor.newRow();
        row.add(Root.COLUMN_ROOT_ID,"local-test"); row.add(Root.COLUMN_DOCUMENT_ID,"root");
        row.add(Root.COLUMN_TITLE,"Journal Test Images"); row.add(Root.COLUMN_FLAGS,Root.FLAG_LOCAL_ONLY);
        row.add(Root.COLUMN_MIME_TYPES,"image/png");
        return cursor;
    }
    private MatrixCursor cursor(String[] projection) {
        return new MatrixCursor(projection != null ? projection : new String[]{Document.COLUMN_DOCUMENT_ID, Document.COLUMN_DISPLAY_NAME,
            Document.COLUMN_MIME_TYPE, Document.COLUMN_FLAGS, Document.COLUMN_SIZE, Document.COLUMN_LAST_MODIFIED});
    }
    private void add(MatrixCursor cursor, String id) {
        if (!id.equals("root") && !Arrays.asList(NAMES).contains(id)) throw new IllegalArgumentException("Unknown test document");
        File file = new File(getContext().getFilesDir(), id);
        MatrixCursor.RowBuilder row = cursor.newRow();
        row.add(Document.COLUMN_DOCUMENT_ID,id);
        row.add(Document.COLUMN_DISPLAY_NAME,id.equals("root") ? "Journal Test Images" : id);
        row.add(Document.COLUMN_MIME_TYPE,id.equals("root") ? Document.MIME_TYPE_DIR : "image/png");
        row.add(Document.COLUMN_FLAGS,0); row.add(Document.COLUMN_SIZE,id.equals("root") ? 0L : file.length());
        row.add(Document.COLUMN_LAST_MODIFIED,1792400000000L);
    }
    @Override public Cursor queryDocument(String id, String[] projection) {
        MatrixCursor result = cursor(projection); add(result,id); return result;
    }
    @Override public Cursor queryChildDocuments(String parent, String[] projection, String sortOrder) {
        MatrixCursor result = cursor(projection); for (String name : NAMES) add(result,name); return result;
    }
    @Override public ParcelFileDescriptor openDocument(String id, String mode, CancellationSignal signal) throws FileNotFoundException {
        if (!Arrays.asList(NAMES).contains(id) || !mode.equals("r")) throw new FileNotFoundException("Read-only test photograph");
        return ParcelFileDescriptor.open(new File(getContext().getFilesDir(),id),ParcelFileDescriptor.MODE_READ_ONLY);
    }
    @Override public boolean isChildDocument(String parent, String id) { return parent.equals("root") && Arrays.asList(NAMES).contains(id); }
}
