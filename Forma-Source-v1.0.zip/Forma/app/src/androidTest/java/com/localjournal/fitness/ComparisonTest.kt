package com.localjournal.fitness

import android.graphics.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.toPixelMap
import androidx.compose.ui.semantics.*
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.exifinterface.media.ExifInterface
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.localjournal.fitness.data.models.*
import com.localjournal.fitness.data.preferences.ThemeMode
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.*
import org.junit.Assert.*
import org.junit.runner.RunWith
import java.io.ByteArrayOutputStream
import java.io.File
import java.time.Instant

@RunWith(AndroidJUnit4::class)
class ComparisonTest {
    @get:Rule val compose = createAndroidComposeRule<MainActivity>()
    private val instrumentation get() = InstrumentationRegistry.getInstrumentation()
    private val graph get() = instrumentation.targetContext.applicationContext as JournalApplication
    private fun entries() = runBlocking { graph.repository.checkIns.first() }
    private fun waitFor(condition: () -> Boolean) = compose.waitUntil(20000, condition)
    private fun tab(label: String) = compose.onNode(hasText(label) and hasClickAction()).performClick()
    private fun state(tag: String) = compose.onNodeWithTag(tag).fetchSemanticsNode().config[SemanticsProperties.StateDescription]
    private fun ready() = waitFor { compose.onAllNodesWithText("Opening photograph…").fetchSemanticsNodes().isEmpty() }
    @Before fun clear() {
        waitFor { compose.onAllNodesWithTag("photo-grid").fetchSemanticsNodes().isNotEmpty() }
        runBlocking {
            entries().forEach { graph.repository.deleteCheckIn(it.id) }
            graph.preferences.setThemeMode(ThemeMode.LIGHT)
        }
        waitFor { compose.onAllNodesWithText("Your photo journal is empty.").fetchSemanticsNodes().isNotEmpty() }
    }
    private fun fixture(width: Int, height: Int, color: Int, title: String, rotate: Boolean): ByteArray {
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap); canvas.drawColor(color)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = Color.WHITE; strokeWidth = 5f; style = Paint.Style.STROKE }
        canvas.drawRect(30f, 30f, width-30f, height-30f, paint)
        canvas.drawCircle(width/2f, height/2f, minOf(width,height)*.24f, paint)
        paint.style = Paint.Style.FILL; paint.textSize = 34f
        canvas.drawText("TEST IMAGE $title", 40f, height-65f, paint)
        val bytes = ByteArrayOutputStream().use { bitmap.compress(if (rotate) Bitmap.CompressFormat.JPEG else Bitmap.CompressFormat.PNG, 95, it); it.toByteArray() }
        bitmap.recycle()
        if (!rotate) return bytes
        val file = File(graph.cacheDir, "comparison-orientation-fixture.jpg")
        return try {
            file.writeBytes(bytes)
            ExifInterface(file).apply { setAttribute(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_ROTATE_90.toString()); saveAttributes() }
            file.readBytes()
        } finally { file.delete() }
    }
    private fun seed(): List<Photo> {
        val ids = mutableListOf<String>()
        runBlocking {
            repeat(3) { group ->
                val id = graph.repository.createDraft()
                val bytes = when(group) {
                    0 -> fixture(600,1000,Color.rgb(139,64,55),"A PORTRAIT",false)
                    1 -> fixture(1000,600,Color.rgb(44,91,139),"B EXIF 90",true)
                    else -> fixture(1000,600,Color.rgb(55,115,77),"C LANDSCAPE",false)
                }
                val p = graph.repository.stagePhoto(id, PhotoSource.IMPORT, bytes.inputStream(), label = if (group < 2) PhotoLabel.FRONT else PhotoLabel.BACK)
                val selected = mutableListOf(p.id); ids += p.id
                if (group == 0) {
                    val extra = graph.repository.stagePhoto(id, PhotoSource.IMPORT,
                        fixture(600,600,Color.rgb(130,110,40),"SIBLING",false).inputStream(), label = PhotoLabel.SIDE)
                    selected += extra.id; ids += extra.id
                }
                graph.repository.commitDraft(id, selected, "Comparison test fixtures")
                val date = "2026-10-${20-group}"
                graph.database.openHelper.writableDatabase.execSQL("UPDATE check_ins SET checkInDate = ?, createdAt = ? WHERE id = ?",
                    arrayOf<Any>(date, Instant.parse(date+"T12:00:00Z").toEpochMilli(), id))
            }
        }
        waitFor { entries().sumOf { it.photos.size } == 4 }
        return ids.map { id -> entries().flatMap { it.photos }.first { it.id == id } }
    }
    private fun choose(slot: String, id: String) {
        compose.onNodeWithTag("select-$slot").performClick()
        compose.onNodeWithTag("comparison-picker").performScrollToKey(id)
        compose.onNodeWithTag("pick-$id").performClick()
        ready()
    }
    private fun screenshot(name: String) {
        ready(); compose.waitForIdle(); instrumentation.waitForIdleSync(); android.os.SystemClock.sleep(600)
        val path = File(graph.filesDir,"phase3a-screenshots/$name.png"); path.parentFile!!.mkdirs()
        val bitmap=instrumentation.uiAutomation.takeScreenshot()
        path.outputStream().use { bitmap.compress(Bitmap.CompressFormat.PNG,100,it) }; bitmap.recycle()
    }
    @Test fun manualSelectionGesturesModesStateDeletionAndOriginalBytes() {
        val photos = seed(); val a=photos[0]; val sibling=photos[1]; val b=photos[2]; val c=photos[3]
        val hashes = entries().flatMap { it.photos }.associate { it.id to File(graph.filesDir,it.originalFilePath).readBytes().contentHashCode() }
        tab("Compare"); choose("A",a.id)
        compose.onNodeWithTag("select-B").performClick()
        compose.onNodeWithTag("pick-${a.id}").assertDoesNotExist()
        compose.onNodeWithTag("pick-${sibling.id}").assertDoesNotExist()
        compose.onNodeWithTag("pick-${c.id}").performClick(); ready()
        val beforeB = state("compare-pane-B")
        compose.onNodeWithTag("compare-pane-A").performTouchInput { doubleClick(center) }
        assertTrue(state("compare-pane-A").contains("2.50")); assertEquals(beforeB,state("compare-pane-B"))
        compose.onNodeWithTag("compare-pane-A").performTouchInput { swipe(center, center + Offset(width*.15f,height*.1f)) }
        val sideA=state("compare-pane-A")
        compose.onNodeWithTag("compare-pane-B").performTouchInput {
            pinch(Offset(width*.35f,height*.4f),Offset(width*.65f,height*.6f),Offset(width*.15f,height*.25f),Offset(width*.85f,height*.75f))
        }
        assertFalse(state("compare-pane-B").contains("Zoom 1.00"))
        compose.onNodeWithText("Slider").performClick(); ready()
        val beforeTransform=state("compare-slider")
        val pixelsBefore=compose.onNodeWithTag("compare-slider").captureToImage().toPixelMap()
        val colorBefore=pixelsBefore[(pixelsBefore.width*.3f).toInt(),(pixelsBefore.height*.45f).toInt()]
        val sliderWidth=compose.onNodeWithTag("compare-slider").fetchSemanticsNode().boundsInRoot.width
        compose.onNodeWithTag("comparison-divider").performTouchInput { swipe(center,center+Offset(-sliderWidth*.35f,0f),500) }
        val pixelsAfter=compose.onNodeWithTag("compare-slider").captureToImage().toPixelMap()
        val colorAfter=pixelsAfter[(pixelsAfter.width*.3f).toInt(),(pixelsAfter.height*.45f).toInt()]
        assertNotEquals("Divider must reveal different underlying pixels",colorBefore,colorAfter)
        assertEquals("Divider must not move image alignment",beforeTransform,state("compare-slider"))
        val dividerBeforeZoom=state("comparison-divider")
        compose.onNodeWithText("Move: Both").performClick(); compose.onNodeWithText("Photo B only").performClick()
        compose.onNodeWithTag("compare-slider").performTouchInput {
            pinch(Offset(width*.35f,height*.25f),Offset(width*.65f,height*.3f),Offset(width*.1f,height*.2f),Offset(width*.9f,height*.35f))
        }
        val zoomed=state("compare-slider")
        assertTrue(zoomed.startsWith("A zoom 1.0;")); assertNotEquals(beforeTransform,zoomed)
        assertEquals(dividerBeforeZoom,state("comparison-divider"))
        compose.onNodeWithTag("compare-slider").performTouchInput { swipe(Offset(width*.3f,height*.25f),Offset(width*.4f,height*.3f)) }
        val alignment=state("compare-slider")
        assertNotEquals(zoomed,alignment)
        compose.onNodeWithText("Side by Side").performClick()
        assertEquals(sideA,state("compare-pane-A"))
        compose.onNodeWithText("Slider").performClick(); assertEquals(alignment,state("compare-slider"))
        compose.activityRule.scenario.recreate()
        compose.onNodeWithText("Slider").assertIsSelected(); ready()
        assertEquals(alignment,state("compare-slider")); assertEquals(dividerBeforeZoom,state("comparison-divider"))
        tab("Log"); tab("Compare")
        compose.onNodeWithText("Slider").assertIsSelected(); assertEquals(alignment,state("compare-slider"))
        hashes.forEach { (id,hash) -> val p=entries().flatMap { it.photos }.first { it.id==id };assertEquals(hash,File(graph.filesDir,p.originalFilePath).readBytes().contentHashCode()) }
        runBlocking { graph.repository.deletePhoto(c.id) }
        waitFor { compose.onAllNodesWithText("Photo B was deleted. Choose another photograph.").fetchSemanticsNodes().isNotEmpty() }
        compose.onNodeWithTag("compare-slider").assertDoesNotExist()
        choose("B",b.id); compose.onNodeWithTag("compare-slider").assertIsDisplayed()
    }
    @Test fun quickCompareSuggestionFallbackAndNativeBack() {
        val photos=seed(); val a=photos[0]; val b=photos[2]; val c=photos[3]
        compose.onNodeWithTag("photo-${a.id}").performClick()
        compose.onNodeWithText("Compare").performClick(); ready()
        compose.onNodeWithTag("select-A").assertTextContains("20 Oct 2026",substring=true)
        compose.onNodeWithTag("select-B").assertTextContains("19 Oct 2026",substring=true)
        compose.onNodeWithTag("compare-pane-A").assertIsDisplayed()
        choose("A",c.id)
        compose.onNodeWithTag("select-B").assertTextContains("19 Oct 2026",substring=true)
        instrumentation.runOnMainSync { compose.activity.onBackPressedDispatcher.onBackPressed() }
        compose.onNodeWithContentDescription("More").assertIsDisplayed()
        compose.onNodeWithContentDescription("Back to Log").performClick()
        compose.onNodeWithTag("photo-grid").performScrollToKey(c.id)
        compose.onNodeWithTag("photo-${c.id}").performClick();compose.onNodeWithText("Compare").performClick()
        compose.onNodeWithText("Choose a photograph from another check-in.").assertIsDisplayed()
        choose("B",b.id); compose.onNodeWithTag("compare-pane-B").assertIsDisplayed()
    }
    @Test fun comparisonScreensBothThemesAndMixedOrientations() {
        val photos=seed(); tab("Compare");choose("A",photos[0].id);choose("B",photos[2].id)
        for (mode in listOf(ThemeMode.LIGHT,ThemeMode.DARK)) {
            runBlocking { graph.preferences.setThemeMode(mode) }
            val theme=mode.name.lowercase()
            compose.onNodeWithText("Side by Side").performClick();screenshot("side-by-side-exif-$theme")
            compose.onNodeWithText("Slider").performClick();screenshot("slider-exif-$theme")
            choose("B",photos[3].id);screenshot("slider-mixed-$theme")
            compose.onNodeWithText("Side by Side").performClick();screenshot("side-by-side-mixed-$theme")
            compose.onNodeWithTag("select-A").performClick();screenshot("selection-$theme")
            compose.onNodeWithContentDescription("Cancel photo selection").performClick()
            choose("B",photos[2].id)
        }
    }
    @Test fun emptyAndSingleCheckInHaveActionableStates() {
        tab("Compare")
        compose.onNodeWithText("Add photographs to at least two check-ins to compare them.").assertIsDisplayed()
        compose.onNodeWithText("Go to Log").performClick()
        val photos=seed()
        runBlocking { entries().filter { it.id!=photos[0].checkInId }.forEach { graph.repository.deleteCheckIn(it.id) } }
        tab("Compare")
        compose.onNodeWithText("Add photographs to at least two check-ins to compare them.").assertIsDisplayed()
        compose.onNodeWithText("Go to Log").assertIsEnabled()
    }
}
