package com.localjournal.fitness

import android.content.Context
import android.graphics.Bitmap
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.localjournal.fitness.core.storage.PrivatePhotoStore
import com.localjournal.fitness.data.database.JournalDatabase
import com.localjournal.fitness.data.models.PhotoSource
import com.localjournal.fitness.data.repositories.LocalJournalRepository
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import java.io.ByteArrayOutputStream
import java.io.File

@RunWith(AndroidJUnit4::class)
class DeviceStorageTest {
    @Test fun persistedDatabaseAndPrivateOriginalSurviveReopening() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val databaseName = "foundation-device-test.db"
        val root = File(context.filesDir, "foundation-device-test").also { it.mkdirs() }
        var database = Room.databaseBuilder(context, JournalDatabase::class.java, databaseName).build()
        try {
            val bitmap = Bitmap.createBitmap(32, 48, Bitmap.Config.ARGB_8888)
            val bytes = ByteArrayOutputStream().use {
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, it)
                bitmap.recycle()
                it.toByteArray()
            }
            val store = PrivatePhotoStore(root)
            val repository = LocalJournalRepository(database, store)
            val draft = repository.createDraft()
            val photo = repository.stagePhoto(draft, PhotoSource.IMPORT, bytes.inputStream())
            repository.commitDraft(draft, listOf(photo.id))
            database.close()
            database = Room.databaseBuilder(context, JournalDatabase::class.java, databaseName).build()
            val row = database.journalDao().checkIn(draft)!!.photos.single()
            val file = store.resolve(row.originalFilePath)
            assertTrue(file.canonicalPath.startsWith(context.filesDir.canonicalPath + "/"))
            assertArrayEquals(bytes, file.readBytes())
            assertTrue(context.getDatabasePath(databaseName).isFile)
            assertFalse(File(context.getExternalFilesDir(null), row.originalFilePath).exists())
            assertTrue(LocalJournalRepository(database, store).reconcile().missingOriginalIds.isEmpty())
        } finally {
            database.close()
            context.deleteDatabase(databaseName)
            root.deleteRecursively()
        }
    }
}
