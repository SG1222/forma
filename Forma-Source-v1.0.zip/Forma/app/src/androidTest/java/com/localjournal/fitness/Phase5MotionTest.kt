package com.localjournal.fitness

import android.graphics.Bitmap
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.semantics.SemanticsActions
import com.localjournal.fitness.data.preferences.ThemeMode
import kotlinx.coroutines.runBlocking
import org.junit.*
import org.junit.Assert.*
import java.io.File

class Phase5MotionTest {
    @get:Rule val compose=createAndroidComposeRule<MainActivity>()
    private val h get()=PrivacyTestSupport(compose)
    @Test fun dockStaysFixedAndTabFramesFollowTheme() {
        h.waitFor{compose.onAllNodesWithTag("photo-grid").fetchSemanticsNodes().isNotEmpty()}
        fun click(label:String) {
            val action=compose.onNode(hasText(label) and hasClickAction()).fetchSemanticsNode().config[SemanticsActions.OnClick].action!!
            compose.runOnUiThread{assertTrue(action())}
        }
        try {
            for(mode in listOf(ThemeMode.LIGHT,ThemeMode.DARK)) {
                runBlocking{h.graph.preferences.setThemeMode(mode)};h.tab("Log");h.screenshot("motion-${mode.name.lowercase()}-start")
                val bounds=compose.onNodeWithTag("navigation-dock").fetchSemanticsNode().boundsInRoot
                compose.mainClock.autoAdvance=false
                for(tab in listOf("Compare","Streaks","Log")) {
                    click(tab)
                    for(t in listOf(16L,64L,160L)) {
                        compose.mainClock.advanceTimeBy(t);compose.waitForIdle()
                        assertEquals("Dock geometry must stay fixed",bounds,compose.onNodeWithTag("navigation-dock").fetchSemanticsNode().boundsInRoot)
                        val bitmap=h.instrumentation.uiAutomation.takeScreenshot();val pixel=bitmap.getPixel(bitmap.width-8,bitmap.height/8)
                        assertEquals("No opposite-theme header flash",mode==ThemeMode.DARK,android.graphics.Color.red(pixel)<100)
                        if(t==64L) {val f=File(h.graph.filesDir,"phase3c-screenshots/motion-${mode.name.lowercase()}-$tab-mid.png");f.parentFile!!.mkdirs();f.outputStream().use{bitmap.compress(Bitmap.CompressFormat.PNG,100,it)}}
                        bitmap.recycle()
                    }
                }
                repeat(6){for(tab in listOf("Compare","Streaks","Log")){click(tab);compose.mainClock.advanceTimeBy(32)}}
                compose.mainClock.autoAdvance=true;compose.waitForIdle();compose.onAllNodesWithTag("photo-grid").assertCountEquals(1)
            }
        } finally {compose.mainClock.autoAdvance=true}
    }
}
