package com.localjournal.fitness

import android.graphics.Bitmap
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.test.platform.app.InstrumentationRegistry
import com.localjournal.fitness.core.design.*
import com.localjournal.fitness.core.security.*
import com.localjournal.fitness.data.preferences.ThemeMode
import com.localjournal.fitness.features.checkin.ReviewScreen
import com.localjournal.fitness.features.log.LogScreen
import com.localjournal.fitness.features.streaks.*
import org.junit.*
import java.io.File

/** Actual production composables with explicit slow/failure states. Not an end-to-end operation simulation. */
class Phase4StatesTest {
    @get:Rule val compose=createComposeRule()
    @Test fun loadingErrorAndEmptyRendersUseRealScreenComponents() {
        var screen by mutableIntStateOf(0)
        var dark by mutableStateOf(false)
        compose.setContent {
            // This harness bypasses MainActivity; mirror its system-bar contrast policy.
            val view = androidx.compose.ui.platform.LocalView.current
            SideEffect {
                val activity = view.context as android.app.Activity
                androidx.core.view.WindowCompat.getInsetsController(activity.window, view).apply {
                    isAppearanceLightStatusBars = !dark
                    isAppearanceLightNavigationBars = !dark
                }
            }
            JournalTheme(if(dark) ThemeMode.DARK else ThemeMode.LIGHT) { Surface {
                Box(Modifier.fillMaxSize().safeDrawingPadding()) { when(screen) {
                    0 -> LockScreen(AccessState(),true,true,{},{})
                    1 -> ReviewScreen(DraftState(busy=true,importProgress=2,importTotal=5),{},{},{_,_,_->},{},{},{},{})
                    2 -> StreaksScreen(StreaksState()) {}
                    3 -> LogScreen(FoundationState.Error("Private journal storage could not be opened. Free up device storage and try again."),LibraryState(loaded=true),emptyMap(),{},{},{},{},{_,_->},rememberLazyGridState())
                    4 -> LogScreen(FoundationState.Ready,LibraryState(loaded=true),emptyMap(),{},{},{},{},{_,_->},rememberLazyGridState())
                    else -> StreaksScreen(StreaksState(error="Check-in statistics could not be loaded. Try again.")) {}
                } }
            } }
        }
        val names=listOf("opening-journal","copy-progress","opening-history","storage-error","empty-log","history-error")
        for(mode in 0..1) for(index in names.indices) {
            compose.runOnIdle { dark=mode==1;screen=index };compose.waitForIdle()
            if(index==3) { compose.onNodeWithText("Try again").assertIsDisplayed();compose.onNodeWithText("Your photo journal is empty.").assertDoesNotExist() }
            val ins=InstrumentationRegistry.getInstrumentation();val file=File(ins.targetContext.filesDir,"phase4-states-screenshots/${names[index]}-${if(mode==0) "light" else "dark"}.png")
            file.parentFile!!.mkdirs();android.os.SystemClock.sleep(150)
            val bitmap=ins.uiAutomation.takeScreenshot();file.outputStream().use {bitmap.compress(Bitmap.CompressFormat.PNG,100,it)};bitmap.recycle()
        }
    }
}
