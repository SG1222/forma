package com.localjournal.fitness

import android.content.ContentValues
import android.graphics.BitmapFactory
import android.provider.MediaStore
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import com.localjournal.fitness.data.models.*
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.flow.first
import androidx.compose.ui.semantics.getOrNull
import org.junit.*
import org.junit.Assert.*
import java.io.*
import java.util.UUID

class Phase4ReliabilityTest {
    @get:Rule val compose=createAndroidComposeRule<MainActivity>()
    private val h get()=PrivacyTestSupport(compose)
    @Before fun clean() {
        runBlocking{h.graph.preferences.setRequireAuthentication(false)}
        h.waitFor{compose.onAllNodesWithTag("photo-grid").fetchSemanticsNodes().isNotEmpty()}
        runBlocking{h.graph.maintenance.deleteAll()}
    }
    @Test fun damagedExportLedgerRecoversOnlyItsPendingPublicCopy()=runBlocking {
        val photo=h.save(true);val source=h.graph.repository.originalForExport(photo.id);val bytes=source.readBytes()
        val collection=MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        val id=UUID.randomUUID().toString();val uri=h.graph.contentResolver.insert(collection,ContentValues().apply{
            put(MediaStore.Images.Media.DISPLAY_NAME,"PhotoJournal_$id.jpg");put(MediaStore.Images.Media.MIME_TYPE,"image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/Photo Journal/");put(MediaStore.Images.Media.IS_PENDING,1)
        })!!
        try {
            val job=File(h.graph.filesDir,"export_jobs/$id.json");job.parentFile!!.mkdirs();job.writeText("damaged metadata")
            assertTrue(h.graph.maintenance.recover())
            assertFalse(job.exists());assertArrayEquals(bytes,source.readBytes())
            val count=h.graph.contentResolver.query(uri,arrayOf("_id"),null,null,null)?.use{it.count} ?: 0
            val detail=h.graph.contentResolver.query(uri,arrayOf("_display_name","relative_path","owner_package_name","is_pending"),null,null,null)?.use{c->if(c.moveToFirst()) (0 until c.columnCount).joinToString {c.getColumnName(it)+"="+c.getString(it)} else "removed"}
            assertEquals(detail,0,count)
        } finally {runCatching{h.graph.contentResolver.delete(uri,null,null)}}
    }
    @Test fun damagedThumbnailAndMissingOriginalStayIsolated() {
        val good=h.save();val missing=h.save(true)
        val original=runBlocking{h.graph.repository.originalForExport(good.id)};val bytes=original.readBytes()
        val thumb=File(h.graph.filesDir,"thumbnails/${good.id}.jpg");thumb.writeText("corrupted preview")
        runBlocking{h.graph.repository.originalForExport(missing.id)}.delete()
        val report=runBlocking{h.graph.repository.reconcile()};assertTrue(report.missingOriginalIds.contains(missing.id))
        val bounds=BitmapFactory.Options().apply{inJustDecodeBounds=true};BitmapFactory.decodeFile(thumb.path,bounds);assertTrue(bounds.outWidth>0)
        h.waitFor{compose.onAllNodesWithTag("photo-${missing.id}").fetchSemanticsNodes().isNotEmpty()}
        compose.onNodeWithTag("photo-${missing.id}").performClick()
        h.waitFor{compose.onAllNodesWithText("This photograph could not be opened. Return to Log or remove it using More.").fetchSemanticsNodes().isNotEmpty()}
        h.screenshot("missing-original-recovery")
        compose.onNodeWithContentDescription("More").performClick();compose.onNodeWithText("Delete").performClick();compose.onNodeWithText("Delete permanently").performClick()
        h.waitFor{compose.onAllNodesWithTag("photo-grid").fetchSemanticsNodes().isNotEmpty()}
        assertArrayEquals(bytes,original.readBytes());assertEquals(1,runBlocking{h.graph.repository.storageInfo().photoCount})
    }
    @Test fun interruptedImportRetainsPriorDraftAndUnrelatedCheckIns()=runBlocking {
        val saved=h.save();val source=h.graph.repository.originalForExport(saved.id);val before=source.readBytes()
        val id=h.graph.repository.createDraft();val first=h.graph.repository.stagePhoto(id,PhotoSource.IMPORT,h.image().inputStream())
        val broken=object:InputStream(){var read=0;override fun read():Int{if(read++>20)throw IOException("ENOSPC injected import interruption");return 1}}
        try{h.graph.repository.stagePhoto(id,PhotoSource.IMPORT,broken);fail("Import must fail")}catch(_:IOException){}
        val second=h.graph.repository.stagePhoto(id,PhotoSource.IMPORT,h.image().inputStream())
        assertEquals(listOf(first.id,second.id),h.graph.repository.loadDraft(id)!!.photos.map{it.id})
        assertFalse(File(h.graph.filesDir,"drafts/$id").walkTopDown().any{it.extension=="part"})
        h.graph.repository.commitDraft(id,listOf(first.id,second.id),"TEST DATA: recovered partial import")
        assertEquals(3,h.graph.repository.storageInfo().photoCount);assertArrayEquals(before,source.readBytes())
    }
    @Suppress("DEPRECATION")
    @Test fun webpExportPreservesOriginalBytes()=runBlocking {
        val bitmap=BitmapFactory.decodeByteArray(h.image(),0,h.image().size)
        val bytes=ByteArrayOutputStream().use{bitmap.compress(android.graphics.Bitmap.CompressFormat.WEBP,95,it);bitmap.recycle();it.toByteArray()}
        val id=h.graph.repository.createDraft();val photo=h.graph.repository.stagePhoto(id,PhotoSource.IMPORT,bytes.inputStream())
        h.graph.repository.commitDraft(id,listOf(photo.id));val original=h.graph.repository.originalForExport(photo.id)
        val uri=h.graph.exporter.export(original)
        try {assertArrayEquals(bytes,original.readBytes());assertArrayEquals(bytes,h.graph.contentResolver.openInputStream(uri)!!.use{it.readBytes()})}
        finally{h.graph.contentResolver.delete(uri,null,null)}
    }

    @Test fun timezoneBroadcastRefreshesTodayWithoutRewritingSavedDates() {
        val photo=h.save();val saved=runBlocking{h.graph.repository.checkIns.first().first{it.id==photo.checkInId}.checkInDate}
        h.tab("Streaks")
        val old=java.util.TimeZone.getDefault().id
        fun timezone(zone:String) {
            require(zone.matches(Regex("[A-Za-z0-9_+/:-]+")))
            val fd=h.instrumentation.uiAutomation.executeShellCommand("cmd alarm set-timezone $zone")
            android.os.ParcelFileDescriptor.AutoCloseInputStream(fd).use{it.readBytes()}
        }
        try { for(zone in listOf("Pacific/Kiritimati","Pacific/Honolulu")) {
            timezone(zone)
            val expected=java.time.LocalDate.now(java.time.ZoneId.of(zone))
            h.waitFor {compose.onAllNodesWithTag("calendar-day-$expected").fetchSemanticsNodes().any{
                it.config.getOrNull(androidx.compose.ui.semantics.SemanticsProperties.StateDescription)?.startsWith("Today.")==true
            }}
            assertEquals(saved,runBlocking{h.graph.repository.checkIns.first().first{it.id==photo.checkInId}.checkInDate})
        }} finally {timezone(old)}
    }

}
