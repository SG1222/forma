# AndroidX/Room/CameraX/Coil consumer rules and the standard Android optimized rules apply.
# No application-wide keep rule: this local variant exercises normal R8 optimization.
